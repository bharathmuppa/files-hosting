# Material ![Coverage](https://gitlab.com/rgb5300241/enterprise-components/material/badges/0.0.1/coverage.svg)


This project contains of angular components based on Enterprise Design System compliant with Material guidelines.
The contents of this project are eventually published into @enterprise-components/material library in [ec Artifactory]()

## Usage
### npm

`npm config set strict-ssl false`

`npm add @enterprise-components/material`


## Build
Run the following to build the project.The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build
`ng build`


# conventions

The file you are trying to import is named _index.scss (with the underscore).
Sass uses the underscore as a convention to treat files as partials, meaning they won't be compiled into standalone CSS files but can be imported.

# Development
## While creating a new component
- `node tools/create-component.js @enterprise-components/material  atoms slide-toggle  `
# Migration Guides
- script for updating flex-layout to tailwind flexlayout
  - `npx @ngnomads/ngflex2tailwind -r false -p ./projects/enterprise-components/material/src/lib/atoms/filter-button`
- script for updating Angular structural directives to control flow
  - `ng generate @angular/core:control-flow`
- Script to migrate to standalone componnets
  - `ng generate @angular/core:standalone`

# Changelog for commit
- use granular commits for better changelog generation
- Use conventional commit messages for better changelog generation
- Follow [Angular Commit Guide](https://github.com/angular/angular/blob/main/CONTRIBUTING.md#commit)

## Commit Message Format

```text
<type>(<scope>): <short summary>
│       │             │
│       │             └─⫸ Summary in present tense. Not capitalized. No period at the end.
│       │
│       └─⫸ Commit Scope: animations|bazel|benchpress|common|compiler|compiler-cli|core|
│                          elements|forms|http|language-service|localize|platform-browser|
│                          platform-browser-dynamic|platform-server|router|service-worker|
│                          upgrade|zone.js|packaging|changelog|docs-infra|migrations|
│                          devtools
│
└─⫸ Commit Type: build|ci|docs|feat|fix|perf|refactor|test
```


### Examples

- feat(aal-input-currency): add new feature
- fix(aal-input-currency): fix issue
- refactor(aal-input-currency): refactor code


- Message should be imperative like 

