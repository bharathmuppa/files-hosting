// .eslintrc.js
module.exports = {
  // Marks this configuration as the root, so ESLint doesn’t look for other configurations higher up in the directory.
  root: true,

  parser: '@typescript-eslint/parser',

  // Ignore patterns prevent ESLint from processing specific folders or files.
  // Here, "projects/**/*" ensures that sub-projects are ignored unless they have their own ESLint configuration.
  ignorePatterns: ['projects/**/*'],

  env: {
    browser: true,
    es6: true,
    node: true,
    jasmine: true, // Add this line to recognize Jasmine globals
    // jest: true  // Use this instead if you are using Jest
  },

  overrides: [
    {
      // Target HTML files for Angular template linting.
      files: ['*.html'],

      // Extend Angular-specific template linting rules.
      extends: ['plugin:@angular-eslint/template/recommended'],

      // Add template-specific rules here if necessary
      rules: {},
    },
    {
      // Target HTML templates within components for Angular template linting.
      files: ['*.component.ts'],
      extends: ['plugin:@angular-eslint/template/process-inline-templates'],
    },
  ],

  // Extend Storybook’s recommended rules for Storybook-specific code.
  extends: ['plugin:storybook/recommended'],
};
