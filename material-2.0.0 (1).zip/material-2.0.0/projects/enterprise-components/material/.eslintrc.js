// .eslintrc.js for the @enterprise-material/material sub-project
const path = require('path');

module.exports = {
  // Extends the root ESLint configuration located at "../../../.eslintrc.js"
  // This inherits global rules and plugins from the main project.
  extends: '../../../.eslintrc.js',

  // The ignorePatterns section excludes files from linting.
  // The "!" symbol negates the pattern, meaning all files are included for linting.
  // The '**/.storybook' pattern explicitly excludes the Storybook directory.
  ignorePatterns: ['!**/*', '**/.storybook'],

  // Overrides allow us to apply specific configurations for certain types of files.
  overrides: [
    {
      // Target TypeScript files (excluding test files) within this sub-project for linting.
      files: ['**/*.ts'],
      excludedFiles: ['**/*.spec.ts'], // Ensures test files are not included in this configuration.

      // parserOptions specifies the TypeScript configurations specific to this library project.
      // 'sourceType: module' allows ES6 modules syntax for imports and exports.
      parserOptions: {
        sourceType: 'module', // Ensures TypeScript files are parsed as modules
        project: [
          path.join(__dirname, 'tsconfig.lib.json'), // TypeScript config for the library code
        ],
        createDefaultProgram: true, // Allows ESLint to automatically use project files in the absence of a specified program
      },

      // Extends recommended configurations for Angular and Prettier integration.
      extends: [
        'plugin:@angular-eslint/recommended', // Angular-specific best practices
        'plugin:@angular-eslint/template/process-inline-templates', // Support for inline HTML in Angular components
        'plugin:prettier/recommended', // Integrates Prettier and disables ESLint conflicts
      ],

      // Custom rules specific to this sub-project, aligned with Angular best practices.
      rules: {
        // Warns against prefixing Angular outputs with 'on'
        '@angular-eslint/no-output-on-prefix': 'warn',

        // Disables the rule for empty lifecycle methods, allowing flexibility in component setup
        '@angular-eslint/no-empty-lifecycle-method': 'off',

        // Enforces attribute selector style for Angular directives
        '@angular-eslint/directive-selector': [
          'error',
          {
            type: 'attribute', // Ensures directives use attribute selectors
            prefix: 'aal', // Custom prefix for the sub-project
            style: 'camelCase', // Enforces camelCase for directive selectors
          },
        ],

        // Enforces element selector style for Angular components
        '@angular-eslint/component-selector': [
          'error',
          {
            type: 'element', // Ensures components use element selectors
            prefix: 'aal', // Custom prefix for the sub-project
            style: 'kebab-case', // Enforces kebab-case for component selectors
          },
        ],
      },
    },
    {
      // Targeting only .spec.ts files for unit tests to apply different settings for test files.
      files: ['*.spec.ts'],

      // Parser options specific to test files, ensuring ESLint applies only the test TypeScript configuration.
      parserOptions: {
        sourceType: 'module', // Allows ES6 module syntax for imports and exports in test files
        project: [
          path.join(__dirname, 'tsconfig.spec.json'), // TypeScript config for unit tests in this sub-project
        ],
      },

      // Environment settings for Jasmine testing framework.
      env: {
        jasmine: true, // Enables Jasmine-specific global variables like describe, it, and beforeEach
      },

      // Adding specific global variables for Jasmine, marking them as read-only.
      globals: {
        describe: 'readonly',
        it: 'readonly',
        beforeEach: 'readonly',
        expect: 'readonly',
      },

      // Custom rules for test files to allow flexibility in testing, e.g., disabling undefined variable checks.
      rules: {
        '@typescript-eslint/no-undef': 'off', // Disables errors for undefined variables, often useful in tests
      },
    },
  ],
};
