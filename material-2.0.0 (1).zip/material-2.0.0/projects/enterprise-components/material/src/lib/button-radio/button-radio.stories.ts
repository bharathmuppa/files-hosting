import { UntypedFormBuilder, UntypedFormControl, Validators } from '@angular/forms';
import { Info, Modes } from '@enterprise-components/common';
import type { Meta, StoryObj } from '@storybook/angular';
import { fn } from '@storybook/test';
import { ButtonRadioComponent } from '../atoms/button-radio/button-radio.component';

const meta: Meta<ButtonRadioComponent> = {
  title: 'Enterprise Components/Legacy/Radio Button/Radio Button',
  tags: ['autodocs'],
  component: ButtonRadioComponent,
};

export default meta;
type Story = StoryObj<ButtonRadioComponent>;

const fb: UntypedFormBuilder = new UntypedFormBuilder();
const objectFormControl: UntypedFormControl = fb.control([], [Validators.required]);
const objectOptions = [
  {
    name: 'option1',
    description:
      'description1 description1 description1 description1 description1 description1 description1 description1 description1 description1 description1 description1 description1 description1 description1',
    line1: 'l1 aakjlkjlkjalkjlk',
  },
  { name: 'option2', description: 'test2 test2 test2 test2 test2', line1: 'l2 lksjflfsjsfk' },
  { name: 'option3', description: 'test3', line1: 'l3 mkljlkd' },
];
const errorTitle = 'Error Title';
const errorMessage =
  'This is error message with <a target="_blank" href="https://www.google.com">link </a>';
const errorAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
const errorThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ec_Holding_N.V._logo.svg';
const errorLevel = 'ERROR';
const helpTitle = 'Help Title';
const helpMessage =
  'This is help message with <a target="_blank" href="https://www.google.com">link </a>';
const helpAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
const helpThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ec_Holding_N.V._logo.svg';
const alert: Info = new Info(errorTitle, errorMessage, errorAnimation, errorThumbnail, errorLevel);
const help: Info = new Info(helpTitle, helpMessage, helpAnimation, helpThumbnail, null);

// <!-- storybook:DONE button-radio.stories.ts ObjectBased-->
export const ObjectBased: Story = {
  args: {
    acceptChanges: fn(),
    control: objectFormControl,
    options: objectOptions,
    alert,
    help,
    mode: Modes.EDIT,
    lockMode: Modes.EDIT,
  },
  render: (args) => {
    return {
      props: args,
      template: `
      <aal-button-radio
        (acceptChanges)="acceptChanges($event)"
        [ID]="'button_radio_object'"
        [control]="control"
        [alert]="alert"
        [help]="help"
        [mode]="mode"
        [lockMode]="lockMode"
        [optionLabelField]="'description'"
        [optionValueField]="'name'"
        [optionLine1Field]="'line1'"
        [optionIdField]="'description'"
        [alignOptionsHorizontally]="true"
        [hideLabel]="true"
        [options]="options"
        [label]="'Select Object'"
        [placeholder]="'select object'">
      </aal-button-radio>
      `,
    };
  },
};

const optionsObjectList = [
  {
    name: 'option1',
    value: 'option1',
    description: 'description1',
    line1: 'l1 aakjlkjlkjalkjlk',
    disabled: false,
  },
  {
    name: 'option2',
    value: 'option2',
    description: 'description2',
    line1: 'l2 lksjflfsjsfk',
    disabled: true,
  },
  {
    name: 'option3',
    value: 'option3',
    description: 'description3',
    line1: 'l3 mkljlkd',
    disabled: false,
  },
];

const fb1: UntypedFormBuilder = new UntypedFormBuilder();
const objectFormControl1: UntypedFormControl = fb1.control([], [Validators.required]);

// <!-- storybook:DONE button-radio.stories.ts ObjectBasedRadioButtonsWithOptionDisabledProperty-->
export const ObjectBasedRadioButtonsWithOptionDisabledProperty: Story = {
  args: {
    acceptChanges: fn(),
    control: objectFormControl1,
    options: optionsObjectList,
    alert,
    help,
  },
  render: (args) => {
    return {
      props: args,
      template: `
      <aal-button-radio
        (acceptChanges)="acceptChanges($event)"
        [ID]="'button_radio_object'"
        [control]="control"
        [alert]="alert"
        [help]="help"
        [optionLabelField]="'value'"
        [optionValueField]="'value'"
        [optionLine1Field]="'line1'"
        [optionIdField]="'description'"
        [alignOptionsHorizontally]="true"
        [disableControl]="false"
        [hideLabel]="true"
        [options]="options"
        [label]="'Select Object'"
        [placeholder]="'select object'">
      </aal-button-radio>
      `,
    };
  },
};

const fb2: UntypedFormBuilder = new UntypedFormBuilder();
const stringFormControl: UntypedFormControl = fb2.control(null, [Validators.required]);
const stringOptions = ['str option1', 'str option2', 'str option3'];

// <!-- storybook:DONE button-radio.stories.ts StringBased-->
export const StringBased: Story = {
  args: {
    acceptChanges: fn(),
    control: stringFormControl,
    options: stringOptions,
    alert,
    help,
  },
  render: (args) => {
    return {
      props: args,
      template: `
      <aal-button-radio
        [ID]="'button_radio_string'"
        [label]="'Select String'"
        [placeholder]="'select string'"
        [options]="options"
        [control]="control"
        [showHyphenForValues]="[null, '']"
        [help]="help"
        [alert]="alert"
        (rejectChanges)="rejectChanges($event)"
        (acceptChanges)="acceptChanges($event)">
      </aal-button-radio>
      `,
    };
  },
};

// <!-- storybook:DONE button-radio.stories.ts StringBasedProtected-->
export const StringBasedProtected: Story = {
  args: {
    acceptChanges: fn(),
    control: stringFormControl,
    options: stringOptions,
    alert,
    help,
    mode: Modes.PROTECTED,
  },
  render: (args) => {
    return {
      props: args,
      template: `
        <aal-button-radio
          [ID]="'button_radio_string'"
          [label]="'Select String'"
          [placeholder]="'select string'"
          [options]="options"
          [control]="control"
          [help]="help"
          [mode]="mode"
          [alert]="alert"
          (acceptChanges)="acceptChanges($event)">
        </aal-button-radio>
      `,
    };
  },
};

// <!-- storybook:DONE button-radio.stories.ts StringBasedPrivate-->
export const StringBasedPrivate: Story = {
  args: {
    acceptChanges: fn(),
    control: stringFormControl,
    options: stringOptions,
    alert,
    help,
    mode: Modes.PRIVATE,
  },
  render: (args) => {
    return {
      props: args,
      template: `
      <aal-button-radio
        [ID]="'button_radio_string'"
        [label]="'Select String'"
        [placeholder]="'select string'"
        [options]="options"
        [control]="control"
        [showHyphenForValues]="[null, '']"
        [help]="help"
        [mode]="mode"
        [alert]="alert"
        (acceptChanges)="acceptChanges($event)">
      </aal-button-radio>
      `,
    };
  },
};
