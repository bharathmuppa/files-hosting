import { UntypedFormBuilder, Validators } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Info } from '@enterprise-components/common';
import { moduleMetadata, type Meta, type StoryObj } from '@storybook/angular';
import { fn } from '@storybook/test';
import { ButtonRadioInputComponent } from './button-radio-input.component';

const meta: Meta<ButtonRadioInputComponent> = {
  title: 'Enterprise Components/Legacy/Radio Button/Button Radio Input',
  tags: ['autodocs'],
  component: ButtonRadioInputComponent,
  decorators: [
    moduleMetadata({
      imports: [BrowserAnimationsModule],
    }),
  ],
};

export default meta;
type Story = StoryObj<ButtonRadioInputComponent>;

const objectOptions = [
  { name: 'option1', description: 'description1', line1: 'line1 option1' },
  { name: 'option2', description: 'description2', line1: 'line1 option2' },
  { name: 'option3', description: 'description3', line1: 'line1 option3' },
];
const errorTitle = 'Error Title';
const errorMessage =
  'This is an error message with <a target="_blank" href="https://www.google.com">link</a>';
const errorAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
const errorThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ec_Holding_N.V._logo.svg';
const errorLevel = 'ERROR';
const helpTitle = 'Help Title';
const helpMessage =
  'This is a help message with <a target="_blank" href="https://www.google.com">link</a>';
const helpAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
const helpThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ec_Holding_N.V._logo.svg';
const alert: Info = new Info(errorTitle, errorMessage, errorAnimation, errorThumbnail, errorLevel);
const help: Info = new Info(helpTitle, helpMessage, helpAnimation, helpThumbnail, null);

export const ObjectBasedWithInput: Story = {
  args: {
    acceptChanges: fn(),
    options: objectOptions,
    alert,
    help,
  },
  render: (args) => {
    const fb = new UntypedFormBuilder();
    const control = fb.control([], [Validators.required]);
    const secondaryControl = fb.control('');

    return {
      props: {
        ...args,
        control,
        secondaryControl,
      },
      template: `
        <aal-button-radio-input
          [ID]="'button_radio_input_object'"
          [isNullable]="true"
          [label]="'Select Object'"
          [optionLabelField]="'description'"
          [optionLine1Field]="'line1'"
          [optionValueField]="'name'"
          [optionIdField]="'description'"
          [placeholder]="'select string'"
          [options]="options"
          [control]="control"
          [secondaryControl]="secondaryControl"
          [secondaryControlID]="'button_radio_string_secondary_input'"
          [secondaryControlPlaceholder]="'Description'"
          [showHyphenForValues]="[null, '']"
          [isSecondaryControlValueHTML]="true"
          [valuesWhereSecondaryControlIsApplicable]="['option2', 'option3']"
          [valuesWhereSecondaryControlIsMandatory]="['option2']"
          [combineValueChangeEvents]="false"
          [help]="help"
          [alert]="alert"
          (acceptSecondaryControlChanges)="acceptChanges($event)"
          (revertSecondaryControlChanges)="acceptChanges($event)"
          (acceptChanges)="acceptChanges($event)">
        </aal-button-radio-input>
      `,
    };
  },
};

export const StringBasedWithInput: Story = {
  args: {
    acceptChanges: fn(),
    options: ['str option1', 'str option2', 'str option3'],
    alert,
    help,
  },
  render: (args) => {
    const fb = new UntypedFormBuilder();
    const control = fb.control(null, [Validators.required]);
    const secondaryControl = fb.control('');

    return {
      props: {
        ...args,
        control,
        secondaryControl,
      },
      template: `
        <aal-button-radio-input
          [ID]="'button_radio_string'"
          [isNullable]="true"
          [label]="'Select String'"
          [placeholder]="'select string'"
          [options]="options"
          [control]="control"
          [showHyphenForValues]="[null, '']"
          [secondaryControl]="secondaryControl"
          [secondaryControlID]="'button_radio_string_secondary_input'"
          [isSecondaryControlValueHTML]="false"
          [secondaryControlPlaceholder]="'Description'"
          [valuesWhereSecondaryControlIsApplicable]="['str option2', 'str option3']"
          [valuesWhereSecondaryControlIsMandatory]="['str option2']"
          [help]="help"
          [alert]="alert"
          (acceptSecondaryControlChanges)="acceptChanges($event)"
          (revertSecondaryControlChanges)="acceptChanges($event)"
          (acceptChanges)="acceptChanges($event)">
        </aal-button-radio-input>
      `,
    };
  },
};

export const CombinedValueChangeEvents: Story = {
  args: {
    acceptChanges: fn(),
    options: ['str option1', 'str option2', 'str option3'],
    alert,
    help,
  },
  render: (args) => {
    const fb = new UntypedFormBuilder();
    const control = fb.control(null, [Validators.required]);
    const secondaryControl = fb.control('');

    return {
      props: {
        ...args,
        control,
        secondaryControl,
      },
      template: `
        <aal-button-radio-input
          [ID]="'button_radio_string'"
          [isNullable]="true"
          [label]="'Select String'"
          [placeholder]="'select string'"
          [options]="options"
          [control]="control"
          [secondaryControl]="secondaryControl"
          [secondaryControlID]="'button_radio_string_secondary_input'"
          [isSecondaryControlValueHTML]="false"
          [secondaryControlPlaceholder]="'Description'"
          [valuesWhereSecondaryControlIsApplicable]="['str option2', 'str option3']"
          [valuesWhereSecondaryControlIsMandatory]="['str option2']"
          [combineValueChangeEvents]="false"
          [help]="help"
          [alert]="alert"
          (acceptSecondaryControlChanges)="acceptChanges($event)"
          (revertSecondaryControlChanges)="acceptChanges($event)"
          (acceptChanges)="acceptChanges($event)">
        </aal-button-radio-input>
      `,
    };
  },
};
