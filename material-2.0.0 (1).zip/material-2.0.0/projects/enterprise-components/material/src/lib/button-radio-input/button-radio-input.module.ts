import { NgModule } from '@angular/core';
import { ButtonRadioInputComponent } from './button-radio-input.component';

@NgModule({
  imports: [ButtonRadioInputComponent],
  exports: [ButtonRadioInputComponent],
})
export class ButtonRadioInputModule {}
