import { AsyncPipe, NgClass } from '@angular/common';
import { Component, Input, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormControl } from '@angular/forms';
import { MatAutocomplete, MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { MatIconButton } from '@angular/material/button';
import { MatOption } from '@angular/material/core';
import { MatDivider } from '@angular/material/divider';
import { MatFormField, MatLabel, MatSuffix } from '@angular/material/form-field';
import { MatIcon } from '@angular/material/icon';
import { MatInput } from '@angular/material/input';
import { MatProgressSpinner } from '@angular/material/progress-spinner';
import { MatTooltip } from '@angular/material/tooltip';
import { AALAutoCompleteFormControlComponent } from '@enterprise-components/common';
import { CardSummaryComponent } from '../card-summary/card-summary.component';
import { ChipModule } from '../chip/chip.module';
import { OverlayCardAlertComponent } from '../overlay-card-alert/overlay-card-alert.component';
import { OverlayCardHelpComponent } from '../overlay-card-help/overlay-card-help.component';
import { CommonMaterialComponentErrorStateMatcher } from '../shared/common-material-component.error-state-matcher';

@Component({
  selector: 'aal-auto-complete-single-card',
  templateUrl: './auto-complete-single-card.component.html',
  styleUrls: ['./auto-complete-single-card.component.scss'],
  standalone: true,
  imports: [
    OverlayCardHelpComponent,
    MatProgressSpinner,
    MatFormField,
    MatLabel,
    MatInput,
    FormsModule,
    MatAutocompleteTrigger,
    ReactiveFormsModule,
    MatIconButton,
    MatSuffix,
    MatIcon,
    MatAutocomplete,
    MatOption,
    MatDivider,
    MatTooltip,
    NgClass,
    CardSummaryComponent,
    ChipModule,
    OverlayCardAlertComponent,
    AsyncPipe,
  ],
})
export class AutoCompleteSingleCardComponent extends AALAutoCompleteFormControlComponent {
  errorStateMatcher = new CommonMaterialComponentErrorStateMatcher();
  oldValueUpdated: boolean;
  @Input()
  showValueAsChip: boolean;
  @Input()
  fallbackImageURL: string;
  @ViewChild('resultAutoComplete', { static: false }) matAutoComplete: MatAutocomplete;
  @ViewChild('inputField', { read: MatAutocompleteTrigger }) autoTrigger: MatAutocompleteTrigger;

  @Input()
  set control(ctrl: UntypedFormControl) {
    this.frmControl = ctrl;
    if (ctrl && ctrl.value) {
      this.oldValue =
        typeof ctrl.value === 'object' ? JSON.parse(JSON.stringify(ctrl.value)) : ctrl.value;
      this.setInputValue(ctrl.value);
    }
    this.frmControl.valueChanges.subscribe((val) => {
      if (
        !this.oldValueUpdated &&
        typeof val === 'object' &&
        this.oldValue &&
        typeof this.oldValue === 'string'
      ) {
        this.oldValue = typeof val === 'object' ? JSON.parse(JSON.stringify(val)) : val;
        this.oldValueUpdated = !this.oldValueUpdated;
      }
      this.setInputValue(val);
    });
  }

  get control() {
    return this.frmControl;
  }

  onClick(): void {
    this.setInputValue(this.control.value);
    super.onClick();
  }

  setInputValue(val): void {
    this.inputControl.setValue(typeof val === 'object' ? JSON.parse(JSON.stringify(val)) : val);
  }

  emptyControl(): void {
    this.control.setValue('');
    this.inputControl.setValue('');
    if (this.control.valid) {
      this.triggerAcceptChanges();
    }
    this.mode = this.modes.EDIT;
  }

  onItemSelected(item): void {
    this.control.patchValue(item);
    this.triggerAcceptChanges();
  }

  onInputBlur(event: any): void {
    if (event.relatedTarget && this.matAutoComplete.isOpen) {
      event.relatedTarget.click();
    } else if (event.relatedTarget && event.relatedTarget.id === this.hyphenatedID + '_close') {
      event.preventDefault();
    } else {
      // update old value with control value if the control value is changed
      // eg: in case, if there is any additional logic to set control value as object from string etc..
      if (this.control.value && typeof this.oldValue !== typeof this.control.value) {
        this.oldValue = this.control.value;
      }
      this.triggerRejectChanges();
    }
  }

  onKeyUp(event: any) {
    if (event.key === ' ' && this.autoTrigger && this.autoTrigger.activeOption) {
      this.onItemSelected(this.autoTrigger.activeOption.value);
    }
  }

  getDisplayText(item: any): string {
    const itemData = [];
    if (this.displayFields) {
      if (item && typeof item === 'string') {
        return item;
      }
      if (item && this.displayFields && this.displayFields.length === 1) {
        return item[this.displayFields[0]];
      }
      if (item && this.displayFields && this.displayFields.length === 2) {
        return item[this.displayFields[0]] + ' (' + item[this.displayFields[1]] + ')';
      }
      if (item && this.displayFields && this.displayFields.length > 2) {
        this.displayFields.forEach((field: string) => {
          if (item && item[field]) {
            itemData.push(item[field].value || item[field]);
          }
        });
        return itemData.join(' - ');
      }
      return '';
    }
  }

  getImageURL(): string {
    if (!this.control || !this.control.value) {
      return null;
    } else if (this.control.value.photoURL && this.control.value.photoURL !== '') {
      return this.control.value.photoURL;
    } else if (this.createImageUrlFn) {
      return this.createImageUrlFn(this.control.value);
    } else if (this.itemImageURL) {
      return this.itemImageURL;
    } else if (this.fallbackImageURL) {
      return this.fallbackImageURL;
    } else {
      return null;
    }
  }

  getMainDescription(item: any) {
    const itemData = [];
    if (this.displayFields) {
      if (item && typeof item === 'string') {
        return item;
      }
      if (item && this.displayFields && this.displayFields.length === 1) {
        return item[this.displayFields[0]];
      }
      if (
        item &&
        this.displayFields &&
        this.displayFields.length === 2 &&
        item[this.displayFields[0]] &&
        item[this.displayFields[1]]
      ) {
        return item[this.displayFields[0]] + ' (' + item[this.displayFields[1]] + ')';
      }
      if (item && this.displayFields && this.displayFields.length > 2) {
        this.displayFields.forEach((field: string) => {
          if (item && item[field]) {
            itemData.push(item[field].value || item[field]);
          }
        });
        return itemData.join(' - ');
      }
      return '';
    }
  }
}
