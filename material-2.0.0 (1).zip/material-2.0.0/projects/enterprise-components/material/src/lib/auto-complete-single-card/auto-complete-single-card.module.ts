import { NgModule } from '@angular/core';
import { AutoCompleteSingleCardComponent } from './auto-complete-single-card.component';

@NgModule({
  imports: [AutoCompleteSingleCardComponent],
  exports: [AutoCompleteSingleCardComponent],
})
export class AutoCompleteSingleCardModule {}
