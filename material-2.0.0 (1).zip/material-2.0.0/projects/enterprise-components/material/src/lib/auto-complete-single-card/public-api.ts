/*
 * Public API Surface of material
 */

export * from './auto-complete-single-card.component';
export * from './auto-complete-single-card.module';
