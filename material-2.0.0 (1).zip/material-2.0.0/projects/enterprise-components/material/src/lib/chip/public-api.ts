/*
 * Public API Surface of material
 */

export * from './chip.component';
export * from './chip.module';
