import { CommonModule } from '@angular/common';

import { MatChipsModule } from '@angular/material/chips';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';

import type { Meta, StoryObj } from '@storybook/angular';
import { moduleMetadata } from '@storybook/angular';

import { AALCommonComponentsModule } from '@enterprise-components/common';

import { OverlayCardErrorModule } from '../overlay-card-alert/overlay-card-alert.module';
import { OverlayCardHelpModule } from '../overlay-card-help/overlay-card-help.module';
import { ToolbarConfirmModule } from '../toolbar-confirm/toolbar-confirm.module';
import { ChipComponent } from './chip.component';

const meta: Meta<ChipComponent> = {
  title: 'Enterprise Components/Legacy/Chip',
  tags: ['autodocs'],
  decorators: [
    moduleMetadata({
      imports: [
        CommonModule,
        AALCommonComponentsModule,
        OverlayCardHelpModule,
        OverlayCardErrorModule,
        ToolbarConfirmModule,
        MatChipsModule,
        MatIconModule,
        MatTooltipModule,

        ChipComponent,
      ],
    }),
  ],
};

export default meta;
type Story = StoryObj<ChipComponent>;

export const Default: Story = {
  args: {
    data: 'cug-cm-ccb-mc01',
  },
  render: (args) => ({
    props: args,
    template: `
    <aal-chip
      data={{data}}>
    </aal-chip>
    `,
  }),
};
