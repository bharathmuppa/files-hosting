import { NgModule } from '@angular/core';
import { ChipComponent } from './chip.component';

@NgModule({
  imports: [ChipComponent],
  exports: [ChipComponent],
})
export class ChipModule {}
