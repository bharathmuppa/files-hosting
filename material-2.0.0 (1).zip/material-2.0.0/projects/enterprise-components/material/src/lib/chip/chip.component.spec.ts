import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatBadgeModule } from '@angular/material/badge';
import { AALCommonComponentsModule } from '@enterprise-components/common';

import { SharedFormModule } from '../shared/shared-form.module';
import { SharedMaterialModule } from '../shared/shared-material.module';
import { SharedModule } from '../shared/shared.module';
import { ChipComponent } from './chip.component';

describe('ChipComponent', () => {
  let component: ChipComponent;
  let fixture: ComponentFixture<ChipComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        MatBadgeModule,
        ChipComponent,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call onRemove', () => {
    spyOn(component.deleteChip, 'emit');
    const $event = { value: 'sample data' };
    component.onRemove($event);
    expect(component.deleteChip.emit).toHaveBeenCalled();
  });

  it('should call onChipClick', () => {
    spyOn(component.chipPress, 'emit');
    const $event = { value: 'sample data' };
    component.onChipClick($event);
    expect(component.chipPress.emit).toHaveBeenCalled();
  });

  it('should remove chip based on the index passed.', () => {
    spyOn(component.removeChipEvent, 'emit');
    const chipIndex = 1;
    component.removeChip(chipIndex);
    expect(component.removeChipEvent.emit).toHaveBeenCalled();
  });

  it('should emit matChipClicked event when mouseOnChip is true.', () => {
    spyOn(component.matChipClicked, 'emit');
    component.mouseOnChip = true;
    component.matChipClick();
    expect(component.matChipClicked.emit).toHaveBeenCalled();
  });

  it('should emit matChipClicked event as true when mouseOverChipData is called.', () => {
    const event = true;

    spyOn(component, 'mouseOverChipData').and.callThrough();
    spyOn(component.matChipClicked, 'emit');
    component.mouseOverChipData(event);

    expect(component.mouseOverChipData).toHaveBeenCalledWith(event);
    expect(component.mouseOnChip).toBeTrue();
    expect(component.matChipClicked.emit).toHaveBeenCalledWith(true);
  });

  it('should emit matChipClicked event as false when mouseOverChipData is called.', () => {
    const event = undefined;

    spyOn(component, 'mouseOverChipData').and.callThrough();
    spyOn(component.matChipClicked, 'emit');
    component.mouseOverChipData(event);

    expect(component.mouseOverChipData).toHaveBeenCalledWith(event);
    expect(component.mouseOnChip).toBeFalse();
    expect(component.matChipClicked.emit).toHaveBeenCalledWith(false);
  });

  it('should emit activateRemoveChip and matChipClicked events when we call mouseOverRemoveChip.', () => {
    const event = 0;
    const data = {
      chipIndex: event,
      removeChipActivated: true,
    };

    spyOn(component, 'mouseOverRemoveChip').and.callThrough();
    spyOn(component.activateRemoveChip, 'emit');
    spyOn(component.matChipClicked, 'emit');

    component.mouseOverRemoveChip(event);
    expect(component.mouseOverRemoveChip).toHaveBeenCalledWith(event);
    expect(component.activateRemoveChip.emit).toHaveBeenCalledWith(data);
    expect(component.matChipClicked.emit).toHaveBeenCalledWith(true);
  });

  it('should emit activateRemoveChip event only when we call mouseOverRemoveChip.', () => {
    const event = -1;

    spyOn(component, 'mouseOverRemoveChip').and.callThrough();
    spyOn(component.activateRemoveChip, 'emit');

    component.mouseOverRemoveChip(event);
    expect(component.mouseOverRemoveChip).toHaveBeenCalledWith(event);
    expect(component.activateRemoveChip.emit).toHaveBeenCalledWith(false);
  });
});
