import { MAT_NATIVE_DATE_FORMATS } from '@angular/material/core';
import { MatDatePickerTypes } from './date-picker.component';

export function generateMatDateFormats(matDatePickerType?: MatDatePickerTypes) {
  return {
    ...MAT_NATIVE_DATE_FORMATS,
    display: {
      ...MAT_NATIVE_DATE_FORMATS.display,
      dateInput: matDatePickerType || MatDatePickerTypes.DATE_PICKER,
    },
  };
}
