import { MatNativeDateModule } from '@angular/material/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Info, Modes } from '@enterprise-components/common';
import { moduleMetadata, type Meta, type StoryObj } from '@storybook/angular';
import { fn } from '@storybook/test';
import { PassCustomControl } from '../../../.storybook/utils';
import { DatePickerComponent, MatDatePickerTypes } from './date-picker.component';

const meta: Meta<DatePickerComponent> = {
  title: 'Enterprise Components/Molecules/Date Picker',
  component: DatePickerComponent,
  decorators: [
    moduleMetadata({
      imports: [MatNativeDateModule, BrowserAnimationsModule],
    }),
  ],
};

export default meta;
type Story = StoryObj<DatePickerComponent>;

const helpTitle = 'Help Title';
const helpMessage =
  'This is help message with <a target="_blank" href="https://www.google.com">link </a>';
const helpAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
const helpThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ec_Holding_N.V._logo.svg';
const help: Info = new Info(helpTitle, helpMessage, helpAnimation, helpThumbnail, null);

export const Default: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    ID: 'DatePicker1',
    label: 'Datepicker',
    showHyphenForValues: [null, ''],
    placeholder: 'Datepicker(editable)',
    mode: Modes.READ,
    mouseOverClearButton: true,
    help,
  },
  render: PassCustomControl,
};

export const DatePickerModePrivate: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    ID: 'DatePicker',
    label: 'Datepicker',
    placeholder: 'Datepicker(editable)',
    mode: Modes.PRIVATE,
  },
  render: PassCustomControl,
};

export const DatePickerModeProtected: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    ID: 'DatePicker',
    label: 'Datepicker',
    placeholder: 'Datepicker(editable)',
    mode: Modes.PROTECTED,
  },
  render: PassCustomControl,
};

export const DatePickerWithTimePicker: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    ID: 'DatePicker1',
    label: 'Datepicker',
    showHyphenForValues: [null, ''],
    placeholder: 'Datepicker(editable)',
    mode: Modes.READ,
    type: MatDatePickerTypes.DATE_TIME_PICKER,
    mouseOverClearButton: true,
    help,
  },
  render: PassCustomControl,
};
