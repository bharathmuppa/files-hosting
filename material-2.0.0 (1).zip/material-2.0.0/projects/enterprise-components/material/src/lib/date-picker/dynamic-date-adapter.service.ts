import { Injectable } from '@angular/core';
import { NativeDateAdapter } from '@angular/material/core';
import { MatDatePickerTypes } from './date-picker.component';

@Injectable({
  providedIn: 'root', // Make it available globally if needed
})
export class DynamicDateAdapter extends NativeDateAdapter {
  private startOfWeek: number = 1; // Default to Monday

  setStartOfWeek(day: number): void {
    console.log('set start of week called roi', day);
    if (typeof day === 'number') {
      this.startOfWeek = day;
    }
  }

  getFirstDayOfWeek(): number {
    return this.startOfWeek; // Dynamically use the set value
  }

  format(date: Date, displayFormat: Object): string {
    if (isNaN(date.getTime())) {
      return 'Invalid Date'; // Handle invalid date
    }
    if (displayFormat === MatDatePickerTypes.DATE_TIME_PICKER) {
      return date
        .toLocaleDateString('en-NL', {
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
          hour: 'numeric',
          minute: 'numeric',
          hour12: false,
        })
        .replace(',', '');
    } else if (displayFormat === MatDatePickerTypes.DATE_PICKER) {
      return date
        .toLocaleDateString('en-NL', {
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
        })
        .replace(',', '');
    } else {
      return date.toLocaleDateString('en-NL', {
        year: 'numeric',
        month: 'short',
      });
    }
  }
}
