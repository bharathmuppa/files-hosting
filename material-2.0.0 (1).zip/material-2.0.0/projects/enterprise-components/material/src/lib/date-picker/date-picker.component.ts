import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
  MatNativeDateModule,
} from '@angular/material/core';

import { NgClass } from '@angular/common';
import {
  Component,
  ElementRef,
  EventEmitter,
  input,
  Input,
  OnChanges,
  OnInit,
  Output,
  Renderer2,
  ViewChild,
} from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButton } from '@angular/material/button';
import {
  MatDatepicker,
  MatDatepickerInput,
  MatDatepickerModule,
  MatDatepickerToggle,
  MatDatepickerToggleIcon,
} from '@angular/material/datepicker';
import { MatError, MatFormField, MatLabel, MatSuffix } from '@angular/material/form-field';
import { MatInput } from '@angular/material/input';
import { MatProgressSpinner } from '@angular/material/progress-spinner';
import { MatTooltip } from '@angular/material/tooltip';
import { AALCommonModule, AALUtil, HistoryService, Statuses } from '@enterprise-components/common';
import { ButtonIconComponent } from '../atoms/button-icon/button-icon.component';
import { DividerComponent } from '../atoms/divider/divider.component';
import { DatePickerWeekComponent } from '../date-picker-week/date-picker-week.component';
import { OverlayCardErrorModule } from '../overlay-card-alert/overlay-card-alert.module';
import { OverlayCardHelpModule } from '../overlay-card-help/overlay-card-help.module';
import { CommonMaterialComponentErrorStateMatcher } from '../shared/common-material-component.error-state-matcher';
import { TimePickerComponent } from '../time-picker/time-picker.component';
import { generateMatDateFormats } from './date-picker.utils';
import { DynamicDateAdapter } from './dynamic-date-adapter.service';

export enum MatDatePickerTypes {
  DATE_PICKER = 'DATE_PICKER',
  DATE_TIME_PICKER = 'DATE_TIME_PICKER',
}

export type DateTimePickerType =
  | MatDatePickerTypes.DATE_PICKER
  | MatDatePickerTypes.DATE_TIME_PICKER;

@Component({
  selector: 'aal-date-picker',
  templateUrl: './date-picker.component.html',
  styleUrls: ['./date-picker.component.scss'],
  standalone: true,
  imports: [
    OverlayCardHelpModule,
    MatProgressSpinner,
    MatFormField,
    MatLabel,
    MatInput,
    MatDatepickerInput,
    FormsModule,
    ReactiveFormsModule,
    MatSuffix,
    MatDatepickerToggle,
    MatDatepickerToggleIcon,
    MatDatepicker,
    MatError,
    MatTooltip,
    NgClass,
    AALCommonModule,
    OverlayCardErrorModule,
    TimePickerComponent,

    MatNativeDateModule,
    MatDatepickerModule,
    MatButton,
    DividerComponent,
    ButtonIconComponent,
  ],
  providers: [
    { provide: MAT_DATE_LOCALE, useValue: 'en-GB' }, // Set the locale to English (with Monday as the first day)
    {
      provide: DateAdapter,
      useFactory: () => {
        const adapter = new DynamicDateAdapter();
        adapter.setStartOfWeek(1); // Default to Monday
        return adapter;
      },
    },
    {
      provide: MAT_DATE_FORMATS,
      useFactory: (comp: DatePickerComponent) => {
        if (comp.type() === MatDatePickerTypes.DATE_TIME_PICKER) {
          return generateMatDateFormats(MatDatePickerTypes.DATE_TIME_PICKER);
        }
        return generateMatDateFormats(MatDatePickerTypes.DATE_PICKER);
      },
      deps: [DatePickerComponent],
    },
  ],
})
export class DatePickerComponent extends DatePickerWeekComponent implements OnInit, OnChanges {
  DateTimePickerTypes = MatDatePickerTypes;
  // TODO: Didn't change to signals based input because minDate is from AALDatePickerFormControlComponent
  // Before changing to signals here, we need to change in AALDatePickerFormControlComponent
  @Input()
  minDate: Date;
  // New Signal based input for selecting date picker type, defaults to date picker
  type = input<DateTimePickerType>(MatDatePickerTypes.DATE_PICKER);

  @Output()
  onDatePickerClosed: EventEmitter<void> = new EventEmitter();
  @ViewChild('picker', { static: false }) datepicker: MatDatepicker<any>;
  initialDate: Date;
  errorStateMatcher = new CommonMaterialComponentErrorStateMatcher();
  @ViewChild('inputFieldNoMinDate', { static: false }) inputFieldNoMinDate: ElementRef;
  @ViewChild('inputFieldMinDate', { static: false }) inputFieldMinDate: ElementRef;
  mouseOverClearButton: boolean;
  dateTime: Date = new Date(new Date().setHours(0, 0)); // Default to current date and time
  // For tracking if time picker value is edited/changed
  // so that we can consider the time while setting the date value
  hasDateTimeChanged: boolean = false;

  constructor(renderer: Renderer2, historyService: HistoryService) {
    super(renderer, historyService);
  }

  ngOnInit() {
    super.setDefaultValue();
    // if mindate is set then dateTime should also follow minDate
    if (this.minDate) {
      this.minDate.setHours(0, 0, 0, 0);
      this.dateTime = this.minDate;
    }
  }

  ngOnChanges() {
    if (this.control && this.control.value) {
      this.initialDate = AALUtil.setDateDefaultTime(this.control.value);
    }
  }

  onClick(): void {
    super.setModeToEdit();
    setTimeout(() => {
      if (this.datepicker) {
        this.datepicker.open();
      } else {
        console.error('date-picker.component.ts: datepicker is not available');
      }
    }, 100);
  }

  dateChange(): void {
    if (this.control.value) {
      const date = new Date(this.control.value);
      if (this.hasDateTimeChanged && this.dateTime) {
        date.setHours(this.dateTime.getHours(), this.dateTime.getMinutes());
      }
      // TODO: Check while setting date, we need to consider type parameter, whether it is date time picker or just date picker
      this.control.setValue(AALUtil.getDateTimeInISOFormat(date));
      super.triggerAcceptChanges();
    } else {
      this.datePickerClosed();
    }
  }

  clearDate(): void {
    this.dateTime = new Date(new Date().setHours(0, 0)); // Default to current date and time
    // TODO: Check while setting date, we need to consider type parameter, whether it is date time picker or just date picker
    // Here we don't need that as we are setting empty value
    this.control.setValue('');
    // Here also we need to clear the time
    if (this.control.valid) {
      this.triggerAcceptChanges();
    }
  }

  minDateFilter = (d: Date): boolean => {
    if (d) {
      d.setHours(0, 0, 0, 0);
      if (this.initialDate) {
        return d.getTime() === this.initialDate.getTime() || d.getTime() >= this.minDate.getTime();
      } else {
        return d.getTime() >= this.minDate.getTime();
      }
    }
  };

  onKeyUp(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      this.triggerAcceptChanges();
    } else if (event.key === 'Escape') {
      this.triggerRejectChanges();
    }
  }

  datePickerClosed() {
    if (this.minDate) {
      this.inputFieldMinDate.nativeElement.focus();
    } else {
      this.inputFieldNoMinDate.nativeElement.focus();
    }
    // if we want to reset time everytime the datepicker closed this is the place
    if (this.control.value) {
      this.dateTime = new Date(this.control.value);
    } else {
      this.dateTime = new Date(new Date().setHours(0, 0)); // Default to current date and time
    }
    this.hasDateTimeChanged = false;
    this.onDatePickerClosed.emit();
  }

  onBlur(event) {
    if (
      event &&
      event.relatedTarget &&
      event.relatedTarget.parentElement &&
      event.relatedTarget.parentElement.id &&
      event.relatedTarget.parentElement.id.includes(this.hyphenatedID)
    ) {
      return;
    } else if (this.status === Statuses.DRAFT) {
      this.triggerAcceptChanges();
    }
  }

  toggleMouseover() {
    this.mouseOverClearButton = !this.mouseOverClearButton;
  }

  updateTime(event: any) {
    console.log('update time');
    console.log(event);
  }

  onDateTimeChange(event: any) {
    this.hasDateTimeChanged = true;
  }
}
