import { TestBed } from '@angular/core/testing';

import { NativeDateAdapter } from '@angular/material/core';
import { DynamicDateAdapter } from './dynamic-date-adapter.service';

describe('DynamicDateAdapter', () => {
  let service: DynamicDateAdapter;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DynamicDateAdapter, NativeDateAdapter],
    });
    service = TestBed.inject(DynamicDateAdapter);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should default startOfWeek to Monday (1)', () => {
    // Test the default start of week value
    expect(service.getFirstDayOfWeek()).toBe(1);
  });

  it('should update startOfWeek when setStartOfWeek is called', () => {
    // Call setStartOfWeek with Sunday (0)
    service.setStartOfWeek(0);

    // Test if the startOfWeek is updated to Sunday (0)
    expect(service.getFirstDayOfWeek()).toBe(0);
  });

  it('should update startOfWeek when setStartOfWeek is called with valid values', () => {
    // Call setStartOfWeek with Saturday (6)
    service.setStartOfWeek(6);

    // Test if the startOfWeek is updated to Saturday (6)
    expect(service.getFirstDayOfWeek()).toBe(6);
  });

  it('should not update startOfWeek if setStartOfWeek is called with invalid value', () => {
    // Call setStartOfWeek with an invalid value (like string or null)
    service.setStartOfWeek('invalid' as any);

    // Test that the startOfWeek remains unchanged (Monday = 1)
    expect(service.getFirstDayOfWeek()).toBe(1);
  });

  it('should format date correctly with displayFormat "input" (dd/mm/yyyy hh:mm)', () => {
    const date = new Date('2024-01-25T10:30:00');

    // When displayFormat is 'DATE_TIME_PICKER'
    const formattedDate = service.format(date, 'DATE_TIME_PICKER');

    // Expected format: '25/01/2024 10:30'
    expect(formattedDate).toBe('25/01/2024 10:30');
  });

  it('should format date correctly with displayFormat other than "input" (month-year)', () => {
    const date = new Date('2024-01-25T10:30:00');

    // When displayFormat is not 'DATE_TIME_PICKER' (it defaults to month-year formatting)
    const formattedDate = service.format(date, 'other');

    // Expected format: 'Jan 2024'
    expect(formattedDate).toBe('Jan 2024');
  });

  it('should handle different date formats correctly for different input', () => {
    const date = new Date('2024-12-25T08:15:00');

    // When displayFormat is 'DATE_TIME_PICKER'
    const formattedDate = service.format(date, 'DATE_TIME_PICKER');

    // Expected format: '25/12/2024 08:15'
    expect(formattedDate).toBe('25/12/2024 08:15');

    // When displayFormat is 'other' (month-year)
    const formattedMonthYear = service.format(date, 'other');

    // Expected format: 'Dec 2024'
    expect(formattedMonthYear).toBe('Dec 2024');
  });

  it('should handle invalid date gracefully', () => {
    const invalidDate = new Date('invalid-date');

    // Check if the format method returns 'Invalid Date' when an invalid date is provided
    const formattedDate = service.format(invalidDate, 'DATE_TIME_PICKER');
    expect(formattedDate).toBe('Invalid Date'); // Invalid date should result in 'Invalid Date'

    const formattedMonthYear = service.format(invalidDate, 'other');
    expect(formattedMonthYear).toBe('Invalid Date'); // Invalid date should result in 'Invalid Date'
  });
});
