import { Info } from '@enterprise-components/common';

export class ListItemConfiguration {
  ID: string;
  title: string;
  mainDescription: string;
  line1: string;
  line2: any;
  icon?: string;
  imageURL?: string;
  svgIcon?: string;
  isClickable: boolean;
  help?: Info;
  error?: Info;
  actionButtonConfiguration: ActionButtonConfiguration;
}

export class ExpansionPanelItemConfiguration {
  ID: string;
  title: string;
  mainDescription: any;
  line1: any;
  line1Caption: string;
  line2: any;
  icon: string;
  imageURL: string;
  svgIcon: string;
  isClickable: boolean;
  help: Info;
  error: Info;
  isBusy: boolean;
  showActionButtonOnFocus: boolean;
  actionButtonConfiguration: ActionButtonConfiguration;
}

export class ActionButtonConfiguration {
  actionButtonIcon: string;
  actionButtonText: string;
  actionButtonType: string;
  actionButtonTooltip: string;
  showActionButton: boolean;
  action: string;
  hasBadge?: boolean;
  badgeData?: number;
  referenceBadgeData?: number;
  badgeType?: string;
  actionButtonData?: OverlayCardData[];
}

export class EmptyStateData {
  title: string;
  subTitle?: string;
  description?: string;
  icon?: string;
  imageURL?: string;
  svgIcon?: string;
}

export class OverlayCardData {
  ID: string;
  title: string;
  mainDescription: any;
  subDescription: any;
  icon: string;
  isClickable: boolean;
  actionButtonConfiguration: ActionButtonConfiguration;
}
