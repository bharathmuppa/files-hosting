import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { EmptyStateComponent } from '../empty-state/empty-state.component';
import { ListItemComponent } from '../list-item/list-item.component';
import { OverlayCardErrorModule } from '../overlay-card-alert/overlay-card-alert.module';
import { OverlayCardHelpModule } from '../overlay-card-help/overlay-card-help.module';
import { ExpansionPanelListComponent } from './expansion-panel-list.component';

@NgModule({
  imports: [
    CommonModule,
    ListItemComponent,
    EmptyStateComponent,
    OverlayCardHelpModule,
    OverlayCardErrorModule,
    MatButtonModule,
    MatExpansionModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    ExpansionPanelListComponent,
  ],
  exports: [ExpansionPanelListComponent],
})
export class ExpansionPanelListModule {}
