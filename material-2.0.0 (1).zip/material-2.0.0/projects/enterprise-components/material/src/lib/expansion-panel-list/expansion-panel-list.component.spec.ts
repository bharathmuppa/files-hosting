import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Info } from '@enterprise-components/common';
import { EmptyStateComponent } from '../empty-state/empty-state.component';
import { ListItemToolbarComponent } from '../list-item-toolbar/list-item-toolbar.component';
import { ActionEventData } from '../list-item/list-item.component';
import { SharedFormModule } from '../shared/shared-form.module';
import { SharedMaterialModule } from '../shared/shared-material.module';
import { SharedModule } from '../shared/shared.module';
import { ExpansionPanelListComponent } from './expansion-panel-list.component';
import {
  ActionButtonConfiguration,
  ExpansionPanelItemConfiguration,
} from './expansion-panel-list.model';

describe('ExpansionPanelListComponent', () => {
  let component: ExpansionPanelListComponent;
  let fixture: ComponentFixture<ExpansionPanelListComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        SharedMaterialModule,
        SharedFormModule,
        SharedModule,
        ListItemToolbarComponent,
        EmptyStateComponent,
        BrowserAnimationsModule,
        ExpansionPanelListComponent,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExpansionPanelListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should set initial values on component initiation', () => {
    component.help = 'help text';
    const value = new Info('Sample Title', 'Sample Help Message', '', '', null);
    component.expansionPanelItemConfigurationList = [
      {
        ID: 'ID1',
        title: 'title1',
        mainDescription: 'item main description1',
        line1: 'item sub description1',
        icon: 'group',
        isClickable: true,
        isBusy: true,
        help: new Info('some item level help'),
        showActionButtonOnFocus: true,
        actionButtonConfiguration: {
          actionButtonIcon: 'delete',
          actionButtonText: 'buttonText1',
          actionButtonType: 'icon',
          actionButtonTooltip: 'action button tooltip1',
          showActionButton: true,
          action: 'delete',
        } as ActionButtonConfiguration,
      } as ExpansionPanelItemConfiguration,
    ];
    component.ngOnInit();
    expect(typeof component.help).toBe(typeof value);
    component.hasAnyItemHelp = component.hasAnyItemHelpText();
    expect(component.hasAnyItemHelp).toBeTruthy();
  });
  it('should emit on click of button', () => {
    spyOn(component.actionSubmit, 'emit');
    const actionEventData: ActionEventData = { ID: '', action: '' };
    component.onActionSubmit(actionEventData);
    fixture.detectChanges();
    expect(component.actionSubmit.emit).toHaveBeenCalled();
  });
  it('should emit on click of add item', () => {
    spyOn(component.addItem, 'emit');
    const event = new MouseEvent('click');
    component.addItemClick(event);
    fixture.detectChanges();
    expect(component.addItem.emit).toHaveBeenCalled();
  });
  it('should emit on click of specific item', () => {
    spyOn(component.itemClick, 'emit');
    const event = new MouseEvent('click');
    component.onItemClick('');
    fixture.detectChanges();
    expect(component.itemClick.emit).toHaveBeenCalled();
  });

  it('should match object error info onInIt', () => {
    component.error = 'test error string';
    component.ngOnInit();
    expect(component.error).toEqual(
      jasmine.objectContaining({
        message: 'test error string',
      }),
    );
  });
});
