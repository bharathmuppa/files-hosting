import { Component, EventEmitter, Input, OnInit, Output, TemplateRef } from '@angular/core';
import { MatIconButton } from '@angular/material/button';
import {
  MatExpansionPanel,
  MatExpansionPanelHeader,
  MatExpansionPanelTitle,
} from '@angular/material/expansion';
import { MatIcon } from '@angular/material/icon';
import { MatProgressSpinner } from '@angular/material/progress-spinner';
import { MatTooltip } from '@angular/material/tooltip';
import { Info } from '@enterprise-components/common';
import { EmptyStateComponent } from '../empty-state/empty-state.component';
import { ActionEventData, ListItemComponent } from '../list-item/list-item.component';
import { OverlayCardAlertComponent } from '../overlay-card-alert/overlay-card-alert.component';
import { OverlayCardHelpComponent } from '../overlay-card-help/overlay-card-help.component';
import { EmptyStateData, ExpansionPanelItemConfiguration } from './expansion-panel-list.model';

@Component({
  selector: 'aal-expansion-panel-list',
  templateUrl: './expansion-panel-list.component.html',
  styleUrls: ['./expansion-panel-list.component.scss'],
  standalone: true,
  imports: [
    MatExpansionPanel,
    MatExpansionPanelHeader,
    MatExpansionPanelTitle,

    OverlayCardHelpComponent,
    MatProgressSpinner,
    OverlayCardAlertComponent,
    MatTooltip,
    MatIconButton,
    MatIcon,
    ListItemComponent,
    EmptyStateComponent,
  ],
})
export class ExpansionPanelListComponent implements OnInit {
  @Input()
  expansionPanelItemConfigurationList: ExpansionPanelItemConfiguration[];
  @Input()
  defaultItemIcon: string;
  @Input()
  defaultItemImageURL: string;
  @Input()
  defaultSvgIcon: string;
  @Input()
  help: Info | string;
  @Input()
  error: Info | string;
  @Input()
  header: string;
  @Input()
  showAddButton: boolean;
  @Input()
  addButtonTooltip: string;
  @Input()
  disableAddButton: boolean;
  @Input()
  isExpanded: boolean;
  @Input()
  isBusy: boolean;
  @Input()
  emptyStateData: EmptyStateData;
  @Input()
  titleTemplateRef: TemplateRef<any>;
  @Input()
  mainDescriptionTemplateRef: TemplateRef<any>;
  @Input()
  subDescriptionTemplateRef: TemplateRef<any>;
  @Input()
  imageDisplayRef: TemplateRef<any>;
  @Input()
  fontSize: string;
  @Input()
  hideHelp: boolean;
  @Output()
  addItem: EventEmitter<void> = new EventEmitter<void>();
  @Output()
  actionSubmit: EventEmitter<ActionEventData> = new EventEmitter<ActionEventData>();
  @Output()
  itemClick: EventEmitter<string> = new EventEmitter<string>();
  hasAnyItemHelp: boolean;

  ngOnInit() {
    if (this.help && typeof this.help === 'string') {
      this.help = new Info(this.help);
    }
    if (this.error && typeof this.error === 'string') {
      this.error = new Info(this.error);
    }
    this.hasAnyItemHelp = this.hasAnyItemHelpText();
  }

  hasAnyItemHelpText(): boolean {
    if (
      this.expansionPanelItemConfigurationList &&
      this.expansionPanelItemConfigurationList.length > 0
    ) {
      for (const item of this.expansionPanelItemConfigurationList) {
        if (item.help) {
          return true;
        }
      }
    }
    return false;
  }

  onActionSubmit(actionEventData: ActionEventData): void {
    this.actionSubmit.emit(actionEventData);
  }

  addItemClick($event): void {
    this.addItem.emit();
    $event.stopPropagation();
  }

  onItemClick(itemId: string): void {
    this.itemClick.emit(itemId);
  }
}
