/*
 * Public API Surface of material
 */

export * from './card-summary.component';
export * from './card-summary.module';
