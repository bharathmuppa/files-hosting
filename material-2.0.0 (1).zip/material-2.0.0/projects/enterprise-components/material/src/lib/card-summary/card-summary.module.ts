import { NgModule } from '@angular/core';
import { CardSummaryComponent } from './card-summary.component';

@NgModule({
  imports: [CardSummaryComponent],
  exports: [CardSummaryComponent],
})
export class CardSummaryModule {}
