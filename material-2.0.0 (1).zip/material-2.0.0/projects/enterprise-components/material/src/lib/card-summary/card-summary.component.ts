import { NgClass, NgTemplateOutlet } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output, TemplateRef } from '@angular/core';
import { MatButton } from '@angular/material/button';
import { MatTooltip } from '@angular/material/tooltip';
import { AALFixedInputFormControlComponent } from '@enterprise-components/common';
import { AALCommonModule } from '../common/common.module';
import { ListItemConfiguration, Separators } from '../shared/list-item-configuration.model';

@Component({
  selector: 'aal-card-summary',
  templateUrl: './card-summary.component.html',
  styleUrls: ['./card-summary.component.scss'],
  standalone: true,
  imports: [NgTemplateOutlet, NgClass, AALCommonModule, MatTooltip, MatButton],
})
export class CardSummaryComponent extends AALFixedInputFormControlComponent implements OnInit {
  @Input()
  item: ListItemConfiguration;
  @Input()
  labelCaption: string;
  @Input()
  separator: string;
  @Input()
  mainDescription: string;
  @Input()
  mainDescriptionCaption: string;
  @Input()
  mainDescriptionLink: string;
  @Input()
  line1: string;
  @Input()
  line1Caption: string;
  @Input()
  line2: string;
  @Input()
  line2Caption: string;
  @Input()
  line3: string;
  @Input()
  line3Caption: string;
  @Input()
  addIconBorder: boolean;
  @Input()
  isMainDescriptionHTML: boolean;
  @Input()
  fallbackImageURL: string;
  @Input()
  wordWrapApplicable: boolean;
  @Output()
  readonly mainDescriptionClick: EventEmitter<string> = new EventEmitter<string>();
  @Input()
  iconImageTemplateRef: TemplateRef<any>;
  @Input()
  actionTemplateRef: TemplateRef<any>;
  @Input()
  labelTemplateRefr: TemplateRef<any>;
  @Input()
  mainDescriptionTemplateRefr: TemplateRef<any>;
  @Input()
  line1TemplateRefr: TemplateRef<any>;
  @Input()
  line2TemplateRefr: TemplateRef<any>;
  @Input()
  line3TemplateRefr: TemplateRef<any>;
  @Input()
  showActionButtonOnFocus: boolean;
  @Input()
  hideToolTip: boolean;
  @Input()
  isMandatoryField: boolean;
  separators = Separators;
  imageURL: string;
  hasFocus: boolean;

  ngOnInit(): void {
    this.isMainDescriptionHTML = !!this.isMainDescriptionHTML;
  }

  onLabelClick(label: string) {
    this.mainDescriptionClick.emit(label);
  }
}
