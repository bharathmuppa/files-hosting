import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { UntypedFormControl, Validators } from '@angular/forms';
import { AALInputFormControlComponent } from '@enterprise-components/common';

import { AALInputNumberComponent } from './input-number.component';
import createSpyObj = jasmine.createSpyObj;

describe('AALInputNumberComponent', () => {
  let component: AALInputNumberComponent;
  let fixture: ComponentFixture<AALInputNumberComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [AALInputNumberComponent],
    })
      .compileComponents()
      .then(() => {});
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALInputNumberComponent);
    component = fixture.componentInstance;

    // Default control
    component.control = new UntypedFormControl('actualVal', Validators.compose([]));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // -----------------------------------------------------------
  // 1) CUSTOM VALIDATION PATTERN
  // -----------------------------------------------------------
  it('should initialize regex when we have input pattern', () => {
    component.validationPattern = '^d{1,5}$';
    component.ngOnInit();
    expect(component.regex).toEqual(/^d{1,5}$/);
  });

  it('should not initialize validation regex when there is no input pattern', () => {
    // i.e. uses the default pattern logic
    component.validationPattern = '';
    // fractionDigits=0 & allowNegative=true => ^-?(?:[1-9]\d*|0)$
    component.fractionDigits = 0;
    component.allowNegative = true;
    component.ngOnInit();
    expect(component.regex).toEqual(new RegExp('^-?(?:[1-9]\\d*|0)$'));
  });

  // -----------------------------------------------------------
  // 2) FRACTION DIGITS + NEGATIVE/POSITIVE => DEFAULT PATTERNS
  // -----------------------------------------------------------

  it('should initialize regex for fractionDigits=2, allowNegative=true', () => {
    component.validationPattern = ''; // ensure we use the default pattern
    component.fractionDigits = 2;
    component.allowNegative = true;
    component.ngOnInit();
    // e.g. ^-?(?:[1-9]\d*(\.\d{0,2})?|0(\.\d{0,2})?)$
    expect(component.regex).toEqual(new RegExp('^-?(?:[1-9]\\d*(\\.\\d{0,2})?|0(\\.\\d{0,2})?)$'));
  });

  it('should initialize regex for fractionDigits=2, allowNegative=false', () => {
    component.validationPattern = '';
    component.fractionDigits = 2;
    component.allowNegative = false;
    component.ngOnInit();
    // e.g. ^(?:[1-9]\d*(\.\d{0,2})?|0(\.\d{0,2})?)$
    expect(component.regex).toEqual(new RegExp('^(?:[1-9]\\d*(\\.\\d{0,2})?|0(\\.\\d{0,2})?)$'));
  });

  it('should initialize regex for fractionDigits=0, allowNegative=true', () => {
    component.validationPattern = '';
    component.fractionDigits = 0;
    component.allowNegative = true;
    component.ngOnInit();
    // e.g. ^-?(?:[1-9]\d*|0)$
    expect(component.regex).toEqual(new RegExp('^-?(?:[1-9]\\d*|0)$'));
  });

  it('should initialize regex for fractionDigits=0, allowNegative=false', () => {
    component.validationPattern = '';
    component.fractionDigits = 0;
    component.allowNegative = false;
    component.ngOnInit();
    // e.g. ^(?:[1-9]\d*|0)$
    expect(component.regex).toEqual(new RegExp('^(?:[1-9]\\d*|0)$'));
  });

  // -----------------------------------------------------------
  // 3) VALIDATION MESSAGES
  // -----------------------------------------------------------

  xit('should be able to get validation messages when no fractions and negative numbers', () => {
    component.fractionDigits = 0;
    component.allowNegative = true;
    const validatorMessage = component.getValidatorMessage('PATTERN');
    expect(validatorMessage).toBe('Use Only Numbers');
  });

  xit('should be able to get validation messages when no fractions and positive', () => {
    component.fractionDigits = 0;
    component.allowNegative = false;
    const validatorMessage = component.getValidatorMessage('PATTERN');
    expect(validatorMessage).toBe('Use Only Numbers');
  });

  xit('should be able to get validation messages when fractions and negative', () => {
    component.fractionDigits = 2;
    component.allowNegative = true;
    const validatorMessage = component.getValidatorMessage('PATTERN');
    expect(validatorMessage).toBe('Use Only Numbers (And One Dot)');
  });

  xit('should be able to get validation messages when fractions and positive', () => {
    component.fractionDigits = 2;
    component.allowNegative = false;
    const validatorMessage = component.getValidatorMessage('PATTERN');
    expect(validatorMessage).toBe('Use Only Numbers (And One Dot)');
  });

  it('should be able to get custom validation messages when fractions and positive are set', () => {
    component.fractionDigits = 2;
    component.allowNegative = false;
    component.customValidationMessage = 'In-Valid Number enter';
    const validatorMessage = component.getValidatorMessage('PATTERN');
    expect(validatorMessage).toBe('In-Valid Number enter');
  });

  it('should be able to get validation messages from super class', () => {
    component.fractionDigits = 2;
    component.allowNegative = false;
    spyOn(AALInputFormControlComponent.prototype, 'getValidatorMessage').and.returnValue('Sample');
    const validatorMessage = component.getValidatorMessage('');
    expect(validatorMessage).toContain('Sample');
  });

  // -----------------------------------------------------------
  // 4) BLUR / ACCEPT CHANGES
  // -----------------------------------------------------------

  it('should call (onBlur) function', () => {
    spyOn(AALInputFormControlComponent.prototype, 'onBlur');
    component.control = new UntypedFormControl('', Validators.required);
    const event = createSpyObj('relatedTarget', ['mat-option']);
    component.onBlur(new Event(event));
    expect(AALInputFormControlComponent.prototype.onBlur).toHaveBeenCalled();
  });

  it('should call triggerAcceptChanges of super Component', () => {
    spyOn(AALInputFormControlComponent.prototype, 'triggerAcceptChanges').and.callThrough();
    component.control.setValue('1234');
    component.triggerAcceptChanges();
    expect(AALInputFormControlComponent.prototype.triggerAcceptChanges).toHaveBeenCalled();
  });

  it('should return nothing when value is set from history', () => {
    component.control = new UntypedFormControl('sample data', Validators.required);
    const matOption = document.createElement('mat-option');
    matOption.classList.add('mat-select');
    const event = new FocusEvent('focus', { relatedTarget: matOption });
    const returnValue = component.onBlur(event);
    expect(returnValue).toBe(undefined);
  });

  // -----------------------------------------------------------
  // 5) KEYDOWN LOGIC
  // -----------------------------------------------------------
  xit('should not allow disallowed keys', () => {
    component.control = new UntypedFormControl('', Validators.required);
    const event = new KeyboardEvent('keydown', {
      key: 'e',
    });
    // spy on event.preventDefault or expect the default not changed
    spyOn(event, 'preventDefault').and.callThrough();
    component.onKeyDown(event);
    // the default pattern blocks 'e', so we expect preventDefault to be called
    expect(event.preventDefault).toHaveBeenCalled();
    // control.value remains ''
    expect(component.control.value).toEqual('');
  });

  it('should call super onBlur function when disableAcceptChangesOnBlur is set to false', () => {
    spyOn(AALInputFormControlComponent.prototype, 'onBlur');
    component.control = new UntypedFormControl('', Validators.required);
    component.disableAcceptChangesOnBlur = false;
    const event = createSpyObj('relatedTarget', ['']);
    component.onBlur(new Event(event));
    expect(AALInputFormControlComponent.prototype.onBlur).toHaveBeenCalled();
  });
});
