import { AsyncPipe, CommonModule, NgClass } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import {
  AbstractControl,
  ReactiveFormsModule,
  ValidationErrors,
  ValidatorFn,
  Validators,
} from '@angular/forms';
import { MatAutocomplete, MatAutocompleteTrigger, MatOption } from '@angular/material/autocomplete';
import {
  MatFormField,
  MatFormFieldModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
} from '@angular/material/form-field';
import { MatInput } from '@angular/material/input';
import { MatProgressSpinner } from '@angular/material/progress-spinner';
import { MatTooltip } from '@angular/material/tooltip';

import {
  AALCommonModule,
  AALInputFormControlComponent,
  HistoryService,
} from '@enterprise-components/common';

import { IconComponent } from '../atoms/icon/icon.component';
import { OverlayCardErrorModule } from '../overlay-card-alert/overlay-card-alert.module';
import { OverlayCardHelpModule } from '../overlay-card-help/overlay-card-help.module';
import { CommonMaterialComponentErrorStateMatcher } from '../shared/common-material-component.error-state-matcher';
import { ToolbarConfirmModule } from '../toolbar-confirm/toolbar-confirm.module';

/**
 * AALInputNumberComponent
 * -----------------------
 * A specialized numeric input component with configurable validations:
 *
 * 1. **allowNegative**: Allows negative numbers if set to `true`.
 * 2. **allowSpecialCharacters**: Allows all typed special characters if `true`.
 *    Otherwise, keys like `+`, `-`, `e`, etc. are blocked on keydown.
 * 3. **fractionDigits**: Number of decimal digits allowed. If `0`, no decimals are permitted.
 * 4. **minValue** / **maxValue**: Validation range for numeric input.
 * 5. **maxLength**: Maximum number of characters allowed in the field.
 * 6. **Disallow leading zeros**: By default, leading zeros are not permitted (except a single `0`).
 * 7. **No alphabetic characters**: Letters are disallowed.
 * 8. **No spaces**: Disallowed in numeric input.
 * 9. **prefix / suffix**: Display optional prefix and suffix in the Material form field.
 * 10. **disableAcceptChangesOnBlur**: If `true`, changes are not accepted automatically when the input loses focus (useful when a confirmation toolbar is present).
 * 11. **customValidationMessage**: Custom message for pattern or other validator errors.
 *
 * This component extends `AALInputFormControlComponent` to inherit common input behaviors.
 */
@Component({
  selector: 'aal-input-number',
  templateUrl: './input-number.component.html',
  styleUrls: ['./input-number.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    AsyncPipe,
    NgClass,
    MatFormField,
    MatInput,
    MatAutocompleteTrigger,
    MatAutocomplete,
    MatOption,
    MatProgressSpinner,
    MatTooltip,
    OverlayCardHelpModule,
    ToolbarConfirmModule,
    AALCommonModule,
    OverlayCardErrorModule,
    MatPrefix,
    MatSuffix,
    MatLabel,
    MatFormFieldModule,
    IconComponent,
  ],
})
export class AALInputNumberComponent extends AALInputFormControlComponent implements OnInit {
  /**
   * If `true`, all special characters are allowed in `keydown`.
   */
  @Input() allowSpecialCharacters: boolean = false;

  /**
   * If `true`, negative numbers are allowed.
   */
  @Input() allowNegative: boolean = true;

  /**
   * Override default error messages (e.g., 'pattern') if needed.
   */
  @Input() customValidationMessage: string;

  /**
   * If `true`, changes are not accepted on blur automatically.
   */
  @Input() disableAcceptChangesOnBlur: boolean;

  /**
   * Number of digits allowed after the decimal. e.g., `2` => up to 2 decimal places.
   */
  @Input() fractionDigits: number = 0;

  /**
   * If `true`, hides error messages in the template.
   */
  @Input() hideError: boolean = false;

  /**
   * Optional prefix for the input (e.g., `$`, `%`).
   */
  @Input() prefix: string;

  /**
   * Optional suffix for the input (e.g., `USD`, `kg`).
   */
  @Input() suffix: string;

  /**
   * Maximum length of the entire field (including minus sign & decimal).
   */
  @Input() maxLength: number = 16;

  /**
   * Minimum numeric value, e.g., `0` => cannot go negative.
   */
  @Input() minValue: number;

  /**
   * Maximum numeric value, e.g., `100`.
   */
  @Input() maxValue: number;

  /**
   * Internal RegExp for pattern validation.
   */
  regex: RegExp;

  /**
   * Error matcher for Material state management.
   */
  errorStateMatcher = new CommonMaterialComponentErrorStateMatcher();

  /**
   * If set, overrides the default numeric patterns for validation.
   */
  private validationRegex: string;

  /**
   * Disallowed characters if `allowSpecialCharacters=false`.
   */
  invalidChars: string[] = [];

  constructor(historyService: HistoryService) {
    super(historyService);
  }

  /**
   * Initialize the component (build pattern, validators, etc.).
   */
  ngOnInit(): void {
    // 1) Build the default RegExp if a custom pattern isn't given
    if (!this.validationRegex) {
      this.regex = this.buildDefaultPattern();
    } else {
      this.regex = new RegExp(this.validationRegex);
    }

    // 2) Setup invalid characters
    this.setupInvalidChars();

    // 3) Call parent ngOnInit
    super.ngOnInit();

    // 4) Apply Angular validators (pattern, min, max, etc.)
    this.setupValidatorsOnControl();
  }

  /**
   * Allows dynamic pattern override.
   */
  @Input()
  set validationPattern(value: string) {
    if (value) {
      this.validationRegex = value;
      this.regex = new RegExp(value);
    }
  }

  /**
   * Returns a validator message for a given key.
   */
  getValidatorMessage(validatorKey: string): string {
    if (this.customValidationMessage) {
      return this.customValidationMessage;
    }

    switch (validatorKey.toLowerCase()) {
      case 'pattern':
        if (this.fractionDigits === 0) {
          return 'Use only numbers (no decimal).';
        }
        return `Use only valid number format with up to ${this.fractionDigits} decimal places.`;
      case 'required':
        return 'This field cannot be empty.';
      case 'min':
        return `Value must be >= ${this.minValue}.`;
      case 'max':
        return `Value must be <= ${this.maxValue}.`;
      case 'leadingzero':
        return `Leading zeros are not allowed (except '0').`;
      case 'maxlength':
        return `Input cannot exceed ${this.maxLength} characters.`;
      default:
        return super.getValidatorMessage(validatorKey);
    }
  }

  /**
   * If not disabled, accept changes on blur (unless skipping due to special blur targets).
   */
  onBlur($event?: Event): void {
    if (
      $event instanceof FocusEvent &&
      $event.relatedTarget &&
      ($event.relatedTarget['classList']?.contains('mat-select') ||
        $event.relatedTarget['id']?.includes(this.hyphenatedID) ||
        $event.relatedTarget['parentElement']?.classList?.contains('skip-input-blur-event'))
    ) {
      return; // skip if user is moving to an element that keeps focus within
    }

    const isAcceptChangesNotNeeded =
      !this.confirmToolBarNotApplicable && this.disableAcceptChangesOnBlur;

    if (!isAcceptChangesNotNeeded) {
      super.onBlur($event);
    }
  }

  /**
   * Explicitly accept changes, if needed.
   */
  triggerAcceptChanges(): void {
    super.triggerAcceptChanges();
  }

  /**
   * Keydown logic:
   * - Blocks disallowed chars
   * - Unifies numpad digits => normal digits
   * - Unifies ',' => '.'
   * - Enforces fraction digit limit
   * - Disallows multiple decimals
   * - Manages minus sign usage
   * - Enforces maxLength
   */
  onKeyDown(event: KeyboardEvent): void {
    const inputElement = event.target as HTMLInputElement;
    const currentValue = inputElement.value || '';

    // 1) Allow navigation/control keys (like Backspace, Delete, Arrow keys, etc.)
    //    We'll also specifically handle 'Backspace' to remove from the end.
    const allowedControlKeys = new Set([
      'ArrowLeft',
      'ArrowRight',
      'ArrowUp',
      'ArrowDown',
      'Tab',
      'Home',
      'End',
      'Escape',
      'Enter', // optional
    ]);
    if (allowedControlKeys.has(event.key)) {
      return; // Let these keys pass without blocking
    }

    // 2) Special case: backspace => remove last char (if any)
    //    (You could handle 'Delete' similarly if you want it to also remove last char from end.)
    if (event.key === 'Backspace') {
      // Remove the last character from currentValue
      const newValue = currentValue.slice(0, -1);
      // Then check if newValue is valid or not:
      // Typically we'd just let them remove the character, so we won't block backspace
      // unless you want to handle some custom logic here.
      return; // let the backspace proceed
    }

    // 3) Unify SHIFT + '.' => '>' => '.' on some keyboards
    //    (If SHIFT + '.' yields '>', unify it so they can type a decimal.)
    let typedChar = event.key;
    if (typedChar === '>' && event.code === 'Period' && event.shiftKey) {
      typedChar = '.';
    }

    // 4) Convert numeric keypad digits and decimal
    if (/^Numpad[0-9]$/.test(event.code)) {
      typedChar = event.code.replace('Numpad', ''); // e.g. 'Numpad1' => '1'
    } else if (event.code === 'NumpadDecimal') {
      typedChar = '.';
    }

    // 5) If fractionDigits > 0, allow '.' and ','; unify ',' => '.'
    if (typedChar === ',' && this.fractionDigits > 0) {
      typedChar = '.';
    }

    // 6) Build the prospective newValue by appending typedChar at the end
    const newValue = currentValue + typedChar;

    // 7) Validate newValue against your numeric rules

    // a) If fractionDigits=0 => block decimals
    if (this.fractionDigits === 0 && typedChar === '.') {
      event.preventDefault();
      return;
    }

    // b) No multiple decimals if fractionDigits>0
    if (typedChar === '.') {
      const dotCount = (newValue.match(/\./g) || []).length;
      if (dotCount > 1) {
        event.preventDefault();
        return;
      }
    }

    // c) Enforce fraction digit limit
    if (this.fractionDigits > 0) {
      const [intPart, fracPart = ''] = newValue.replace('-', '').split('.');
      if (fracPart.length > this.fractionDigits) {
        event.preventDefault();
        return;
      }
    }

    // d) Enforce negative sign only if the field is empty or you want multiple rules
    if (typedChar === '-') {
      // If negative not allowed => block
      if (!this.allowNegative) {
        event.preventDefault();
        return;
      }
      // If there's already content, block unless you specifically allow
      // e.g., only at the very start
      if (currentValue.length > 0) {
        event.preventDefault();
        return;
      }
    }

    // e) Enforce numeric digits only, unless decimal or minus is allowed
    //    So typedChar must be 0-9, '.' (if fractionDigits>0), or '-'
    const validDigits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    let validChars = [...validDigits];
    if (this.fractionDigits > 0) {
      validChars.push('.');
    }
    if (this.allowNegative) {
      validChars.push('-');
    }
    // If special chars not allowed
    if (!this.allowSpecialCharacters && !validChars.includes(typedChar)) {
      event.preventDefault();
      return;
    }

    // f) Enforce maxLength
    if (newValue.length > this.maxLength) {
      event.preventDefault();
      return;
    }

    // If you pass all checks, the typedChar is appended to the end of currentValue.
    // No caret or selection logic is used. The user cannot insert in the middle or highlight text.
  }

  // --------------------------------------------------------------------------
  // INTERNAL SETUP METHODS
  // --------------------------------------------------------------------------

  /**
   * Build a default regex pattern that allows 0..fractionDigits if decimal is present.
   * e.g., fractionDigits=2 => either integer or integer + . + up to 2 digits
   */
  private buildDefaultPattern(): RegExp {
    if (this.fractionDigits === 0) {
      // integers only
      // e.g., if allowNegative => ^-?(?:[1-9]\d*|0)$
      // else => ^(?:[1-9]\d*|0)$
      const signPart = this.allowNegative ? '-?' : '';
      return new RegExp(`^${signPart}(?:[1-9]\\d*|0)$`);
    } else {
      // e.g., fractionDigits=2 => ^-?(?:[1-9]\d*(\.\d{0,2})?|0(\.\d{0,2})?)$
      // This lets the user type "123." (with zero digits after the decimal) OR "123.45"
      const signPart = this.allowNegative ? '-?' : '';
      return new RegExp(
        `^${signPart}(?:[1-9]\\d*(\\.\\d{0,${this.fractionDigits}})?|0(\\.\\d{0,${this.fractionDigits}})?)$`,
      );
    }
  }

  /**
   * Setup invalidChars if `allowSpecialCharacters=false`.
   */
  private setupInvalidChars(): void {
    const baseInvalid = [
      ' ', // no spaces
      'e',
      'E',
      '+',
      '*',
      '/',
      '\\',
      '(',
      ')',
      '[',
      ']',
      '{',
      '}',
      '!',
      '@',
      '#',
      '$',
      '%',
      '^',
      '&',
      '_',
      '=',
      '?',
      ':',
      ';',
      '"',
      "'",
      '`',
      '~',
      '|',
      '<',
      '>', // etc. (extend if needed)
    ];

    // If fractionDigits=0 => '.' is invalid
    if (this.fractionDigits === 0) {
      baseInvalid.push('.');
    }
    // If negative not allowed => '-' is invalid
    if (!this.allowNegative) {
      baseInvalid.push('-');
    }
    // Block alphabets
    for (let i = 0; i < 26; i++) {
      baseInvalid.push(String.fromCharCode(65 + i)); // A-Z
      baseInvalid.push(String.fromCharCode(97 + i)); // a-z
    }
    this.invalidChars = baseInvalid;
  }

  /**
   * Setup validators: pattern, min, max, maxLength, leading zero, etc.
   */
  private setupValidatorsOnControl(): void {
    const validators: ValidatorFn[] = [];

    // Inherit any existing validators
    const existingValidator = this.control?.validator;
    if (existingValidator) {
      validators.push(existingValidator);
    }

    // If 'required' is indicated, enforce it
    if (this.hasRequiredValidator()) {
      validators.push(Validators.required);
    }

    // 1) Pattern validator
    validators.push(Validators.pattern(this.regex));

    // 2) Min / max numeric
    if (this.minValue !== null && this.minValue !== undefined) {
      validators.push(Validators.min(this.minValue));
    }
    if (this.maxValue !== null && this.maxValue !== undefined) {
      validators.push(Validators.max(this.maxValue));
    }

    // 3) maxLength => built-in Angular validator
    if (this.maxLength > 0) {
      validators.push(Validators.maxLength(this.maxLength));
    }

    // 4) Leading zero validator
    validators.push(this.noLeadingZeroValidator(this.allowNegative, this.fractionDigits));

    this.control.setValidators(validators);
    this.control.updateValueAndValidity();
  }

  /**
   * Disallows leading zeros in multi-digit numbers (e.g. '01', '007.12') but allows single '0' or '0.xxx'.
   */
  private noLeadingZeroValidator(allowNegative: boolean, fractionDigits: number): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      if (!control.value) return null;

      const valueStr = String(control.value);
      const signRemoved = valueStr.startsWith('-') ? valueStr.slice(1) : valueStr;
      const [integerPart] = signRemoved.split('.');

      // If integerPart has more than 1 digit and starts with '0', invalid
      if (integerPart.length > 1 && integerPart.startsWith('0')) {
        return { leadingZero: true };
      }
      return null;
    };
  }
}
