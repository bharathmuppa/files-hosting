import { NgModule } from '@angular/core';
import { AALInputNumberComponent } from './input-number.component';

@NgModule({
  imports: [AALInputNumberComponent],
  exports: [AALInputNumberComponent],
})
export class AALInputNumberModule {}
