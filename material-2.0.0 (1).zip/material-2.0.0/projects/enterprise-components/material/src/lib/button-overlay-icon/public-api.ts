/*
 * Public API Surface of material
 */

export * from './button-overlay-icon.component';
export * from './button-overlay-icon.module';
