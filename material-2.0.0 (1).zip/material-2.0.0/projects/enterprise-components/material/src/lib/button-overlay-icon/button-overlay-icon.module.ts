import { NgModule } from '@angular/core';
import { ButtonOverlayIconComponent } from './button-overlay-icon.component';

@NgModule({
  imports: [ButtonOverlayIconComponent],
  exports: [ButtonOverlayIconComponent],
})
export class ButtonOverlayIconModule {}
