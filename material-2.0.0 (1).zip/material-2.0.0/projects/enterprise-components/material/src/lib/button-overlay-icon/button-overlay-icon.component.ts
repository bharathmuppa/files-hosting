import { NgClass, NgTemplateOutlet } from '@angular/common';
import { Component, EventEmitter, Input, Output, TemplateRef } from '@angular/core';
import { MatBadge } from '@angular/material/badge';
import { MatButton, MatIconButton } from '@angular/material/button';
import { MatDivider } from '@angular/material/divider';
import { MatIcon } from '@angular/material/icon';
import { MatMenu, MatMenuTrigger } from '@angular/material/menu';
import { MatToolbar, MatToolbarRow } from '@angular/material/toolbar';
import { MatTooltip } from '@angular/material/tooltip';
import { AALCommonButtonComponent } from '@enterprise-components/common';
import { ListItemComponent } from '../list-item/list-item.component';
import { ListItemConfiguration } from '../shared/list-item-configuration.model';

@Component({
  selector: 'aal-button-overlay-icon',
  templateUrl: './button-overlay-icon.component.html',
  styleUrls: ['./button-overlay-icon.component.scss'],
  standalone: true,
  imports: [
    MatIconButton,
    MatTooltip,
    NgClass,
    MatMenuTrigger,
    MatIcon,

    MatBadge,
    MatMenu,
    MatToolbar,
    MatToolbarRow,
    ListItemComponent,
    NgTemplateOutlet,
    MatDivider,
    MatButton,
  ],
})
export class ButtonOverlayIconComponent extends AALCommonButtonComponent {
  @Input()
  headerIcon: string;
  @Input()
  headerTitle: any;
  @Input()
  buttonText: any;
  @Input()
  listItemDetails: ListItemConfiguration[];
  @Input()
  defaultItemIcon: string;
  @Input()
  menuContentRef: TemplateRef<any>;
  @Input()
  defaultItemImageURL: string;
  @Input()
  defaultSvgIcon: string;
  @Input()
  titleTemplateRef: TemplateRef<any>;
  @Input()
  mainDescriptionTemplateRef: TemplateRef<any>;
  @Input()
  subDescriptionTemplateRef: TemplateRef<any>;
  @Output()
  submitClick: EventEmitter<string> = new EventEmitter<string>();

  onsubmit($event) {
    this.submitClick.emit();
  }
}
