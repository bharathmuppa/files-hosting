import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatBadgeModule } from '@angular/material/badge';
import { AALCommonComponentsModule } from '@enterprise-components/common';
import { ListItemToolbarComponent } from '../list-item-toolbar/list-item-toolbar.component';
import { SharedFormModule } from '../shared/shared-form.module';
import { SharedMaterialModule } from '../shared/shared-material.module';
import { SharedModule } from '../shared/shared.module';
import { ButtonOverlayIconComponent } from './button-overlay-icon.component';

describe('ButtonOverlayIconComponent', () => {
  let component: ButtonOverlayIconComponent;
  let fixture: ComponentFixture<ButtonOverlayIconComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        ListItemToolbarComponent,
        MatBadgeModule,
        ButtonOverlayIconComponent,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ButtonOverlayIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit on click of button', () => {
    spyOn(component.submitClick, 'emit');
    const event = new MouseEvent('click');
    component.onsubmit(event);
    fixture.detectChanges();
    expect(component.submitClick.emit).toHaveBeenCalled();
  });
});
