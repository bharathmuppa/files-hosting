import { NgClass, NgTemplateOutlet } from '@angular/common';
import { Component, EventEmitter, Input, Output, TemplateRef } from '@angular/core';
import { MatCheckbox } from '@angular/material/checkbox';
import { MatDivider } from '@angular/material/divider';
import { MatIcon } from '@angular/material/icon';

@Component({
  selector: 'aal-analytics-card',
  templateUrl: './analytics-card.component.html',
  styleUrls: ['./analytics-card.component.scss'],
  standalone: true,
  imports: [NgClass, MatCheckbox, NgTemplateOutlet, MatIcon, MatDivider],
})
export class AnalyticsCardComponent {
  @Input()
  item: any;
  @Input()
  cardDetail: any;
  @Input()
  expandStatePanel: boolean;
  @Input()
  cardLabelKey: string;
  @Input()
  cardCountKey: string;
  @Input()
  mode: string;
  @Input()
  additionalTemplateRef: TemplateRef<any>;
  @Input()
  layout: string;
  @Input()
  cardStyleClassName: string;
  @Input()
  iconRef: TemplateRef<any>;
  @Input()
  icon: string;
  @Output()
  readonly cardChecked: EventEmitter<any> = new EventEmitter();

  checked() {
    this.cardChecked.emit();
  }
}
