import { NgModule } from '@angular/core';
import { AnalyticsPanelComponent } from './analytics-panel.component';

@NgModule({
  imports: [AnalyticsPanelComponent],
  exports: [AnalyticsPanelComponent],
})
export class AnalyticsPanelModule {}
