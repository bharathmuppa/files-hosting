import { NgModule } from '@angular/core';
import { AnalyticsCardComponent } from './analytics-card.component';

@NgModule({
  imports: [AnalyticsCardComponent],
  exports: [AnalyticsCardComponent],
})
export class AnalyticsCardModule {}
