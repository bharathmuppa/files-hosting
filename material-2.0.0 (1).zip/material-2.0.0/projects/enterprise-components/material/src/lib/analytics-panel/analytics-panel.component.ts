import { Component, EventEmitter, Input, OnInit, Output, TemplateRef } from '@angular/core';
import { MatTooltip } from '@angular/material/tooltip';
import { AnalyticsCardComponent } from './analytics-card/analytics-card.component';

@Component({
  selector: 'aal-analytics-panel',
  templateUrl: './analytics-panel.component.html',
  styleUrls: ['./analytics-panel.component.css'],
  standalone: true,
  imports: [AnalyticsCardComponent, MatTooltip],
})
export class AnalyticsPanelComponent implements OnInit {
  @Input()
  item: any;
  @Input()
  panelExpanded: boolean;
  @Input()
  panelData: any[];
  @Input()
  cardLabelKey: string;
  @Input()
  cardCountKey: string;
  @Input()
  mode: string;
  @Input()
  cardCountLayout: string;
  @Input()
  toolTipKey: string;
  @Input()
  additionalTemplateRef: TemplateRef<any>;
  @Output()
  readonly cardsSelected: EventEmitter<any> = new EventEmitter();

  constructor() {}

  ngOnInit(): void {}

  onStatusCardSelection(selectedCardDetails) {
    if (this.mode === 'multiple') {
      selectedCardDetails.checked = !selectedCardDetails.checked;
      this.cardsSelected.emit(this.panelData.filter((card) => card && card.checked));
    } else {
      if (selectedCardDetails.checked) {
        selectedCardDetails.checked = !selectedCardDetails.checked;
        this.cardsSelected.emit('');
      } else {
        this.panelData.forEach((cardDetails) => {
          cardDetails.checked = false;
        });
        selectedCardDetails.checked = !selectedCardDetails.checked;
        this.cardsSelected.emit(this.panelData.filter((card) => card && card.checked)[0]);
      }
    }
  }
}
