import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { AnalyticsPanelComponent } from './analytics-panel.component';

describe('AnalyticsPanelComponent', () => {
  let component: AnalyticsPanelComponent;
  let fixture: ComponentFixture<AnalyticsPanelComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [AnalyticsPanelComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalyticsPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit event when panel is selected', () => {
    component.panelData = [{ checked: false }, { checked: false }];
    spyOn(component.cardsSelected, 'emit');
    component.onStatusCardSelection({ checked: false });
    expect(component.cardsSelected.emit).toHaveBeenCalled();
  });

  it('should emit checked events when panel is selected', () => {
    component.mode = 'multiple';
    component.panelData = [{ checked: true }, { checked: false }];
    spyOn(component.cardsSelected, 'emit');
    component.onStatusCardSelection({ checked: true });
    expect(component.cardsSelected.emit).toHaveBeenCalledWith([{ checked: true }]);
  });

  it('should emit empty string when panel is deselected', () => {
    component.panelData = [{ checked: true }, { checked: false }];
    spyOn(component.cardsSelected, 'emit');
    component.onStatusCardSelection({ checked: true });
    expect(component.cardsSelected.emit).toHaveBeenCalledWith('');
  });
});
