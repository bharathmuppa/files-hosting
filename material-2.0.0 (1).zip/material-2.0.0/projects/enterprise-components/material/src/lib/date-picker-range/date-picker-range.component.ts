import { DatePipe, NgClass } from '@angular/common';
import { Component, OnInit, Renderer2 } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
  MatNativeDateModule,
  MatOption,
} from '@angular/material/core';
import {
  MatDatepickerModule,
  MatDatepickerToggle,
  MatDateRangeInput,
  MatDateRangePicker,
  MatEndDate,
  MatStartDate,
} from '@angular/material/datepicker';
import { MatError, MatFormField, MatLabel, MatSuffix } from '@angular/material/form-field';
import { MatProgressSpinner } from '@angular/material/progress-spinner';
import { MatSelect } from '@angular/material/select';
import { MatTooltip } from '@angular/material/tooltip';
import { AALCommonModule, AALUtil, HistoryService } from '@enterprise-components/common';
import { DatePickerWeekComponent } from '../date-picker-week/date-picker-week.component';
import { generateMatDateFormats } from '../date-picker/date-picker.utils';
import { DynamicDateAdapter } from '../date-picker/dynamic-date-adapter.service';
import { OverlayCardErrorModule } from '../overlay-card-alert/overlay-card-alert.module';
import { OverlayCardHelpModule } from '../overlay-card-help/overlay-card-help.module';

@Component({
  selector: 'aal-date-picker-range',
  templateUrl: './date-picker-range.component.html',
  styleUrls: ['./date-picker-range.component.scss'],
  standalone: true,
  imports: [
    OverlayCardHelpModule,
    MatProgressSpinner,
    MatFormField,
    MatLabel,
    MatSelect,
    FormsModule,
    MatOption,
    MatDateRangeInput,
    ReactiveFormsModule,
    MatStartDate,
    MatEndDate,
    MatDatepickerToggle,
    MatSuffix,
    MatDateRangePicker,
    MatError,
    MatTooltip,
    NgClass,
    AALCommonModule,
    OverlayCardErrorModule,
    DatePipe,

    MatNativeDateModule,
    MatDatepickerModule,
  ],
  providers: [
    { provide: MAT_DATE_LOCALE, useValue: 'en-GB' }, // Set the locale to English (with Monday as the first day)
    {
      provide: DateAdapter,
      useFactory: () => {
        const adapter = new DynamicDateAdapter();
        adapter.setStartOfWeek(1); // Default to Monday
        return adapter;
      },
    },
    { provide: MAT_DATE_FORMATS, useValue: generateMatDateFormats() },
  ],
})
export class DatePickerRangeComponent extends DatePickerWeekComponent implements OnInit {
  beginDate: Date;

  constructor(renderer: Renderer2, historyService: HistoryService) {
    super(renderer, historyService);
    this.listValueSelected = false;
  }

  ngOnInit() {
    if (this.control && this.control.value) {
      this.datePickerSelection = this.selectedValue = AALUtil.setDateDefaultTime(
        this.control.value,
      );
    }
    super.ngOnInit();
  }

  onChange($event?: Event) {
    if (this.control.value) {
      const isoDateObject = {
        begin: AALUtil.getDateInISOFormat(this.control.value.begin),
        end: AALUtil.getDateInISOFormat(this.control.value.end),
      };
      this.control.setValue(isoDateObject);
    }
    super.onChange($event);
  }

  changeDateFormat(event, dateType) {
    if (event.value) {
      if (!event.value.begin) {
        if (dateType === 'start') {
          this.beginDate = event.value;
        } else if (dateType === 'end') {
          this.control.patchValue({
            begin: this.beginDate,
            end: event.value,
          });
        } else {
          this.control.setValue({
            begin: this.isPastDateRange ? event.value : this.today,
            end: this.isPastDateRange ? this.today : event.value,
          });
          this.datePickerSelection = this.control.value;
        }
      } else {
        this.datePickerSelection = this.control.value;
      }
    } else {
      this.control.setValue('');
    }
  }

  onClick(): void {
    super.setModeToEdit();
    setTimeout(() => {
      if (this.selectField && this.selectField.trigger) {
        this.selectField.trigger.nativeElement.click();
      }
    }, 100);
  }
}
