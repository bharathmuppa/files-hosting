import { NgModule } from '@angular/core';
import { DatePickerRangeComponent } from './date-picker-range.component';

@NgModule({
  imports: [DatePickerRangeComponent],
  exports: [DatePickerRangeComponent],
})
export class DatePickerRangeModule {}
