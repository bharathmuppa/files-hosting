import { CommonModule } from '@angular/common';
import { ElementRef } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { UntypedFormControl, Validators } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AALCommonComponentsModule, AALUtil } from '@enterprise-components/common';

import { SharedFormModule } from '../shared/shared-form.module';
import { SharedMaterialModule } from '../shared/shared-material.module';
import { SharedModule } from '../shared/shared.module';
import { DatePickerRangeComponent } from './date-picker-range.component';

describe('AALDateRangeComponent', () => {
  let component: DatePickerRangeComponent;
  let fixture: ComponentFixture<DatePickerRangeComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        MatDatepickerModule,
        BrowserAnimationsModule,
        DatePickerRangeComponent,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatePickerRangeComponent);
    component = fixture.componentInstance;
    component.control = new UntypedFormControl(
      new Date(),
      Validators.compose([Validators.required]),
    );
    fixture.detectChanges();
    jasmine.clock().uninstall();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize component (ngOnInit)', () => {
    const todayDate = new Date();
    component.control.setValue(todayDate);
    component.ngOnInit();
    expect(component.datePickerSelection).toEqual(AALUtil.setDateDefaultTime(todayDate));
  });

  it('should set beginDate, when changeDateFormat is triggered and dateType is start', () => {
    component.changeDateFormat(
      {
        value: new Date(2021, 6),
      },
      'start',
    );
    expect(component.beginDate).toEqual(new Date(2021, 6));
  });

  it('should set control value, when changeDateFormat is triggered and dateType is end', () => {
    component.beginDate = new Date(2021, 6);
    component.changeDateFormat(
      {
        value: {},
      },
      'end',
    );
    expect(component.control.value).toEqual({ begin: new Date(2021, 6), end: {} });
  });

  it('should set control value, when changeDateFormat is triggered and dateType is neither start nor end', () => {
    component.today = new Date(2021, 6);
    component.changeDateFormat(
      {
        value: {},
      },
      'noStartEnd',
    );
    expect(component.control.value).toEqual({ begin: new Date(2021, 6), end: {} });
  });

  it('should set datePickerSelection, when changeDateFormat is triggered', () => {
    component.control = new UntypedFormControl(new Date(2021, 6));
    component.changeDateFormat(
      {
        value: {
          begin: new Date(2021, 6),
        },
      },
      'end',
    );
    expect(component.datePickerSelection).toEqual(new Date(2021, 6));
  });

  it('should set control as empty, when changeDateFormat is triggered and inappropriate data is passed', () => {
    component.changeDateFormat({}, 'noStartEnd');
    expect(component.control.value).toEqual('');
  });

  it('should call onChange function', () => {
    component.control.setValue({ begin: new Date(), end: new Date() });
    component.onChange(new Event(''));
    expect(new Date(component.control.value.begin).getDate()).toBe(new Date().getDate());
  });

  it('should open optionsPanel, when onClick is triggered', () => {
    component.selectField = {
      trigger: new ElementRef<any>({
        click: () => {},
      }),
    };
    const spy = spyOn(component.selectField.trigger.nativeElement, 'click').and.callFake(() => {});
    jasmine.clock().install();
    component.onClick();
    jasmine.clock().tick(300);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });
});
