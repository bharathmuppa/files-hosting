import { MatNativeDateModule } from '@angular/material/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Modes } from '@enterprise-components/common';
import { moduleMetadata, type Meta, type StoryObj } from '@storybook/angular';
import { fn } from '@storybook/test';
import { PassCustomControl } from '../../../.storybook/utils';
import { DatePickerRangeComponent } from './date-picker-range.component';

const meta: Meta<DatePickerRangeComponent> = {
  title: 'Enterprise Components/Molecules/Date Picker Range',
  component: DatePickerRangeComponent,
  decorators: [
    moduleMetadata({
      imports: [MatNativeDateModule, BrowserAnimationsModule],
    }),
  ],
};

export default meta;
type Story = StoryObj<DatePickerRangeComponent>;

export const Default: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    ID: 'DateRangeField',
    isPastDateRange: true,
    label: 'DatePicker Range',
    showHyphenForValues: [null, ''],
    placeholder: 'DateRangeField(editable)',
  },
  render: PassCustomControl,
};

export const DatePickerModeProtected: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    ID: 'DatePicker',
    label: 'Datepicker',
    placeholder: 'DateRangeField(editable)',
    mode: Modes.PROTECTED,
  },
  render: PassCustomControl,
};

export const DatePickerModePrivate: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    ID: 'DateRangeField',
    label: 'DatePicker Range',
    placeholder: 'DateRangeField(editable)',
    mode: Modes.PRIVATE,
  },
  render: PassCustomControl,
};
