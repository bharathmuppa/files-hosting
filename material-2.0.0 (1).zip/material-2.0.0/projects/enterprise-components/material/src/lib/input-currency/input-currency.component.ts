import { CommonModule, getCurrencySymbol } from '@angular/common';
import { Component, input, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';
import {
  AALCommonComponentsModule,
  AALCommonModule,
  AALInputFormControlComponent,
  HistoryService,
} from '@enterprise-components/common';
import { OverlayCardErrorModule } from '../overlay-card-alert/overlay-card-alert.module';
import { OverlayCardHelpModule } from '../overlay-card-help/overlay-card-help.module';
import { CommonMaterialComponentErrorStateMatcher } from '../shared/common-material-component.error-state-matcher';
import { ToolbarConfirmModule } from '../toolbar-confirm/toolbar-confirm.module';

const DEFAULT_DECIMAL_SEPARATOR = ',';
const DEFAULT_THOUSANDS_SEPARATOR = '.';
const DEFAULT_MIN_INTEGER_DIGITS = 1;
const DEFAULT_MIN_FRACTION_DIGITS = 0;
const DEFAULT_MAX_FRACTION_DIGITS = 0;

@Component({
  selector: 'aal-input-currency',
  standalone: true,
  templateUrl: './input-currency.component.html',
  styleUrls: ['./input-currency.component.scss'],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AALCommonModule,
    AALCommonComponentsModule,
    OverlayCardHelpModule,
    OverlayCardErrorModule,
    ToolbarConfirmModule,
    MatAutocompleteModule,
    MatIconModule,
    MatInputModule,
    MatProgressSpinnerModule,
    MatSelectModule,
    MatTooltipModule,
  ],
})
export class AALInputCurrencyComponent extends AALInputFormControlComponent implements OnInit {
  /**
   * The currency code to determine the currency symbol (e.g., USD, EUR).
   */
  currencyCode = input<string>();

  /**
   * The character used to separate decimals in currency values.
   * Default: `DEFAULT_DECIMAL_SEPARATOR`.
   */
  decimalSeparator = input<string>(DEFAULT_DECIMAL_SEPARATOR);

  /**
   * The character used to separate thousands in currency values.
   * Default: `DEFAULT_THOUSANDS_SEPARATOR`.
   */
  thousandsSeparator = input<string>(DEFAULT_THOUSANDS_SEPARATOR);

  /**
   * Minimum number of integer digits required before the decimal point.
   * Default: `DEFAULT_MIN_INTEGER_DIGITS`.
   */
  minIntegerDigits = input<number>(DEFAULT_MIN_INTEGER_DIGITS);

  /**
   * Minimum number of fraction digits required after the decimal point.
   * Default: `DEFAULT_MIN_FRACTION_DIGITS`.
   */
  minFractionDigits = input<number>(DEFAULT_MIN_FRACTION_DIGITS);

  /**
   * Maximum number of fraction digits allowed after the decimal point.
   * Default: `DEFAULT_MAX_FRACTION_DIGITS`.
   */
  maxFractionDigits = input<number>(DEFAULT_MAX_FRACTION_DIGITS);

  /**
   * Specifies whether negative currency values are allowed.
   */
  isNegativeCurrency = input<boolean>();

  /**
   * Allows special characters like '-', '+', or 'e' in the input if set to true.
   */
  allowSpecialCharacters = input<boolean>();

  /**
   * Regex validation pattern for the input value.
   */
  set validationPattern(value: string) {
    if (value) {
      this.regex = new RegExp(value);
      this.validationRegex = value;
    }
  }

  /**
   * The compiled regex object for validation.
   */
  regex: RegExp;

  /**
   * Stores the string representation of the regex pattern for validation.
   */
  private validationRegex: string;

  /**
   * Material Design error state matcher for validation styling.
   */
  errorStateMatcher = new CommonMaterialComponentErrorStateMatcher();

  /**
   * Characters that are invalid in the input field unless `allowSpecialCharacters` is true.
   */
  invalidChars = ['-', '+', 'e'];

  constructor(historyService: HistoryService) {
    super(historyService);
  }

  ngOnInit() {
    this.regex = this.validationRegex ? new RegExp(this.validationRegex) : /^-?\d+$/;
    super.ngOnInit();
  }

  /**
   * Handles the blur event. Sanitizes the input value unless a specific condition is met.
   * @param $event Event triggered when the input loses focus.
   */
  onBlur($event?: Event) {
    /* For composite controls, when any value is selected, the focus shits to the input element. Here we are writing conditions for the scenarios when the blur event of the input control must not be called. Add the class 'skip-input-blur-event' to achieve this */
    if (
      $event instanceof FocusEvent &&
      $event.relatedTarget &&
      ($event.relatedTarget['classList'].contains('mat-select') ||
        $event.relatedTarget['id'].includes(this.hyphenatedID) ||
        $event.relatedTarget['parentElement'].classList.contains('skip-input-blur-event'))
    ) {
      // do nothing
      return;
    }
    this.sanitizeInputValue(true);
    super.onBlur($event);
  }

  /**
   * Provides custom validator messages for the component.
   * @param validatorKey The key of the validator.
   * @returns A user-friendly validation message.
   */
  getValidatorMessage(validatorKey: string): string {
    if (validatorKey.toUpperCase() === 'PATTERN') {
      return 'Use Format: -123 Or 123';
    } else {
      return super.getValidatorMessage(validatorKey);
    }
  }

  /**
   * Retrieves the currency symbol based on the provided currency code.
   * @returns The currency symbol.
   */
  getCurrencySymbol(): string {
    return this.currencyCode() ? getCurrencySymbol(this.currencyCode(), 'narrow') : '';
  }

  /**
   * Converts a string to a numeric value.
   * @param data The string value to convert.
   * @returns The numeric value.
   */
  toNumber(data: string): number {
    return +data;
  }

  /**
   * Constructs the display format string for currency input.
   * @returns The display format string.
   */
  getDisplayFormat(): string {
    return `${this.minIntegerDigits()}.${this.minFractionDigits()}-${this.maxFractionDigits()}`;
  }

  /**
   * Sanitizes the input value by handling negative values based on settings.
   * @param triggerSanitizeInput Flag to trigger the sanitization.
   * @param event The event triggering the sanitization.
   */
  sanitizeInputValue(triggerSanitizeInput: boolean, event?) {
    if (this.isNegativeCurrency() && ((event && event.key === 'Enter') || triggerSanitizeInput)) {
      if (this.toNumber(this.control.value) < 1) {
        this.control.setValue(Math.abs(this.toNumber(this.control.value)).toString());
      }
    }
  }

  /**
   * Handles the `keydown` event to prevent invalid characters from being entered.
   * @param event The keyboard event.
   */
  onKeyDown(event: KeyboardEvent): void {
    // block special character from input field unless explicitly asked for
    if (this.invalidChars.includes(event.key) && !this.allowSpecialCharacters()) {
      event.preventDefault();
    }
  }
}
