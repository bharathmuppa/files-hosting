import { UntypedFormControl } from '@angular/forms';
import { BrowserAnimationsModule, provideAnimations } from '@angular/platform-browser/animations';
import { Info, Modes } from '@enterprise-components/common';
import { applicationConfig, Meta, moduleMetadata, StoryObj } from '@storybook/angular';
import { AALInputCurrencyComponent } from './input-currency.component';

const meta: Meta<AALInputCurrencyComponent> = {
  title: 'Enterprise Components/Atoms/Input/InputCurrency',
  component: AALInputCurrencyComponent,
  decorators: [
    moduleMetadata({
      imports: [BrowserAnimationsModule],
    }),
    applicationConfig({
      providers: [provideAnimations()],
    }),
  ],
  argTypes: {},
};

export default meta;
type Story = StoryObj<AALInputCurrencyComponent>;

const helpInfo = new Info(
  'Help Title',
  'This is help message with <a target="_blank" href="https://www.google.com">link </a>',
  null,
);
const alertErrorInfo = new Info(
  'Error Title',
  'This is error message with <a target="_blank" href="https://www.google.com">link </a>',
  'ERROR',
);

// Scenario 1: Default
export const Default: Story = {
  args: {
    ID: 'currency',
    mode: Modes.EDIT,
    currencyCode: 'EUR',
    help: helpInfo,
    placeholder: 'currency',
    label: 'Currency Label',
  },
  parameters: {
    docs: {
      description: {
        story: 'Displays the default currency input component in READ mode.',
      },
    },
  },
  render: (args) => ({
    template: `
      <aal-input-currency
        [ID]="ID"
        [control]="control"
        [mode]="mode"
        [lockMode]="mode"
        [currencyCode]="currencyCode"
        [help]="help"
        [alert]="alert"
        [placeholder]="placeholder"
        [label]="label"
        [isBusy]="isBusy"
        (acceptChanges)="onAcceptChanges($event)"
        (rejectChanges)="onRejectChanges($event)">
      </aal-input-currency>
    `,
    props: {
      ...args,
      control: new UntypedFormControl(''),
      onAcceptChanges: ($event: Event) => {
        console.log($event);
      },
      onRejectChanges: ($event: Event) => {
        console.log($event);
      },
    },
  }),
};

// Scenario 2: Edit Mode
export const EditModeWithError: Story = {
  args: {
    ID: 'currency',
    mode: Modes.EDIT,
    currencyCode: 'EUR',
    help: helpInfo,
    alert: alertErrorInfo,
    placeholder: 'currency',
    label: 'Currency Label',
    isBusy: false,
    isNegativeCurrency: true,
  },
  parameters: {
    docs: {
      description: {
        story: 'Displays the currency input component in EDIT mode.',
      },
    },
  },
  render: (args) => ({
    template: `
      <aal-input-currency
        [ID]="ID"
        [control]="control"
        [mode]="mode"
        [currencyCode]="currencyCode"
        [help]="help"
        [alert]="alert"
        [placeholder]="placeholder"
        [label]="label"
        [isBusy]="isBusy"
        [isNegativeCurrency]="isNegativeCurrency"
        (acceptChanges)="onAcceptChanges($event)"
        (rejectChanges)="onRejectChanges($event)">
      </aal-input-currency>
    `,
    props: {
      ...args,
      control: new UntypedFormControl(''),
      onAcceptChanges: ($event: Event) => {
        console.log($event);
      },
      onRejectChanges: ($event: Event) => {
        console.log($event);
      },
    },
  }),
};

// Scenario 3: Private Mode
export const PrivateMode: Story = {
  args: {
    ID: 'currency',
    mode: Modes.PRIVATE,
    currencyCode: 'EUR',
    help: helpInfo,
    placeholder: 'currency',
    label: 'Currency Label',
  },
  parameters: {
    docs: {
      description: {
        story: 'Displays the currency input component in PRIVATE mode.',
      },
    },
  },
  render: (args) => ({
    template: `
      <aal-input-currency
        [ID]="ID"
        [control]="control"
        [mode]="mode"
        [currencyCode]="currencyCode"
        [help]="help"
        [placeholder]="placeholder"
        [label]="label">
      </aal-input-currency>
    `,
    props: {
      ...args,
      control: new UntypedFormControl(''),
    },
  }),
};

// Scenario 5: Negative Currency Mode (Edit)
export const NegativeCurrencyMode: Story = {
  args: {
    ID: 'currency',
    mode: Modes.EDIT,
    currencyCode: 'EUR',
    help: helpInfo,
    placeholder: 'currency',
    label: 'Currency Label',
    isNegativeCurrency: true,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Displays the currency input component in EDIT mode when negative currency is enabled.',
      },
    },
  },
  render: (args) => ({
    template: `
      <aal-input-currency
        [ID]="ID"
        [control]="control"
        [currencyCode]="currencyCode"
        [help]="help"
        [placeholder]="placeholder"
        [label]="label"
        [isNegativeCurrency]="isNegativeCurrency">
      </aal-input-currency>
    `,
    props: {
      ...args,
      control: new UntypedFormControl(''),
    },
  }),
};

// Scenario 6: Protected Mode
export const ProtectedMode: Story = {
  args: {
    ID: 'currency',
    mode: Modes.PROTECTED,
    currencyCode: 'EUR',
    help: helpInfo,
    placeholder: 'currency',
    label: 'Currency Label',
    isBusy: false,
    thousandsSeparator: ',',
    isNegativeCurrency: true,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Displays the currency input component in PROTECTED mode with custom thousand separator.',
      },
    },
  },
  render: (args) => ({
    template: `
      <aal-input-currency
        [ID]="ID"
        [control]="control"
        [mode]="mode"
        [currencyCode]="currencyCode"
        [help]="help"
        [alert]="alert"
        [placeholder]="placeholder"
        [label]="label"
        [isBusy]="isBusy"
        [thousandsSeparator]="thousandsSeparator"
        [isNegativeCurrency]="isNegativeCurrency">
      </aal-input-currency>
    `,
    props: {
      ...args,
      control: new UntypedFormControl(''),
      onAcceptChanges: ($event: Event) => {
        console.log($event);
      },
      onRejectChanges: ($event: Event) => {
        console.log($event);
      },
    },
  }),
};

// Scenario 7: Custom Validation Pattern
export const CustomValidationPattern: Story = {
  args: {
    ID: 'currency',
    mode: Modes.READ,
    currencyCode: 'EUR',
    help: helpInfo,
    placeholder: 'currency',
    label: 'Currency Label',
    validationPattern: '^\\s*(?=.*[0-9])\\d{0,6}(?:\\.\\d{1,2})?\\s*$',
  },
  parameters: {
    docs: {
      description: {
        story:
          'Displays the currency input component with custom validation pattern for maxLength and fraction digits.',
      },
    },
  },
  render: (args) => ({
    template: `
      <aal-input-currency
        [ID]="ID"
        [control]="control"
        [mode]="mode"
        [currencyCode]="currencyCode"
        [help]="help"
        [placeholder]="placeholder"
        [label]="label"
        [validationPattern]="validationPattern">
      </aal-input-currency>
    `,
    props: {
      ...args,
      control: new UntypedFormControl(''),
    },
  }),
};
