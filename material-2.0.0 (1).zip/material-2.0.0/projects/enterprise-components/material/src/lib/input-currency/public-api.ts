/*
 * Public API Surface of material
 */

export * from './input-currency.component';
