import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormControl, UntypedFormControl, Validators } from '@angular/forms';

import { signal } from '@angular/core';
import { AALInputFormControlComponent } from '@enterprise-components/common';
import { AALInputCurrencyComponent } from './input-currency.component';

describe('AALInputCurrencyComponent', () => {
  let component: AALInputCurrencyComponent;
  let fixture: ComponentFixture<AALInputCurrencyComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [AALInputCurrencyComponent],
    })
      .compileComponents()
      .then(() => {});
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALInputCurrencyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize regex when we have input pattern', () => {
    component.validationPattern = '^d{1,5}$';
    component.ngOnInit();
    expect(component.regex).toEqual(/^d{1,5}$/);
  });

  it('should not initialize validation regex when there is no input pattern', () => {
    component.validationPattern = '';
    expect(component.regex).toEqual(/^-?\d+$/);
  });

  it('should return currency display format (getDisplayFormat)', () => {
    const displayFormat = component.getDisplayFormat();
    expect(displayFormat).toEqual('1.0-0');
  });

  it('should return number from string (toNumber)', () => {
    const outputNumber = component.toNumber('3');
    expect(typeof outputNumber).toEqual('number');
  });

  it('should return currency symbol (getCurrencySymbol)', () => {
    component.currencyCode = signal('EUR') as unknown as typeof component.currencyCode;
    const currencySymbol = component.getCurrencySymbol();
    expect(currencySymbol).toEqual('€');
  });

  it('should return currency symbol (getCurrencySymbol) if null', () => {
    component.currencyCode = signal('') as unknown as typeof component.currencyCode;
    const currencySymbol = component.getCurrencySymbol();
    expect(currencySymbol).toEqual('');
  });

  it('should return validation message (getValidatorMessage)', () => {
    const validationMessage = component.getValidatorMessage('PATTERN');
    expect(validationMessage).toEqual('Use Format: -123 Or 123');
  });

  it('should return validation message from parent component (getValidatorMessage)', () => {
    component.control = new UntypedFormControl('', Validators.required);
    const validationMessage = component.getValidatorMessage('');
    expect(validationMessage.indexOf('Failed validation')).toBeGreaterThan(-1);
  });

  it('should return nothing when value is set from history ', () => {
    component.control = new UntypedFormControl('EUR', Validators.required);
    const matOption = document.createElement('mat-option');
    matOption.classList.add('mat-select');
    const event = new FocusEvent('focus', { relatedTarget: matOption });
    const returnValue = component.onBlur(event);
    expect(returnValue).toBe(undefined);
  });

  it('should call onBlur of super Component ', () => {
    spyOn(AALInputFormControlComponent.prototype, 'onBlur');
    component.control = new UntypedFormControl(10, []);
    const matOption = document.createElement('no-mat-option');
    const $event = new Event('blur');
    const ret = component.onBlur($event);
    expect(AALInputFormControlComponent.prototype.onBlur).toHaveBeenCalled();
  });

  it('should sanitize -ve values and convert to +ve values, when isNegativeCurrency flag is set as true', () => {
    component.isNegativeCurrency = signal(true) as unknown as typeof component.isNegativeCurrency;
    component.control = new FormControl('-10', []);
    component.sanitizeInputValue(true, { key: 'Enter' });
    expect(component.control.value).toBe('10');
  });

  it('should not allow value which are not allowed', () => {
    component.control = new FormControl('', Validators.required);
    const event = new KeyboardEvent('keydown', {
      key: 'e',
    });
    component.onKeyDown(event);
    expect(component.control.value).toEqual('');
  });
});
