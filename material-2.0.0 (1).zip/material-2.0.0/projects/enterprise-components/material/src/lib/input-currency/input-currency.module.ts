import { NgModule } from '@angular/core';
import { AALInputCurrencyComponent } from './input-currency.component';

@NgModule({
  imports: [AALInputCurrencyComponent],
  exports: [AALInputCurrencyComponent],
})
export class AALInputCurrencyModule {}
