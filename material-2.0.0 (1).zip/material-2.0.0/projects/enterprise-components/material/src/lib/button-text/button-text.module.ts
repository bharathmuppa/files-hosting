import { NgModule } from '@angular/core';
import { ButtonTextComponent } from './button-text.component';

@NgModule({
  imports: [ButtonTextComponent],
  exports: [ButtonTextComponent],
})
export class ButtonTextModule {}
