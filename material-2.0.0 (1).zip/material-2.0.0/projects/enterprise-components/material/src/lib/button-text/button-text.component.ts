import { Component } from '@angular/core';
import { MatButton } from '@angular/material/button';
import { MatTooltip } from '@angular/material/tooltip';
import { AALCommonButtonComponent } from '@enterprise-components/common';

@Component({
  selector: 'aal-button-text',
  templateUrl: './button-text.component.html',
  styleUrls: ['./button-text.component.scss'],
  standalone: true,
  imports: [MatButton, MatTooltip],
})
export class ButtonTextComponent extends AALCommonButtonComponent {}
