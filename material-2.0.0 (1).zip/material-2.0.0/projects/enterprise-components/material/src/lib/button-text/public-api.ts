/*
 * Public API Surface of material
 */

export * from './button-text.component';
export * from './button-text.module';
