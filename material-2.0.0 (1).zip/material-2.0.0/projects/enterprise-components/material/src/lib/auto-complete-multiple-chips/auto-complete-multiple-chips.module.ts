import { NgModule } from '@angular/core';
import { AutoCompleteMultipleChipsComponent } from './auto-complete-multiple-chips.component';

@NgModule({
  imports: [AutoCompleteMultipleChipsComponent],
  exports: [AutoCompleteMultipleChipsComponent],
})
export class AutoCompleteMultipleChipsModule {}
