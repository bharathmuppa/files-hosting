import { NgClass } from '@angular/common';
import {
  AfterViewInit,
  Component,
  ElementRef,
  Input,
  OnChanges,
  OnInit,
  ViewChild,
} from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatAutocomplete, MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { MatIconButton } from '@angular/material/button';
import {
  MatChip,
  MatChipAvatar,
  MatChipGrid,
  MatChipInput,
  MatChipListbox,
  MatChipRemove,
  MatChipRow,
} from '@angular/material/chips';
import { MatOption } from '@angular/material/core';
import { MatDivider } from '@angular/material/divider';
import { MatFormField, MatLabel, MatPrefix, MatSuffix } from '@angular/material/form-field';
import { MatIcon } from '@angular/material/icon';
import { MatInput } from '@angular/material/input';
import { MatMenu, MatMenuTrigger } from '@angular/material/menu';
import { MatProgressSpinner } from '@angular/material/progress-spinner';
import { MatTooltip } from '@angular/material/tooltip';
import { AALAutoCompleteFormControlComponent, HistoryService } from '@enterprise-components/common';
import { ChipModule } from '../chip/chip.module';
import { AALCommonModule } from '../common/common.module';
import { OverlayCardAlertComponent } from '../overlay-card-alert/overlay-card-alert.component';
import { OverlayCardHelpComponent } from '../overlay-card-help/overlay-card-help.component';
import { CommonMaterialComponentErrorStateMatcher } from '../shared/common-material-component.error-state-matcher';

@Component({
  selector: 'aal-auto-complete-multiple-chips',
  templateUrl: './auto-complete-multiple-chips.component.html',
  styleUrls: ['./auto-complete-multiple-chips.component.scss'],
  standalone: true,
  imports: [
    OverlayCardHelpComponent,
    MatProgressSpinner,
    NgClass,
    FormsModule,
    MatFormField,
    MatLabel,
    MatChipGrid,
    MatChipRow,
    MatChipAvatar,
    MatTooltip,
    MatChipRemove,
    MatIcon,
    MatMenuTrigger,
    MatMenu,
    MatChip,
    MatPrefix,
    MatInput,
    MatChipInput,
    MatAutocompleteTrigger,
    AALCommonModule,
    ReactiveFormsModule,
    MatIconButton,
    MatSuffix,
    MatAutocomplete,
    MatOption,
    MatDivider,
    MatChipListbox,
    ChipModule,
    OverlayCardAlertComponent,
  ],
})
export class AutoCompleteMultipleChipsComponent
  extends AALAutoCompleteFormControlComponent
  implements OnInit, OnChanges, AfterViewInit
{
  isControlDisabledInitially: boolean;
  @ViewChild('resultAutoComplete', { static: false }) matAutoComplete: MatAutocomplete;
  @ViewChild('inputField', { read: MatAutocompleteTrigger }) autoTrigger: MatAutocompleteTrigger;
  @ViewChild('inputField') autoCompleteInput: ElementRef;
  @Input()
  chipsRemovable: boolean;
  @Input()
  chipsDisabled: boolean;
  @Input()
  autoActiveFirstOption: boolean;
  @Input()
  highlightOption: boolean;
  @Input()
  maxChipsToDisplay: number;
  errorStateMatcher = new CommonMaterialComponentErrorStateMatcher();
  currentValue: any;
  @Input() enableRemoveChipFromList: boolean;
  chipIndex: number;
  removeChipActivated: boolean;
  pointerOnChip: boolean;

  mouseOnChip: boolean;
  removeChipActivatedOn: any;
  mouseOnMatCompleteList: boolean;
  mouseOnMatCompleteListValue: any;

  constructor(historyService: HistoryService) {
    super(historyService);
  }

  ngOnInit() {
    super.ngOnInit();
  }

  ngOnChanges() {
    if (this.inputControl && this.control && this.control.disabled) {
      this.isControlDisabledInitially = true;
      this.inputControl.disable();
    }
  }

  emptyControl() {
    this.control.setValue([]);
  }

  getDisplayItems(list) {
    let displayItems = [];
    if (this.maxChipsToDisplay && list && list.length > this.maxChipsToDisplay) {
      displayItems = list.slice(0, this.maxChipsToDisplay);
    } else {
      displayItems = list;
    }
    return displayItems;
  }

  getOverlayItems(list) {
    let overlayListItems = [];
    if (this.maxChipsToDisplay && list && list.length > this.maxChipsToDisplay) {
      overlayListItems = list.slice(this.maxChipsToDisplay, list.length);
    }
    return overlayListItems;
  }

  onInputBlur(event) {
    if (event.relatedTarget && this.matAutoComplete.isOpen) {
      event.relatedTarget.click();
    } else if (event.relatedTarget && event.relatedTarget.id === this.hyphenatedID + '_close') {
      event.preventDefault();
    } else if (
      event.relatedTarget &&
      (!event.relatedTarget.id ||
        (event.relatedTarget.id && event.relatedTarget.id.includes(this.hyphenatedID)))
    ) {
      this.triggerAcceptChanges();
      return;
    } else {
      this.triggerAcceptChanges();
    }
  }

  addChip(event: any, input?: HTMLInputElement): void {
    const value = event.value || event.option.value;
    if (value) {
      this.currentValue = this.control.value || [];
      this.currentValue.push(value);
      this.control.setValue(this.currentValue);
    }
    if (input) {
      input.value = '';
    }
  }

  removeChip(item: any, inputField: HTMLElement): void {
    const remainingItems = this.control.value.filter((option) => option !== item);
    this.control.setValue(remainingItems);
    inputField.focus();
  }

  onKeyUp(event: KeyboardEvent) {
    if (event.key === 'Escape') {
      this.triggerRejectChanges();
    } else if (event.key === 'Enter' && this.autoTrigger && this.inputControl.value !== '') {
      this.inputControl.setValue('');
      this.triggerAcceptChanges();
    } else if (event.key === ' ' && this.autoTrigger && this.autoTrigger.activeOption) {
      this.addChip(this.autoTrigger.activeOption, this.autoCompleteInput.nativeElement);
    }
  }

  removeChipFromList(index) {
    if (index > -1) {
      this.currentValue = this.control.value || [];
      this.currentValue.splice(index, 1);
      this.control.setValue(this.currentValue);
      let inputElement = this.autoCompleteInput.nativeElement as HTMLElement;
      inputElement.focus();
    }
    this.chipIndex = undefined;
    this.removeChipActivated = undefined;
  }

  onBlur(event) {
    if (!this.pointerOnChip) {
      if (!this.chipIndex && !this.removeChipActivated) {
        this.blurEventHanlder(event);
      } else if (this.chipIndex > -1 && this.removeChipActivated) {
        this.removeChipFromList(this.chipIndex);
      }
    } else if (this.pointerOnChip) {
      if (this.chipIndex > -1 && this.removeChipActivated) {
        this.removeChipFromList(this.chipIndex);
      } else {
        let inputElement = this.inputField.nativeElement as HTMLElement;
        inputElement.focus();
      }
    }
  }

  // Blur event handler from auto complete input
  blurEventHanlder(event) {
    // When selected from autocomplete panel list
    if (this.mouseOnMatCompleteList) {
      // Object to add
      this.mouseOnMatCompleteList = false;

      this.currentValue = this.control.value || [];
      this.currentValue.push(this.mouseOnMatCompleteListValue ?? '');
      this.control.setValue(this.currentValue);
      this.inputField.nativeElement.value = '';
      this.inputControl.setValue(null);
    } else if (event?.relatedTarget && event.relatedTarget.id === this.hyphenatedID + '_close') {
      event.preventDefault();
    } else if (
      event?.relatedTarget &&
      (!event.relatedTarget?.id ||
        (event.relatedTarget.id && event.relatedTarget.id.includes(this.hyphenatedID)))
    ) {
      this.triggerAcceptChanges();
      return;
    } else {
      this.triggerAcceptChanges();
    }
  }

  activateRemoveChip(event) {
    this.chipIndex = event.chipIndex;
    this.removeChipActivated = event.removeChipActivated;
    this.pointerOnChip = false;
  }

  matChipClicked(event) {
    if (event) {
      this.pointerOnChip = event;
      let inputElement = this.inputField.nativeElement as HTMLElement;
      inputElement.focus();
    } else {
      this.pointerOnChip = false;
    }
  }

  // To track the mouse over the chip or not.
  mouseOverChipData(event) {
    if (event) {
      this.mouseOnChip = true;
    } else {
      this.mouseOnChip = false;
    }
  }

  // To track the mouse over the remove icon of the chip or not.
  mouseOverRemoveChip(event) {
    if (event > -1) {
      this.removeChipActivated = true;
      this.removeChipActivatedOn = event;
    } else {
      this.removeChipActivated = false;
    }
  }

  // To track mouse position and read the value to add to the control
  mouseoverOption(entered, value) {
    this.mouseOnMatCompleteList = entered ?? false;
    this.mouseOnMatCompleteListValue = value;
  }
}
