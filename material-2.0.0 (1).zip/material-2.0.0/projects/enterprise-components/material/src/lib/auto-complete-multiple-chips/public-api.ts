/*
 * Public API Surface of material
 */

export * from './auto-complete-multiple-chips.component';
export * from './auto-complete-multiple-chips.module';
