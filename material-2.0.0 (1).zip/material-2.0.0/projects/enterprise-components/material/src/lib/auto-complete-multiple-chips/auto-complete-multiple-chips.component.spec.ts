import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { UntypedFormControl } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AALCommonComponentsModule } from '@enterprise-components/common';

import { MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { MatOption } from '@angular/material/core';
import { ChipModule } from '../chip/chip.module';
import { OverlayCardErrorModule } from '../overlay-card-alert/overlay-card-alert.module';
import { OverlayCardHelpModule } from '../overlay-card-help/overlay-card-help.module';
import { SharedFormModule } from '../shared/shared-form.module';
import { SharedMaterialModule } from '../shared/shared-material.module';
import { SharedModule } from '../shared/shared.module';
import { ToolbarConfirmModule } from '../toolbar-confirm/toolbar-confirm.module';
import { AutoCompleteMultipleChipsComponent } from './auto-complete-multiple-chips.component';

describe('AutoCompleteMultipleComponent', () => {
  let component: AutoCompleteMultipleChipsComponent;
  let fixture: ComponentFixture<AutoCompleteMultipleChipsComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        SharedModule,
        AALCommonComponentsModule,
        OverlayCardHelpModule,
        OverlayCardErrorModule,
        ChipModule,
        ToolbarConfirmModule,
        BrowserAnimationsModule,
        AutoCompleteMultipleChipsComponent,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoCompleteMultipleChipsComponent);
    component = fixture.componentInstance;
    component.control = new UntypedFormControl([]);
    component.itemDisplayField = 'name';

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should empty the control value', () => {
    const value = [{ name: 'abc', abbr: 'ab', id: 1 }];
    component.control.setValue(value);
    component.emptyControl();
    expect(component.control.value).toEqual([]);
  });

  it('ngOnChanges should set the component properties ', () => {
    component.inputControl = new UntypedFormControl('');
    component.control.disable();
    component.ngOnChanges();
    fixture.detectChanges();
    expect(component.isControlDisabledInitially).toBe(true);
  });

  it('should filter the Chip values', () => {
    const value = ['abc', '123', 'xyz'];
    const inputField = document.createElement('input');
    component.control.setValue(value);
    component.removeChip('123', inputField);
    expect(component.control.value).toEqual(['abc', 'xyz']);
  });

  it('should call onInputBlur function if onblur is not triggered to triggerAcceptChanges', () => {
    spyOn(component, 'triggerAcceptChanges');
    const event = new MouseEvent('blur');
    spyOn(event, 'preventDefault');
    component.onInputBlur(event);
    fixture.detectChanges();
    expect(component.triggerAcceptChanges).toHaveBeenCalled();
  });

  it('should set value to control', () => {
    const res = {
      option: {
        abbreviation: 'Q04T',
        departmentName: '',
        email: 'q04test@ec.qas',
        fullName: 'Q 04test',
        photoURL: 'https://people.ec.com:443/User Photos/Profile Pictures/q04test_MThumb.jpg',
        roles: ['changeSpecialist1'],
        userID: 'q04test',
        value: 'test Value',
      },
    };
    const inputElem = document.createElement('input');
    inputElem.placeholder = 'Select a person';
    component.addChip(res, inputElem);
    expect(component.control.value).toEqual(['test Value']);
  });

  it('should set related target for element', () => {
    const mockEvent = {
      relatedTarget: {
        placeholder: 'test',
      },
      preventDefault: () => {},
    };
    component.ID = 'test';
    component.matAutoComplete = jasmine.createSpyObj('isOpen', ['']);
    expect(component.onInputBlur(mockEvent)).toBeFalsy();
  });

  it('should prevent default implementation when, on blur is triggered & relatedTarget is clear button', () => {
    const mockEvent = {
      relatedTarget: {
        id: 'test_close',
        click: () => '',
      },
      preventDefault: () => {},
    };
    const evt = spyOn(mockEvent, 'preventDefault');
    component.ID = 'test';
    component.matAutoComplete = jasmine.createSpyObj('isOpen', ['']);
    component.onInputBlur(mockEvent);
    expect(evt).toHaveBeenCalled();
  });

  it('should click on the element, when onBlur is triggered and related target is the autocomplete options list', () => {
    component.onClick();
    fixture.detectChanges();
    spyOnProperty(component.matAutoComplete, 'isOpen').and.returnValue(true);
    const mockEvent = {
      relatedTarget: {
        id: 'test',
        click: () => '',
      },
    };
    const relatedTargetClick = spyOn(mockEvent.relatedTarget, 'click');
    component.onInputBlur(mockEvent);
    expect(relatedTargetClick).toHaveBeenCalled();
  });

  it('should reject value on escape event', () => {
    spyOn(component, 'triggerRejectChanges');
    const event = new KeyboardEvent('keyup', {
      key: 'Escape',
    });
    component.onKeyUp(event);
    expect(component.triggerRejectChanges).toHaveBeenCalled();
  });

  it('should call addChip, when onKeyUp is triggered after SPACE key is pressed', () => {
    spyOn(component, 'addChip');
    component.autoTrigger = {
      get activeOption(): MatOption | null {
        return {} as MatOption;
      },
    } as MatAutocompleteTrigger;
    component.autoCompleteInput = {
      nativeElement: {},
    };
    const event = new KeyboardEvent('keyup', {
      key: ' ',
    });
    component.onKeyUp(event);
    expect(component.addChip).toHaveBeenCalled();
  });

  it('should emit value on enter key event', () => {
    spyOn(component, 'triggerAcceptChanges');
    component.autoTrigger = {
      get activeOption(): MatOption | null {
        return {} as MatOption;
      },
    } as MatAutocompleteTrigger;
    const event = new KeyboardEvent('keyup', {
      key: 'Enter',
    });
    component.onKeyUp(event);
    component.inputControl = new UntypedFormControl('Sample');
    expect(component.triggerAcceptChanges).toHaveBeenCalled();
  });

  it('should call removeChipFromList and splice an item choose to remove.', () => {
    const index = 0;
    component.control.setValue(['Rama', 'Siva', 'Varma']);

    spyOn(component, 'removeChipFromList');
    component.removeChipFromList(index);
    expect(component.removeChipFromList).toHaveBeenCalledWith(index);
    expect(component.control.value.splice(index, 1).length).toEqual(1);

    expect(component.chipIndex).toBeUndefined();
    expect(component.removeChipActivated).toBeUndefined();
  });

  it('should activateRemoveChip', () => {
    const event = {
      chipIndex: 1,
      removeChipActivated: true,
    };
    spyOn(component, 'activateRemoveChip').and.callThrough();
    component.activateRemoveChip(event);
    expect(component.chipIndex).toEqual(event.chipIndex);
    expect(component.removeChipActivated).toEqual(event.removeChipActivated);
    expect(component.pointerOnChip).toBeFalse();
  });

  it('should call removeChipFromList() when onBlur is called with event, chipIndex != 0 and removeChipActivated = true.', () => {
    component.enableRemoveChipFromList = true;
    component.pointerOnChip = false;
    component.chipIndex = 0;
    component.removeChipActivated = true;

    const event = {
      relatedTarget: {
        id: 'chip_close',
        placeholder: 'test',
      },
      preventDefault: () => {},
    };
    component.autoCompleteInput = {
      nativeElement: jasmine.createSpyObj('nativeElement', ['focus']),
    };

    spyOn(component, 'onBlur').and.callThrough();
    spyOn(component, 'removeChipFromList').and.callThrough();
    component.onBlur(event);
    fixture.detectChanges();
    expect(component.onBlur).toHaveBeenCalledWith(event);
    expect(component.removeChipFromList).toHaveBeenCalledWith(0);
    expect(component.chipIndex).toBeUndefined();
    expect(component.removeChipActivated).toBeUndefined();
  });

  it('should call triggerAcceptChanges when onBlur is called with pointerOnChip is false and chipIndex and removeChipActivated are undefined.', () => {
    component.enableRemoveChipFromList = true;
    component.pointerOnChip = false;
    spyOn(component, 'triggerAcceptChanges');
    const event = new MouseEvent('blur');
    spyOn(event, 'preventDefault');
    component.onBlur(event);
    fixture.detectChanges();
    expect(component.triggerAcceptChanges).toHaveBeenCalled();
  });

  it('should execute preventDefault when onBlur is called with an relatedTarget.id', () => {
    component.pointerOnChip = false;
    component.chipIndex = undefined;
    component.removeChipActivated = undefined;

    const event = {
      relatedTarget: {
        id: 'chip_close',
        click: () => '',
      },
      preventDefault: () => {},
    };
    const evt = spyOn(event, 'preventDefault').and.callThrough();
    component.ID = 'chip';
    component.matAutoComplete = jasmine.createSpyObj('isOpen', ['']);
    component.onBlur(event);
    expect(evt).toHaveBeenCalled();
  });

  it('should call triggerAcceptChanges() when pointerOnChip is false and removeChipActivated is undefined.', () => {
    component.enableRemoveChipFromList = true;
    component.pointerOnChip = false;
    component.chipIndex = undefined;
    component.removeChipActivated = undefined;

    component.onClick();
    fixture.detectChanges();
    spyOnProperty(component.matAutoComplete, 'isOpen').and.returnValue(false);
    const event = {
      relatedTarget: {
        click: () => '',
      },
    };
    spyOn(component, 'triggerAcceptChanges').and.callThrough();
    component.onBlur(event);
    expect(component.triggerAcceptChanges).toHaveBeenCalled();
  });

  it('should call triggerAcceptChanges when onBlur() is called with pointerChip is undefined or a click outside the field.', () => {
    component.enableRemoveChipFromList = true;
    component.pointerOnChip = undefined;
    component.matAutoComplete = jasmine.createSpyObj('isOpen', ['']);

    const event = {
      relatedTarget: {
        click: () => '',
      },
    };
    spyOn(component, 'triggerAcceptChanges');
    component.onBlur(event);
    expect(component.triggerAcceptChanges).toHaveBeenCalled();
  });

  it('should call triggerAcceptChanges when onBlur() is called with pointerChip is undefined/false and event as empty object.', () => {
    component.enableRemoveChipFromList = true;
    component.pointerOnChip = undefined;
    component.removeChipActivated = undefined;
    component.matAutoComplete = jasmine.createSpyObj('isOpen', ['']);

    const event = {};
    spyOn(component, 'triggerAcceptChanges');
    component.onBlur(event);
    expect(component.triggerAcceptChanges).toHaveBeenCalled();
  });

  it('should set focus on autoCompleteInput when onBlur is called and pointerOnChip is true.', () => {
    component.enableRemoveChipFromList = true;
    component.pointerOnChip = true;
    component.inputField = {
      nativeElement: jasmine.createSpyObj('nativeElement', ['focus']),
    };

    component.onBlur(event);
    expect(component.inputField.nativeElement.focus).toHaveBeenCalled();
  });

  it('should set focus on autoCompleteInput when onBlur is called and pointerOnChip is true with chipIndex & removeChipActivated as true.', () => {
    component.enableRemoveChipFromList = true;
    component.pointerOnChip = true;
    component.chipIndex = 1;
    component.removeChipActivated = true;
    component.autoCompleteInput = {
      nativeElement: jasmine.createSpyObj('nativeElement', ['focus']),
    };

    component.onBlur(event);
    expect(component.autoCompleteInput.nativeElement.focus).toHaveBeenCalled();
  });

  it('should remove an item from control and set focus on autoCompleteInput when removeChipFromList is called with an index.', () => {
    const index = 1;
    component.control.setValue(['Rama', 'Siva', 'Varma']);

    spyOn(component, 'removeChipFromList').and.callThrough();
    const splicesArr = component.control.value.splice(index, 1);
    expect(splicesArr).toEqual(['Siva']);

    component.autoCompleteInput = {
      nativeElement: jasmine.createSpyObj('nativeElement', ['focus']),
    };

    component.removeChipFromList(index);

    expect(component.autoCompleteInput.nativeElement.focus).toHaveBeenCalled();
    expect(component.chipIndex).toEqual(undefined);
    expect(component.removeChipActivated).toEqual(undefined);
  });

  it('should set focus on the autoCompleteInput when matChipClicked is called with event == true.', () => {
    component.enableRemoveChipFromList = true;
    const event = true;
    component.inputField = {
      nativeElement: jasmine.createSpyObj('nativeElement', ['focus']),
    };
    spyOn(component, 'matChipClicked').and.callThrough();

    component.matChipClicked(event);
    expect(component.matChipClicked).toHaveBeenCalledWith(event);
    expect(component.inputField.nativeElement.focus).toHaveBeenCalled();
  });

  it('should set pointerOnChip value as false when matChipClicked is called with event == false.', () => {
    const event = false;
    spyOn(component, 'matChipClicked').and.callThrough();
    component.matChipClicked(event);
    expect(component.pointerOnChip).toBeFalse();
  });

  it('should toggle the mouseOnChip value upon calling mouseOverChip().', () => {
    let event = true;
    component.enableRemoveChipFromList = true;

    spyOn(component, 'mouseOverChipData').and.callThrough();
    component.mouseOverChipData(event);
    expect(component.mouseOverChipData).toHaveBeenCalledWith(event);
    expect(component.mouseOnChip).toEqual(true);

    event = false;
    component.mouseOverChipData(event);
    expect(component.mouseOverChipData).toHaveBeenCalledWith(event);
    expect(component.mouseOnChip).toEqual(false);
  });

  it('should activate removeChipActivated flag and capture index of chip when mouseOverRemoveChip() is called.', () => {
    component.enableRemoveChipFromList = true;

    let event = 1;
    component.removeChipActivated = false;

    spyOn(component, 'mouseOverRemoveChip').and.callThrough();
    component.mouseOverRemoveChip(event);
    expect(component.mouseOverRemoveChip).toHaveBeenCalledWith(event);
    expect(component.removeChipActivated).toEqual(true);
    expect(component.removeChipActivatedOn).toEqual(event);

    event = -1;
    component.mouseOverRemoveChip(event);
    expect(component.mouseOverRemoveChip).toHaveBeenCalledWith(event);
    expect(component.removeChipActivated).toEqual(false);
  });

  it('should call mouseOverOption and set values for mouseOnMatCompleteList and mouseOnMatCompleteListValue.', () => {
    component.enableRemoveChipFromList = true;
    const entered = true;
    const value = true;

    spyOn(component, 'mouseoverOption').and.callThrough();
    component.mouseoverOption(entered, value);

    expect(component.mouseoverOption).toHaveBeenCalledWith(entered, value);
    expect(component.mouseOnMatCompleteList).toEqual(entered);
    expect(component.mouseOnMatCompleteListValue).toEqual(value);
  });

  it('should add chip or value to existing control.value.', () => {
    component.enableRemoveChipFromList = true;
    const event = {};
    const blur = spyOn(component, 'onBlur').and.callThrough();
    const blurHandler = spyOn(component, 'blurEventHanlder').and.callThrough();
    spyOn(component.control.value, 'push');

    component.pointerOnChip = false;
    component.removeChipActivated = false;

    component.mouseOnMatCompleteList = true;
    component.mouseOnMatCompleteListValue = 'Rama';

    component.inputField = {
      nativeElement: {
        value: 'Test',
      },
    };

    component.control.setValue(['Siva', 'Varma']);

    component.onBlur(event);
    expect(blur).toHaveBeenCalledWith(event);
    expect(blurHandler).toHaveBeenCalledWith(event);
    expect(component.mouseOnMatCompleteList).toEqual(false);
    expect(component.inputField.nativeElement.value).toEqual('');
  });
});
