import { Component } from '@angular/core';
import { FormControl, ReactiveFormsModule, UntypedFormControl } from '@angular/forms';
import { BrowserAnimationsModule, provideAnimations } from '@angular/platform-browser/animations';
import { Info, Mode, Modes } from '@enterprise-components/common';
import { applicationConfig, Meta, moduleMetadata, StoryObj } from '@storybook/angular';
import { AALButtonToggleInputComponent } from './button-toggle-input.component';

@Component({
  selector: 'aal-button-toggle-input-wrapper',
  standalone: true,
  template: `
    <aal-button-toggle-input
      [ID]="ID"
      [isNullable]="isNullable"
      [controlType]="controlType"
      [control]="control"
      [help]="help"
      [alert]="alert"
      [layout]="layout"
      [placeholder]="placeholder"
      [options]="options"
      [optionLabelField]="optionLabelField"
      [optionValueField]="optionLabelField"
      [label]="label"
      [showEditableDiv]="showEditableDiv"
      [secondaryControl]="secondaryControl"
      [secondaryControlHelp]="secondaryControlHelp"
      [secondaryControlID]="secondaryControlID"
      [secondaryControlPlaceholder]="secondaryControlPlaceholder"
      [secondaryControlAlert]="secondaryControlAlert"
      [secondaryControlMinLength]="secondaryControlMinLength"
      [valuesWhereSecondaryControlIsApplicable]="valuesWhereSecondaryControlIsApplicable"
      [valuesWhereSecondaryControlIsMandatory]="valuesWhereSecondaryControlIsMandatory"
      [mode]="mode"
      [lockMode]="lockMode"
      (acceptChanges)="acceptChanges($event)"
      (rejectChanges)="rejectChanges($event)"
      (acceptSecondaryControlChanges)="acceptSecondaryControlChanges($event)"
      (rejectSecondaryControlChanges)="rejectSecondaryControlChanges($event)"
      (revertSecondaryControlChanges)="revertSecondaryControlChanges($event)">
    </aal-button-toggle-input>
  `,
  imports: [ReactiveFormsModule, AALButtonToggleInputComponent, AALButtonToggleInputComponent],
})
class ButtonToggleInputWrapperComponent {
  ID: string = 'button_toggle_input';
  isNullable: boolean = true;
  controlType: string = 'button';
  control: UntypedFormControl = new UntypedFormControl('');
  help: Info = new Info(
    'Help Title',
    'This is help message with <a target="_blank" href="https://www.google.com">link </a>',
    'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif',
    'https://upload.wikimedia.org/wikipedia/en/6/6c/ec_Holding_N.V._logo.svg',
    null,
  );
  alert: Info = new Info(
    'Error Title',
    'This is error message with <a target="_blank" href="https://www.google.com">link </a>',
    'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif',
    'https://upload.wikimedia.org/wikipedia/en/6/6c/ec_Holding_N.V._logo.svg',
    'ERROR',
  );
  layout: string = 'column';
  placeholder: string = 'Select an option';
  options: any[] = [
    { name: 'option1', description: 'option1' },
    { name: 'option2', description: 'option2' },
    { name: 'option3', description: 'option3' },
  ];
  optionLabelField: string = 'description';
  optionValueField: string = 'name';
  label: string = 'Select Object';
  showEditableDiv: boolean = false;
  secondaryControl: FormControl = new FormControl('');
  secondaryControlHelp: Info = new Info(
    'Help Title',
    'This is help message with <a target="_blank" href="https://www.google.com">link </a>',
    'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif',
    'https://upload.wikimedia.org/wikipedia/en/6/6c/ec_Holding_N.V._logo.svg',
    null,
  );
  secondaryControlID: string = 'button_toggle_input_secondary';
  secondaryControlPlaceholder: string = 'Explain here';
  secondaryControlAlert: Info = new Info(
    'Alert Title',
    'This is alert message.',
    null,
    null,
    'WARNING',
  );
  secondaryControlMinLength: number = 5;
  valuesWhereSecondaryControlIsApplicable: string[] = ['option2', 'option3'];
  valuesWhereSecondaryControlIsMandatory: string[] = ['option2'];
  mode: Mode = Modes.READ;
  lockMode: Mode = Modes.EDIT;

  acceptChanges(event: any) {
    console.log('Accepted changes:', event);
  }

  rejectChanges(event: any) {
    console.log('Rejected changes:', event);
  }

  acceptSecondaryControlChanges(event: any) {
    console.log('Accepted secondary control changes:', event);
  }

  rejectSecondaryControlChanges(event: any) {
    console.log('Rejected secondary control changes:', event);
  }

  revertSecondaryControlChanges(event: any) {
    console.log('Reverted secondary control changes:', event);
  }
}

const meta: Meta<ButtonToggleInputWrapperComponent> = {
  title: 'Enterprise Components/Molecules/Button Toggle Input',
  component: ButtonToggleInputWrapperComponent,
  tags: ['autodocs'],
  decorators: [
    moduleMetadata({
      imports: [BrowserAnimationsModule],
    }),
    applicationConfig({
      providers: [provideAnimations()],
    }),
  ],
  parameters: {
    docs: {
      description: {
        component: `Draft:
          A wrapper for the \`aal-button - toggle - input\` component, showcasing its configurations and variations.`,
      },
    },
  },
  argTypes: {
    ID: { control: 'text', description: 'Unique identifier for the component.' },
    isNullable: { control: 'boolean', description: 'Whether the input can be null.' },
    mode: {
      control: { type: 'select', options: ['READ', 'EDIT', 'PROTECTED'] },
      description: 'Mode of the component.',
    },
    lockMode: {
      control: { type: 'select', options: ['READ', 'EDIT', 'PROTECTED'] },
      description: 'Mode of the component.',
    },
    options: { control: 'object', description: 'Options for the dropdown or toggle.' },
    secondaryControlMinLength: {
      control: 'number',
      description: 'Minimum length for the secondary control input.',
    },
  },
};

export default meta;
type Story = StoryObj<ButtonToggleInputWrapperComponent>;

export const ObjectBased: Story = {
  args: {
    ID: 'button_toggle_input_object',
    isNullable: true,
    controlType: 'button',
    control: new FormControl(''),
    help: new Info('Help Title', 'This is help message.', null, null, null),
    alert: new Info('Alert Title', 'This is alert message.', null, null, 'ERROR'),
    layout: 'column',
    options: [
      { name: 'option1', description: 'option1' },
      { name: 'option2', description: 'option2' },
      { name: 'option3', description: 'option3' },
    ],
    secondaryControl: new FormControl(''),
    mode: Modes.EDIT,
    lockMode: Modes.EDIT,
    showEditableDiv: true,
  },
};
