import { NgModule } from '@angular/core';
import { AALButtonToggleInputComponent } from './button-toggle-input.component';

@NgModule({
  imports: [AALButtonToggleInputComponent],
  exports: [AALButtonToggleInputComponent],
})
export class AALButtonToggleInputModule {}
