/*
 * Public API Surface of material
 */

export * from './button-toggle-input.component';
/**
 * @deprecated Use standalone `AALButtonToggleInputComponent` instead.
 */
export * from './button-toggle-input.module';
