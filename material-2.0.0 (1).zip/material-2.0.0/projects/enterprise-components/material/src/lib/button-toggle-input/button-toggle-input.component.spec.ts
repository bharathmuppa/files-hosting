import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { UntypedFormControl, Validators } from '@angular/forms';
import { Info } from '@enterprise-components/common';

import { InputTextComponent } from '../input-text/input-text.component';
import { OverlayCardErrorModule } from '../overlay-card-alert/overlay-card-alert.module';
import { OverlayCardHelpModule } from '../overlay-card-help/overlay-card-help.module';
import { AALFixedInputCompositeFormControlComponent } from '../shared/fixed-input-composite-form-control.component';
import { SharedFormModule } from '../shared/shared-form.module';
import { SharedMaterialModule } from '../shared/shared-material.module';
import { ToolbarConfirmModule } from '../toolbar-confirm/toolbar-confirm.module';
import { AALButtonToggleInputComponent } from './button-toggle-input.component';

describe('AALButtonToggleInputComponent', () => {
  let component: AALButtonToggleInputComponent;
  let fixture: ComponentFixture<AALButtonToggleInputComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        ToolbarConfirmModule,
        OverlayCardHelpModule,
        OverlayCardErrorModule,
        AALButtonToggleInputComponent,
        InputTextComponent,
      ],
    })
      .compileComponents()
      .then(() => {});
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALButtonToggleInputComponent);
    component = fixture.componentInstance;
    component.control = new UntypedFormControl(
      'actual val',
      Validators.compose([Validators.required]),
    );
    component.secondaryControl = new UntypedFormControl('actual val', Validators.compose([]));
    component.help = new Info('Sample Title', 'Sample Help Message', '', '', null);
    component.options = [
      { name: 'abc', label: 'Abc', sequence: 1, isDescriptionAvailable: true },
      { name: 'xyz', label: 'Xyz', sequence: 2, isDescriptionAvailable: false },
    ];
    fixture.detectChanges();
    jasmine.clock().uninstall();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should return, when onButtonToggleBlur is triggered and related target is one of the button toggle options', () => {
    component.hyphenatedID = 'test';
    const retValue = component.onButtonToggleBlur({
      relatedTarget: { id: component.hyphenatedID + '_button_toggle_1', classList: {} },
    });
    expect(retValue).toEqual(undefined);
  });

  it('should set appropriate mode, when resetMode is triggered and related target is not one of the button toggle options', () => {
    component.resetMode({ relatedTarget: null });
    expect(component.mode).toBe('READ');
  });

  it('should set appropriate mode, when onButtonToggleBlur is triggered, no relatedTarget exists or related target is not one of the button toggle options', () => {
    component.onButtonToggleBlur({ relatedTarget: null });
    expect(component.mode).toBe('READ');
  });

  it('should set appropriate mode, when onKeyUp is triggered and ESC key is pressed', () => {
    component.onKeyUp({
      key: 'Escape',
      currentTarget: {
        children: [],
      },
    });
    expect(component.mode).toBe('READ');
  });

  it('should focus on the next option, when onKeyUp is triggered and ArrowRight key is pressed', () => {
    const spy = spyOn(component, 'navigateOptions').and.callThrough();
    const event = {
      key: 'ArrowRight',
      currentTarget: {
        children: [
          {
            classList: {
              contains: () => {
                return true;
              },
              add: () => {},
            },
            focus: () => {},
          },
          {
            classList: {
              contains: () => {
                return true;
              },
              add: () => {},
            },
            focus: () => {},
          },
        ],
      },
    };
    component.onKeyUp(event);
    expect(spy).toHaveBeenCalled();
  });

  it('should focus on the previous option, when onKeyUp is triggered and ArrowLeft key is pressed', () => {
    const spy = spyOn(component, 'navigateOptions').and.callThrough();
    const event = {
      key: 'ArrowLeft',
      currentTarget: {
        children: [
          {
            classList: {
              contains: () => {
                return true;
              },
              add: () => {},
            },
            focus: () => {},
          },
          {
            classList: {
              contains: () => {
                return true;
              },
              add: () => {},
            },
            focus: () => {},
          },
        ],
      },
    };
    component.onKeyUp(event);
    expect(spy).toHaveBeenCalled();
  });

  it('should select the appropriate option, when onKeyUp is triggered and an alphabet key is pressed', () => {
    const event = {
      key: 'S',
      currentTarget: {
        children: [
          {
            innerText: 'Test',
          },
          {
            innerText: 'Select Option',
            children: [
              {
                click: () => {},
              },
            ],
          },
        ],
      },
    };
    const spy = spyOn(event.currentTarget.children[1].children[0], 'click');
    component.onKeyUp(event);
    expect(spy).toHaveBeenCalled();
  });

  it('should reset the control, when onKeyUp is triggered, the control has a value and C key is pressed', () => {
    const spy = spyOn(component, 'resetControl');
    component.control = new UntypedFormControl('Opt 1');
    component.onKeyUp({
      key: 'C',
      currentTarget: {
        children: [
          {
            innerText: 'Test',
          },
          {
            innerText: 'Select Option',
          },
        ],
      },
    });
    expect(spy).toHaveBeenCalled();
  });

  it('should focus on the button toggle, when onClick is triggered', () => {
    component.buttonToggle = {
      focus: () => {},
    };
    spyOn(AALFixedInputCompositeFormControlComponent.prototype, 'onClick').and.callFake(() => {});
    const spy = spyOn(component.buttonToggle, 'focus');
    jasmine.clock().install();
    component.onClick();
    jasmine.clock().tick(300);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });

  it('should call parent controlTabbedOut method, when onBlur is triggered and relatedTarget is an unrelated element', () => {
    const spy = spyOn(AALFixedInputCompositeFormControlComponent.prototype, 'controlTabbedOut');
    const elem = document.createElement('div');
    const event = new FocusEvent('focus', { relatedTarget: elem });
    component.onButtonToggleBlur(event);
    expect(spy).toHaveBeenCalled();
  });
});
