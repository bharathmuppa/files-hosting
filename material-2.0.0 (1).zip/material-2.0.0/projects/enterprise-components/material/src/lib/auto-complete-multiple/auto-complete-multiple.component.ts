import { CommonModule } from '@angular/common';
import {
  AfterViewInit,
  Component,
  ElementRef,
  input,
  OnChanges,
  OnInit,
  ViewChild,
} from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatAutocomplete,
  MatAutocompleteModule,
  MatAutocompleteTrigger,
} from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatChipsModule } from '@angular/material/chips';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import {
  AALAutoCompleteFormControlComponent,
  AALCommonComponentsModule,
  AALCommonModule,
  HistoryService,
} from '@enterprise-components/common';
import { AtomChipComponent } from '../atoms/atom-chip/public-api';
import { OverlayCardErrorModule } from '../overlay-card-alert/overlay-card-alert.module';
import { OverlayCardHelpModule } from '../overlay-card-help/overlay-card-help.module';
import { CommonMaterialComponentErrorStateMatcher } from '../shared/common-material-component.error-state-matcher';
import { ToolbarConfirmModule } from '../toolbar-confirm/toolbar-confirm.module';

@Component({
  selector: 'aal-auto-complete-multiple',
  standalone: true,
  templateUrl: './auto-complete-multiple.component.html',
  styleUrls: ['./auto-complete-multiple.component.scss'],
  imports: [
    CommonModule,
    MatAutocompleteModule,
    MatChipsModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatButtonModule,
    MatTooltipModule,
    ReactiveFormsModule,
    FormsModule,
    MatDividerModule,
    MatProgressSpinnerModule,
    AALCommonModule,
    AALCommonComponentsModule,
    OverlayCardHelpModule,
    OverlayCardErrorModule,
    ToolbarConfirmModule,
    AtomChipComponent,
  ],
})
export class AutoCompleteMultipleComponent
  extends AALAutoCompleteFormControlComponent
  implements OnInit, OnChanges, AfterViewInit
{
  isControlDisabledInitially: boolean;

  @ViewChild('resultAutoComplete', { static: false }) matAutoComplete: MatAutocomplete;
  @ViewChild('inputField', { read: MatAutocompleteTrigger }) autoTrigger: MatAutocompleteTrigger;
  @ViewChild('inputField') autoCompleteInput: ElementRef;

  chipsRemovable = input<boolean>();
  chipsDisabled = input<boolean>();
  autoActiveFirstOption = input<boolean>();
  highlightOption = input<boolean>();
  enableRemoveChipFromList = input<boolean>();
  showCard = input<boolean>(false);

  errorStateMatcher = new CommonMaterialComponentErrorStateMatcher();
  currentValue: any;
  chipIndex: number;
  removeChipActivated: boolean;
  pointerOnChip: boolean;

  constructor(historyService: HistoryService) {
    super(historyService);
  }

  ngOnInit() {
    super.ngOnInit();
  }

  ngOnChanges() {
    if (this.inputControl && this.control && this.control.disabled) {
      this.isControlDisabledInitially = true;
      this.inputControl.disable();
    }
  }

  /**
   * Clears the value of the form control.
   *
   * This method sets the value of the form control to an empty array, effectively
   * clearing all chips or selected items.
   */
  emptyControl() {
    this.control.setValue([]);
  }

  /**
   * Handles the blur event for the autocomplete input field.
   *
   * Ensures that when the input field loses focus, the appropriate action is triggered.
   * For example, it triggers changes acceptance or handles special cases where the
   * related target is a specific button or part of the autocomplete.
   *
   * @param event The blur event triggered by the input field.
   */
  // TODO: Need to remove this methods too. Keeping them as other legacy components uses it for now
  onInputBlur(event) {
    if (event.relatedTarget && this.matAutoComplete.isOpen) {
      event.relatedTarget.click();
    } else if (event.relatedTarget && event.relatedTarget.id === this.hyphenatedID + '_close') {
      event.preventDefault();
    } else if (
      event.relatedTarget &&
      (!event.relatedTarget.id ||
        (event.relatedTarget.id && event.relatedTarget.id.includes(this.hyphenatedID)))
    ) {
      this.triggerAcceptChanges();
      return;
    } else {
      this.triggerAcceptChanges();
    }
  }

  /**
   * Adds a new chip to the control value.
   *
   * This method is triggered when a user selects an option from the autocomplete
   * or types a value and confirms it. The new value is added to the list of selected chips.
   *
   * @param event The event object containing the selected value.
   * @param input The input element, if available, to clear its value after adding the chip.
   */
  addChip(event: any, input?: HTMLInputElement): void {
    const value = event.value || event.option.value;
    if (value) {
      this.currentValue = this.control.value || [];
      this.currentValue.push(value);
      this.control.setValue(this.currentValue);
    }
    if (input) {
      input.value = '';
    }
  }

  /**
   * Removes a specific chip from the list and focuses the input field.
   *
   * @param item The chip value to be removed.
   * @param inputField The input field element to restore focus after removal.
   */
  removeChip(item: any, inputField: HTMLElement): void {
    const remainingItems = this.control.value.filter((option) => option !== item);
    this.control.setValue(remainingItems);
    inputField.focus();
  }

  /**
   * Handles keyboard interactions for the autocomplete.
   *
   * Supports actions like rejecting changes with `Escape`, accepting changes with `Enter`,
   * or adding a chip when a space key is pressed while an active option is highlighted.
   *
   * @param event The keyboard event triggered by user interaction.
   */
  onKeyUp(event: KeyboardEvent) {
    if (event.key === 'Escape') {
      this.triggerRejectChanges();
    } else if (event.key === 'Enter' && this.autoTrigger && this.inputControl.value !== '') {
      this.inputControl.setValue('');
      this.triggerAcceptChanges();
    } else if (event.key === ' ' && this.autoTrigger && this.autoTrigger.activeOption) {
      this.addChip(this.autoTrigger.activeOption, this.autoCompleteInput.nativeElement);
    }
  }

  /**
   * Removes a chip from the list by its index.
   *
   * This is used when navigating through chips with the keyboard or when a specific chip is activated for removal.
   *
   * @param index The index of the chip to remove.
   */
  removeChipFromList(index) {
    if (index > -1) {
      this.currentValue = this.control.value || [];
      this.currentValue.splice(index, 1);
      this.control.setValue(this.currentValue);
      let inputElement = this.autoCompleteInput.nativeElement as HTMLElement;
      inputElement.focus();
    }
    this.chipIndex = undefined;
    this.removeChipActivated = undefined;
  }

  /**
   * Manages the blur behavior of the component when interacting with chips or input.
   *
   * Handles edge cases like clicking on icons or navigating through chips while maintaining
   * proper focus handling and interaction behavior.
   *
   * @param event The blur event from the input field.
   */
  onBlur(event) {
    if (event?.relatedTarget?.className?.includes('clear-icon')) {
      this.emptyControl();
      return;
    }
    if (!this.pointerOnChip) {
      if (!this.chipIndex && !this.removeChipActivated) {
        this.blurEventHanlder(event);
      } else if (this.chipIndex > -1 && this.removeChipActivated) {
        this.removeChipFromList(this.chipIndex);
      }
    } else if (this.pointerOnChip) {
      if (this.chipIndex > -1 && this.removeChipActivated) {
        this.removeChipFromList(this.chipIndex);
      } else {
        let inputElement = this.autoCompleteInput.nativeElement as HTMLElement;
        inputElement.focus();
      }
    }
  }

  /**
   * Handles specific cases of blur events when interacting with the autocomplete toolbar.
   *
   * Ensures that focus and click events on the toolbar buttons or close icons are managed appropriately.
   *
   * @param event The blur event triggered by the input or toolbar interaction.
   */

  // TODO: Need to remove this methods too. Keeping them as other legacy components uses it for now
  blurEventHanlder(event) {
    if (
      event?.relatedTarget &&
      (this.matAutoComplete.isOpen ||
        event.relatedTarget.id === this.hyphenatedID + '_toolbar_confirm_check')
    ) {
      event.relatedTarget.click();
    } else if (event?.relatedTarget && event.relatedTarget.id === this.hyphenatedID + '_close') {
      event.preventDefault();
    } else if (
      event?.relatedTarget &&
      (!event.relatedTarget?.id ||
        (event.relatedTarget.id && event.relatedTarget.id.includes(this.hyphenatedID)))
    ) {
      this.triggerAcceptChanges();
      return;
    } else {
      this.triggerAcceptChanges();
    }
  }

  /**
   * Activates the chip removal feature and sets the necessary internal state.
   *
   * @param event The event containing details like the chip index and removal activation status.
   */
  // TODO: Need to remove this methods too. Keeping them as other legacy components uses it for now
  activateRemoveChip(event) {
    this.chipIndex = event.chipIndex;
    this.removeChipActivated = event.removeChipActivated;
    this.pointerOnChip = false;
  }

  /**
   * Focuses the input field when a chip is clicked.
   *
   * Ensures proper interaction when the user clicks on a chip, maintaining accessibility and interaction consistency.
   *
   * @param event A boolean indicating if the chip is currently focused.
   */
  // TODO: Need to remove this methods too. Keeping them as other legacy components uses it for now
  matChipClicked(event) {
    if (event) {
      this.pointerOnChip = event;
      let inputElement = this.autoCompleteInput.nativeElement as HTMLElement;
      inputElement.focus();
    } else {
      this.pointerOnChip = false;
    }
  }
}
