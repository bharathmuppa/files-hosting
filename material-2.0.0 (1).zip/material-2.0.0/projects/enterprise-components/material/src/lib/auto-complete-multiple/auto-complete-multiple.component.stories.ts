import { UntypedFormControl } from '@angular/forms';
import { BrowserAnimationsModule, provideAnimations } from '@angular/platform-browser/animations';
import { Modes } from '@enterprise-components/common';
import { applicationConfig, Meta, moduleMetadata, StoryObj } from '@storybook/angular';
import { map, of } from 'rxjs';
import { AutoCompleteMultipleComponent } from './auto-complete-multiple.component';

const meta: Meta<AutoCompleteMultipleComponent> = {
  title: 'Enterprise Components/Molecules/AutoComplete/AutoCompleteMultiple',
  component: AutoCompleteMultipleComponent,
  tags: ['autodocs'],
  decorators: [
    moduleMetadata({
      imports: [BrowserAnimationsModule],
    }),
    applicationConfig({
      providers: [provideAnimations()],
    }),
  ],
  argTypes: {},
};

export default meta;
type Story = StoryObj<AutoCompleteMultipleComponent>;
const control = new UntypedFormControl(null);
const inputMode1 = Modes;
// 1. Simple Default
export const Default: Story = {
  args: {
    help: 'Sample help',
    ID: 'auto-complete-multiple',
    mode: inputMode1.EDIT,
    control: control,
  },
  parameters: {
    docs: {
      description: {
        story: 'Displays the basic auto complete single implementation.',
      },
    },
  },
  render: (args) => ({
    template: `
      <aal-auto-complete-multiple [control]="control"
                                      [ID]="'auto_complete_multiple'"
                                      [label]="label"
                                      [placeholder]="placeholder"
                                      [help]="'This is help text'"
                                      [mode]="mode" [lockMode]="mode"
                                      [dataSource]="dataSource"
                                      [itemDisplayField]="['fullName', 'abbreviation']"
                                      [showItemIcon]="true"
                                      [searchDebounceTime]="searchDebounceTime"
                                      [itemIcon]="'nature'"

></aal-auto-complete-multiple>

    `,
    props: {
      ...args,
      label: 'Select a Fruit',
      searchDebounceTime: 200,
      placeholder: 'Apple / Orange / Banana / .... ',
      dataSource: (searchTerm: string) =>
        of(['Apple', 'Banana', 'Grapes', 'Orange', 'Pineapple']).pipe(
          map((items) =>
            items.filter((item) => item.toLowerCase().includes(searchTerm.toLowerCase())),
          ),
        ),
      onAcceptChanges: ($event: Event) => {
        console.log($event);
      },
      onRejectChanges: ($event: Event) => {
        console.log($event);
      },
    },
  }),
};

const inputMode = Modes;
// 2. Mode as EDIT
export const EditMode: Story = {
  args: {
    help: 'Edit mode enabled',
    mode: inputMode.EDIT,
    lockMode: inputMode.EDIT,
    label: 'Auto complete in EDIT mode',
  },
  parameters: {
    docs: {
      description: {
        story: 'Displays auto complete in EDIT mode always',
      },
    },
  },
  render: (args) => ({
    template: `
      <aal-auto-complete-multiple [control]="control"
                                      [ID]="'auto_complete_multiple'"
                                      [label]="label"
                                      [placeholder]="placeholder"
                                      [help]="'This is help text'"
                                      [mode]="mode" [lockMode]="mode"
                                      [dataSource]="dataSource"
                                      [itemDisplayField]="['fullName', 'abbreviation']"
                                      [showItemIcon]="true"
                                      [searchDebounceTime]="searchDebounceTime"
                                      [itemIcon]="'nature'"

></aal-auto-complete-multiple>
    `,
    props: {
      ...args,
      control: new UntypedFormControl(''),
      searchDebounceTime: 200,
      dataSource: (searchTerm: string) => of(['Item1', 'Item2', 'Item3']),
    },
  }),
};

// 3. Passing Objects for Data Source
export const AutoCompleteAsChips: Story = {
  args: {
    help: 'Sample Help Text',
    mode: inputMode.READ,
    lockMode: inputMode.READ,
    label: 'Auto complete as chips',
  },
  parameters: {
    docs: {
      description: {
        story: 'Displays results as chips when values selected (Default State)',
      },
    },
  },
  render: (args) => ({
    template: `
      <aal-auto-complete-multiple [control]="control"
                                      [ID]="'auto_complete_multiple'"
                                      [label]="label"
                                      [placeholder]="placeholder"
                                      [help]="'This is help text'"
                                      [mode]="mode" [lockMode]="mode"
                                      [dataSource]="dataSource"
                                      [itemDisplayField]="['fullName', 'abbreviation']"
                                      [primaryKeyInValue]="'userID'"
                                      [chipsRemovable]="true"
                            [enableRemoveChipFromList]="true"
></aal-auto-complete-multiple>
    `,
    props: {
      ...args,
      control: new UntypedFormControl([
        {
          abbreviation: 'ALPHA',
          departmentName: 'Engineering',
          email: 'user1@example.com',
          fullName: 'John Doe',
          photoURL: 'https://example.com/photo1.jpg',
          roles: ['developer'],
          userID: 'user1',
        },
      ]),
      dataSource: (searchTerm: string) =>
        of([
          {
            abbreviation: 'ALPHA',
            departmentName: 'Engineering',
            email: 'user1@example.com',
            fullName: 'John Doe',
            photoURL: 'https://example.com/photo1.jpg',
            roles: ['developer'],
            userID: 'user1',
          },
          {
            abbreviation: 'BRAVO',
            departmentName: 'Marketing',
            email: 'user2@example.com',
            fullName: 'Jane Smith',
            photoURL: 'https://example.com/photo2.jpg',
            roles: ['marketingLead'],
            userID: 'user2',
          },
          {
            abbreviation: 'CHARLIE',
            departmentName: 'Human Resources',
            email: 'user3@example.com',
            fullName: 'Alice Johnson',
            photoURL: 'https://example.com/photo3.jpg',
            roles: ['hrSpecialist'],
            userID: 'user3',
          },
        ]),
    },
  }),
};

// 4. History Enabled
export const HistoryEnabled: Story = {
  args: {
    help: 'History feature enabled',
    isHistoryEnabled: true,
    ID: 'user-search',
    label: 'Search People',
  },
  parameters: {
    docs: {
      description: {
        story: 'Displays history when a value was preselected before',
      },
    },
  },
  render: (args) => ({
    template: `
      <aal-auto-complete-multiple [control]="control"
                                      [ID]="'auto_complete_multiple'"
                                      [label]="label"
                                      [placeholder]="placeholder"
                                      [help]="'This is help text'"
                                      [mode]="mode" [lockMode]="mode"
                                      [dataSource]="dataSource"
                                      [itemDisplayField]="['fullName', 'abbreviation']"
                                      [primaryKeyInValue]="'userID'"
                                      [isHistoryEnabled]="true"
                                      [chipsRemovable]="true"
                            [enableRemoveChipFromList]="true"
></aal-auto-complete-multiple>
    `,
    props: {
      ...args,
      control: new UntypedFormControl(''),
      dataSource: (searchTerm: string) =>
        of([
          {
            abbreviation: 'ALPHA',
            departmentName: 'Engineering',
            email: 'user1@example.com',
            fullName: 'John Doe',
            photoURL: 'https://example.com/photo1.jpg',
            roles: ['developer'],
            userID: 'user1',
          },
          {
            abbreviation: 'BRAVO',
            departmentName: 'Marketing',
            email: 'user2@example.com',
            fullName: 'Jane Smith',
            photoURL: 'https://example.com/photo2.jpg',
            roles: ['marketingLead'],
            userID: 'user2',
          },
          {
            abbreviation: 'CHARLIE',
            departmentName: 'Human Resources',
            email: 'user3@example.com',
            fullName: 'Alice Johnson',
            photoURL: 'https://example.com/photo3.jpg',
            roles: ['hrSpecialist'],
            userID: 'user3',
          },
        ]),
    },
  }),
};

// 5. Multiple card auto complete
export const AutoCompleteMultipleWithCard: Story = {
  args: {
    help: 'Sample help text',
    isHistoryEnabled: true,
    ID: 'user-search',
    label: 'Search People',
  },
  parameters: {
    docs: {
      description: {
        story: 'Displays result in card format wen selected',
      },
    },
  },
  render: (args) => ({
    template: `
      <aal-auto-complete-multiple [control]="control"
                                      [ID]="'auto_complete_multiple'"
                                      [label]="label"
                                      [placeholder]="placeholder"
                                      [help]="'This is help text'"
                                      [mode]="mode" [lockMode]="mode"
                                      [dataSource]="dataSource"
                                      [itemDisplayField]="['fullName', 'abbreviation']"
                                      [secondLineItemDisplayFields]="['departmentName']"
                                      [primaryKeyInValue]="'userID'"
                                      [showCard]="true"
></aal-auto-complete-multiple>
    `,
    props: {
      ...args,
      control: new UntypedFormControl(''),
      dataSource: (searchTerm: string) =>
        of([
          {
            abbreviation: 'ALPHA',
            departmentName: 'Engineering',
            email: 'user1@example.com',
            fullName: 'John Doe',
            photoURL: 'https://example.com/photo1.jpg',
            roles: ['developer'],
            userID: 'user1',
          },
          {
            abbreviation: 'BRAVO',
            departmentName: 'Marketing',
            email: 'user2@example.com',
            fullName: 'Jane Smith',
            photoURL: 'https://example.com/photo2.jpg',
            roles: ['marketingLead'],
            userID: 'user2',
          },
          {
            abbreviation: 'CHARLIE',
            departmentName: 'Human Resources',
            email: 'user3@example.com',
            fullName: 'Alice Johnson',
            photoURL: 'https://example.com/photo3.jpg',
            roles: ['hrSpecialist'],
            userID: 'user3',
          },
        ]),
    },
  }),
};
