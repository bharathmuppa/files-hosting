import { NgModule } from '@angular/core';
import { AutoCompleteMultipleComponent } from './auto-complete-multiple.component';

@NgModule({
  imports: [AutoCompleteMultipleComponent],
  exports: [AutoCompleteMultipleComponent],
})
export class AutoCompleteMultipleModule {}
