import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { AALCommonComponentsModule } from '@enterprise-components/common';

import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { CardSummaryComponent } from '../card-summary/card-summary.component';
import { EmptyStateComponent } from '../empty-state/empty-state.component';
import { Category } from '../shared/list-item-configuration.model';
import { SharedFormModule } from '../shared/shared-form.module';
import { SharedMaterialModule } from '../shared/shared-material.module';
import { SharedModule } from '../shared/shared.module';
import { ButtonOverlayCardComponent } from './button-overlay-card.component';

describe('ButtonOverlayCardComponent', () => {
  let component: ButtonOverlayCardComponent;
  let fixture: ComponentFixture<ButtonOverlayCardComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        CardSummaryComponent,
        EmptyStateComponent,
        ButtonOverlayCardComponent,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ButtonOverlayCardComponent);
    component = fixture.componentInstance;
    component.overlayMenuXPosition = 'before';
    component.overlayMenuYPosition = 'above';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit on click of button', () => {
    spyOn(component.submitClick, 'emit');
    component.onsubmit(new Event('click'));
    expect(component.submitClick.emit).toHaveBeenCalled();
  });

  it('setting list item details should create category wise data', () => {
    component.showCategories = true;
    component.listItemDetails = [
      {
        name: 'abc',
        items: [
          {
            title: '1234',
            mainDescription: 'main description',
            subDescription: 'subdescription here',
          },
          {
            title: '12345',
            mainDescription: 'main description2',
            subDescription: 'subdescription here2',
          },
        ],
      },
      {
        name: 'abcd',
        items: [
          {
            title: '1234',
            mainDescription: 'main description',
            subDescription: 'subdescription here',
          },
          {
            title: '12345',
            mainDescription: 'main description2',
            subDescription: 'subdescription here2',
          },
        ],
      },
    ];
    fixture.detectChanges();
    expect(component.listItems).toBeTruthy();
    expect(component.listItems.length).toBe(2);
  });

  it('setting list item details should create category wise data', () => {
    component.showCategories = false;
    component.listItemDetails = [
      { title: '1234', mainDescription: 'main description', subDescription: 'subdescription here' },
      {
        title: '12345',
        mainDescription: 'main description2',
        subDescription: 'subdescription here2',
      },
    ];
    fixture.detectChanges();
    expect(component.listItems.length).toBe(1);
  });

  it('setting list item details should create category wise data', () => {
    component.listItemDetails = {} as Category;
    fixture.detectChanges();
    expect(component.categoryKey).toBe('subCategories');
  });

  it('should set list items', () => {
    component.showCategories = false;
    const listItemDetails = [
      { title: '1234', mainDescription: 'main description', subDescription: 'subdescription here' },
      {
        title: '12345',
        mainDescription: 'main description2',
        subDescription: 'subdescription here2',
      },
    ];
    component.listItemDetails = listItemDetails;
    const spy = spyOnProperty(component, 'listItemDetails').and.callThrough();
    const result = component.listItemDetails;
    expect(spy).toHaveBeenCalled();
  });

  it('should emit event on opening of card', () => {
    spyOn(component.overlayCardOpen, 'emit');
    component.overlayCardOpened();
    expect(component.overlayCardOpen.emit).toHaveBeenCalled();
  });

  it('should emit event on click of item', () => {
    spyOn(component.overlayCardListItemClick, 'emit');
    component.onOverlayCardListItemClick({});
    expect(component.overlayCardListItemClick.emit).toHaveBeenCalled();

    spyOn(component.overLayMenu.close, 'emit');
    component.closeOnItemClick = true;
    component.onOverlayCardListItemClick({});
    expect(component.overLayMenu.close.emit).toHaveBeenCalled();
  });

  it('should emit event on dragging an item', () => {
    spyOn(component.dragDropItems, 'emit');
    const items = [];
    const event = {
      previousIndex: 0,
      currentIndex: 1,
      previousContainer: {},
      container: {},
      item: {},
      isPointerOverContainer: true,
      distance: { x: 3, y: 73 },
    } as CdkDragDrop<string[]>;
    component.onDrop(event, items);
    expect(component.dragDropItems.emit).toHaveBeenCalled();
  });
});
