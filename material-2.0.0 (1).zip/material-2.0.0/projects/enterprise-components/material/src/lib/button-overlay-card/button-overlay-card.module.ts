import { NgModule } from '@angular/core';
import { ButtonOverlayCardComponent } from './button-overlay-card.component';

@NgModule({
  imports: [ButtonOverlayCardComponent],
  exports: [ButtonOverlayCardComponent],
})
export class ButtonOverlayCardModule {}
