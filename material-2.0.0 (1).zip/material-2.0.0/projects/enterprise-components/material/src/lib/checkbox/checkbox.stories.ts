import { UntypedFormBuilder, UntypedFormControl, Validators } from '@angular/forms';

import { Info } from '@enterprise-components/common';

import type { Meta, StoryObj } from '@storybook/angular';
import { fn } from '@storybook/test';

import { CheckboxComponent } from './checkbox.component';

const meta: Meta<CheckboxComponent> = {
  title: 'Enterprise Components/Legacy/Checkbox',
  tags: ['autodocs'],
  component: CheckboxComponent,
};

export default meta;
type Story = StoryObj<CheckboxComponent>;

const fb: UntypedFormBuilder = new UntypedFormBuilder();
const objectFormControl: UntypedFormControl = fb.control([], [Validators.required]);
const objectOptions = [
  {
    name: 'option1',
    description: 'description1 description1 description1 description1 description1',
  },
  { name: 'option2', description: 'test2 test2 test2 test2 test2 test2 test2 test2' },
  { name: 'option3', description: 'test3 test3 test3 test3 test3 test3' },
];
const errorTitle = 'Error Title';
const errorMessage =
  'This is error message with <a target="_blank" href="https://www.google.com">link </a>';
const errorAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
const errorThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ec_Holding_N.V._logo.svg';
const errorLevel = 'ERROR';
const helpTitle = 'Help Title';
const helpMessage =
  'This is help message with <a target="_blank" href="https://www.google.com">link </a>';
const helpAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
const helpThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ec_Holding_N.V._logo.svg';
const alert: Info = new Info(errorTitle, errorMessage, errorAnimation, errorThumbnail, errorLevel);
const help: Info = new Info(helpTitle, helpMessage, helpAnimation, helpThumbnail, null);

// <!-- Storybook:DONE checkbox.stories.ts => ObjectBased-->
export const ObjectBased: Story = {
  args: {
    acceptChanges: fn(),
    control: objectFormControl,
    options: objectOptions,
    alert,
    help,
  },
  render: (args) => {
    return {
      props: args,
      template: `
      <aal-checkbox
        (acceptChanges)="acceptChanges($event)"
        [ID]="'button_radio_object'"
        [control]="control"
        [alert]="alert"
        [help]="help"
        [mode]="'EDIT'"
        [lockMode]="'EDIT'"
        [optionLabelField]="'description'"
        [optionValueField]="'name'"
        [alignOptionsHorizontally]="true"
        [hideLabel]="true"
        [options]="options"
        [disabledOptionsList]="['option2', 'option3']"
        [label]="'Select Object'"
        [placeholder]="'select object'">
      </aal-checkbox>
      `,
    };
  },
};

const fb1: UntypedFormBuilder = new UntypedFormBuilder();
const stringFormControl: UntypedFormControl = fb1.control([], [Validators.required]);
const stringOptions = ['str option1', 'str option2', 'str option3'];

// <!-- Storybook:DONE checkbox.stories.ts => StringBased-->
export const StringBased: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    control: stringFormControl,
    options: stringOptions,
    alert,
    help,
  },
  render: (args) => {
    return {
      props: args,
      template: `
      <aal-checkbox
        [ID]="'button_radio_string'"
        [label]="'Select String'"
        [placeholder]="'select string'"
        [options]="options"
        [control]="control"
        [showHyphenForValues]="[null, '']"
        [disabledOptionsList]="['str option1']"
        [help]="help"
        [alert]="alert"
        (rejectChanges)="onRejectChanges($event)"
        (acceptChanges)="onAcceptChanges($event)">
      </aal-checkbox>
      `,
    };
  },
};

const fb2: UntypedFormBuilder = new UntypedFormBuilder();
const stringFormControl1: UntypedFormControl = fb2.control([], [Validators.required]);
const stringOptions1 = ['str option1', 'str option2', 'str option3'];

// <!-- Storybook:DONE checkbox.stories.ts => stringBasedFireAcceptChangesOnSelect-->
export const StringBasedFireAcceptChangesOnSelect: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    control: stringFormControl1,
    options: stringOptions1,
    alert,
    help,
  },
  render: (args) => {
    return {
      props: args,
      template: `
      <aal-checkbox
        [ID]="'button_radio_string'"
        [label]="'Select String'"
        [placeholder]="'select string'"
        [options]="options"
        [control]="control"
        [showHyphenForValues]="[null, '']"
        [disabledOptionsList]="['str option1']"
        [help]="help"
        [alert]="alert"
        [triggerAcceptOnSelect]="true"
        (rejectChanges)="onRejectChanges($event)"
        (acceptChanges)="onAcceptChanges($event)">
      </aal-checkbox>
      `,
    };
  },
};

// TODO: Make this working
export const StringBasedChangeOnSelect1: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    control: stringFormControl1,
    options: stringOptions1,
    alert,
    help,
    ID: 'button_radio_string',
    label: 'Select String',
    placeholder: 'select string',
    showHyphenForValues: [null, ''],
    disabledOptionsList: ['str option1'],
    triggerAcceptOnSelect: true,
  },
};
