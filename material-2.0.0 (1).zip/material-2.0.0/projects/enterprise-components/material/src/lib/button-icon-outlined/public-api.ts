/*
 * Public API Surface of material
 */

export * from './button-icon-outlined.component';
export * from './button-icon-outlined.module';
