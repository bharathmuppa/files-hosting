import { NgModule } from '@angular/core';
import { ButtonIconOutlinedComponent } from './button-icon-outlined.component';

@NgModule({
  imports: [ButtonIconOutlinedComponent],
  exports: [ButtonIconOutlinedComponent],
})
export class ButtonIconOutlinedModule {}
