import { NgClass } from '@angular/common';
import { Component } from '@angular/core';
import { MatBadge } from '@angular/material/badge';
import { MatButton } from '@angular/material/button';
import { MatIcon } from '@angular/material/icon';
import { MatTooltip } from '@angular/material/tooltip';
import { AALCommonButtonComponent } from '@enterprise-components/common';

@Component({
  selector: 'aal-button-icon-outlined',
  templateUrl: './button-icon-outlined.component.html',
  styleUrls: ['./button-icon-outlined.component.scss'],
  standalone: true,
  imports: [MatButton, MatBadge, NgClass, MatTooltip, MatIcon],
})
export class ButtonIconOutlinedComponent extends AALCommonButtonComponent {}
