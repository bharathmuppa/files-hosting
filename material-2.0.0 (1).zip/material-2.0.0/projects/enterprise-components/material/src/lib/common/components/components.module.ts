import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { AALAutoCompleteFormControlComponent } from './auto-complete-form-control.component';
import { AALCommonButtonComponent } from './common-button.component';
import { AALCommonFormControlComponent } from './common-form-control.component';
import { AALDatePickerFormControlComponent } from './date-picker-form-control.component';
import { AALFixedInputFormControlComponent } from './fixed-input-form-control.component';
import { AALInputFormControlComponent } from './input-form-control.component';

@NgModule({
  declarations: [
    AALCommonFormControlComponent,
    AALInputFormControlComponent,
    AALFixedInputFormControlComponent,
    AALAutoCompleteFormControlComponent,
    AALDatePickerFormControlComponent,
    AALCommonButtonComponent,
  ],
  imports: [CommonModule],
  exports: [
    AALCommonFormControlComponent,
    AALInputFormControlComponent,
    AALFixedInputFormControlComponent,
    AALAutoCompleteFormControlComponent,
    AALCommonButtonComponent,
  ],
})
export class AALCommonComponentsModule {}
