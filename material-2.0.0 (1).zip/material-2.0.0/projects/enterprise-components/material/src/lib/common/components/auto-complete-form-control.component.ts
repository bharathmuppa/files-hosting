import { AfterViewInit, Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { Observable, of } from 'rxjs';
import { catchError, debounceTime, distinctUntilChanged, share, switchMap } from 'rxjs/operators';
import { HistoryService } from '../services/history.service';
import { AALCommonFormControlComponent } from './common-form-control.component';

@Component({
  template: ``,
})
export class AALAutoCompleteFormControlComponent
  extends AALCommonFormControlComponent
  implements OnInit, AfterViewInit
{
  @Input()
  showItemIcon: boolean;
  @Input()
  itemIcon: string;
  @Input()
  itemImageURL: string;
  @Input()
  itemValueField: string;
  @Input()
  dataSource: any;
  @Input()
  propertyBindToImage: string;
  @Input()
  createImageUrlFn: any;
  @Input()
  primaryKeyInValue: string;
  @Input()
  primaryKeyInResult: string;
  @Input()
  showIdenticalResults: boolean;
  @Input()
  separator: string;
  @Input()
  svgIcon: string;
  @Input()
  showOptionsOnFocus: boolean; // applicable only when the options list is defined
  @Input()
  minCharacters: number; // service call will happens only after these characters
  @Input()
  searchDebounceTime: number;
  showPrefix: boolean;
  valuePrefix: string;
  inputControl: UntypedFormControl;
  displayFields: string[];
  secondLineDisplayFields: string[];
  // TODO: R
  // filteredList$ type was changed from <any> to Observable<any[]> because async pipe is throwing below error
  // Type 'unknown' must have a '[Symbol.iterator]()' method that returns an iterator.ngtsc(2488)
  filteredList$: Observable<any[]>;
  initialList$: any;
  isDataLoading: boolean;
  optionsList: any[];
  history: any[];
  @ViewChild('inputField') inputField: ElementRef;

  constructor(historyService: HistoryService) {
    super(historyService);
    this.inputControl = new UntypedFormControl('');
    this.searchDebounceTime = 1500;
  }

  @Input()
  set prefix(value: string) {
    this.valuePrefix = value;
    if (value) {
      this.showPrefix = true; // prefix will be shown in input field, when there is prefix value.
    }
  }

  @Input()
  set itemDisplayField(fields: any) {
    // mapping an array to displayFields based on type of fields.
    if (typeof fields === 'string') {
      this.displayFields = [fields];
    } else {
      this.displayFields = fields;
    }
  }

  @Input()
  set secondLineItemDisplayFields(fields: any) {
    // mapping an array to secondLineDisplayFields based on type of fields.
    if (typeof fields === 'string') {
      this.secondLineDisplayFields = [fields];
    } else {
      this.secondLineDisplayFields = fields;
    }
  }

  get control() {
    return this.frmControl;
  }

  @Input()
  set control(val: UntypedFormControl) {
    this.frmControl = val;
    if (val && val.value !== undefined) {
      // mapping oldValue & setting inputControl if value is not undefined
      this.oldValue =
        typeof val.value === 'object' ? JSON.parse(JSON.stringify(val.value)) : val.value;
      this.inputControl.setValue(
        typeof val.value === 'object' ? JSON.parse(JSON.stringify(val.value)) : val.value,
      );
    }
  }

  ngOnInit() {
    this.setDefaultValue();
    this.history = this.removeControlValues(this.getHistory$()); // this line added to remove control values from history
    this.filteredList$ = this.inputControl.valueChanges.pipe(
      // this will trigger whenever input control get changed
      debounceTime(this.searchDebounceTime),
      distinctUntilChanged(),
      switchMap((ctrl): Observable<any[]> => {
        if (typeof ctrl === 'string' && (ctrl || ctrl === '') && !this.minCharacters) {
          // when minCharacters is not provided
          this.isDataLoading = true;
          this.filterHistory(ctrl); // to get history filtered based on input control
          return this.dataSource(this.inputControl.value);
        } else if (typeof ctrl === 'string' && (ctrl || ctrl === '') && this.minCharacters) {
          //  control should be greater than minCharacters, when minCharacters is provided
          if (ctrl.trim().length >= this.minCharacters) {
            this.isDataLoading = true;
            this.filterHistory(ctrl); // to get history filtered based on input control.
            return this.dataSource(this.inputControl.value);
          } else {
            return this.showOptionsOnFocus ? of(this.optionsList) : of([]);
          }
        }
        return this.showOptionsOnFocus ? of(this.optionsList) : of([]); // showing options on focus, when showOptionsOnFocus is set to true
      }),
      catchError((error) => {
        this.isBusy = false;
        return of([]);
      }),
      share(),
    );

    this.filteredList$.subscribe((value) => {
      // when filteredList altered, removing control values from options & history list
      this.optionsList = this.removeControlValues(value);
      this.isDataLoading = false;
      this.history = this.removeControlValues(this.history);
    });
  }

  filterHistory(value: string): void {
    let itemMatched = false;
    // below line added to remove control values from history before filtering the list.
    this.history = this.removeControlValues(this.getHistory$());

    // this method will filter the history list based on input value provided
    this.history = this.getHistory$().filter((data) => {
      itemMatched = false;
      this.displayFields.forEach((field: string) => {
        if (data && data[field]) {
          itemMatched = itemMatched || data[field].toLowerCase().indexOf(value) > -1;
        }
      });
      return itemMatched;
    });
  }

  // this method is used to remove control values from history list
  removeControlValues(data): any {
    const filteredData = [];
    let isControlEmpty = false;
    let controlValues = [];
    if (!this.primaryKeyInResult) {
      this.primaryKeyInResult = this.primaryKeyInValue;
    }
    if (data && !this.showIdenticalResults && this.control.value) {
      data.forEach((result) => {
        // added below condition, as control is array of objects & data is array of strings, updating data to array of objects.
        if (
          Array.isArray(this.control.value) &&
          this.control.value.length &&
          typeof this.control.value[0] === 'object' &&
          typeof result === 'string'
        ) {
          const dataValue = {};
          dataValue[this.primaryKeyInResult] = result;
          result = dataValue;
        }
        if (
          this.primaryKeyInValue &&
          result.hasOwnProperty(this.primaryKeyInResult) &&
          // if control value is an array
          ((Array.isArray(this.control.value) &&
            this.control.value.findIndex(
              (value) => value[this.primaryKeyInValue] === result[this.primaryKeyInResult],
            ) === -1) ||
            // if control value is an object
            (this.control.value[this.primaryKeyInValue] &&
              this.control.value[this.primaryKeyInValue].indexOf(
                result[this.primaryKeyInResult],
              ) === -1))
        ) {
          filteredData.push(result);
        } else if (
          // if control value is string
          !result.hasOwnProperty(this.primaryKeyInResult) &&
          typeof this.control.value === 'string' &&
          this.control.value.length &&
          this.control.value.indexOf(result) === -1
        ) {
          filteredData.push(result);
        } else if (
          Array.isArray(this.control.value) &&
          typeof this.control.value[0] === 'string' &&
          !this.control.value.includes(result)
        ) {
          filteredData.push(result);
        } else if (Array.isArray(this.control.value) && this.control.value.length === 0) {
          isControlEmpty = true;
        }
      });
      if (isControlEmpty) {
        return data;
      } else {
        return filteredData;
      }
    }
    return data;
  }

  ngAfterViewInit() {
    if (this.control.disabled) {
      this.inputControl.disable(); // disabling input control when control is disabled
    }
  }

  // this method will trigger to click on input, so it can display history items.
  onClick(): void {
    // below line is used to remove control values from history list
    this.history = this.removeControlValues(this.getHistory$());
    super.setModeToEdit(); // to enable input field to Edit mode on click on it
    setTimeout(() => {
      if (this.inputField && this.inputField.nativeElement) {
        this.inputField.nativeElement.focus(); // to focus on input field once it is clicked
      }
    });
  }

  getFieldText() {
    // to display text on the field
    return ((itemObj) => {
      if (itemObj) {
        return this.getDisplayText(itemObj);
      }
    }).bind(this);
  }

  // to display text in the options list
  getDisplayText(item: any, displayFields?: string[]): string {
    const itemData = [];
    displayFields = displayFields || this.displayFields;
    if (displayFields) {
      if (item && typeof item === 'string') {
        return item;
      }
      displayFields.forEach((field: string) => {
        // if display fields is an array of objects, get value from that object else display item.
        if (item && item[field]) {
          itemData.push(item[field].value || item[field]);
        }
      });
      if (this.separator && this.separator === 'Parenthesis') {
        // if separator is provided as Parenthesis, item text should be displayed with parenthesis
        itemData[itemData.length - 1] = '(' + itemData[itemData.length - 1] + ')';
        return itemData.join(' ');
      } else if (this.separator) {
        // if separator is provided, then item text should be displayed with separator.
        return itemData.join(' ' + this.separator + ' ');
      } else {
        return itemData.join(' - ');
      }
    } else {
      return item;
    }
  }

  // to get history list from local storage
  getHistory$(): any[] {
    const history = this.getHistory();
    if (history && history.length > 0) {
      return history;
    }
    return [];
  }

  onKeyUp(event: KeyboardEvent) {
    // Reject changes when escape key is pressed
    if (event.key === 'Escape') {
      this.triggerRejectChanges();
    }
  }
}
