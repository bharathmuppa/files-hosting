import { Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';

import { Observable, of, Subscription } from 'rxjs';
import { HistoryService } from '../services/history.service';
import { AALCommonFormControlComponent } from './common-form-control.component';

export const DEFAULT_ELLIPSIS_AFTER = 40;

@Component({
  template: ``,
})
export class AALFixedInputFormControlComponent
  extends AALCommonFormControlComponent
  implements OnInit, OnDestroy
{
  @Input()
  optionValueField: string;
  @Input()
  optionLabelField: string;
  @Input()
  optionTooltip: string;
  @Input()
  valuesWhereOtherOptionsDisabled: any[];
  @Input()
  disabledOptionsList: any[];
  @Input()
  isNullable: boolean;
  @Input()
  primaryKeyInValue: string;
  @Input()
  controlType = 'notButton';
  disableOtherOptions: boolean;

  @Input()
  set options(values: any[]) {
    this.optionValues = values ? JSON.parse(JSON.stringify(values)) : [];
    this.setOptionType();
    this.sortOptions();
    if (this.isNullable && this.controlType !== 'button') {
      this.setEmptyOption();
    }
  }

  get options(): any[] {
    return this.optionValues;
  }

  @ViewChild('selectField') selectField: any;
  optionType: string;
  @Input()
  ellipsisAfter: number;
  optionValues: any[];
  controlOldValue: any[];
  controlValueChangesSubscription$: Subscription;

  constructor(historyService: HistoryService) {
    super(historyService);
  }

  ngOnInit() {
    this.setDefaultValue();
    if (this.valuesWhereOtherOptionsDisabled) {
      this.controlOldValue = this.control.value || [];
      this.subscribeToControlValueChanges();
      if (this.control.value && this.control.value.length === 1) {
        this.onSelectingOption(this.control.value);
      }
    }
  }

  subscribeToControlValueChanges() {
    this.controlValueChangesSubscription$ = this.control.valueChanges.subscribe((value) => {
      this.onSelectingOption(value.filter((item) => this.controlOldValue.indexOf(item) < 0));
      this.controlOldValue = value;
    });
  }

  setDefaultValue() {
    super.setDefaultValue();
    this.ellipsisAfter =
      this.ellipsisAfter === null || this.ellipsisAfter === undefined
        ? DEFAULT_ELLIPSIS_AFTER
        : this.ellipsisAfter;
  }

  setEmptyOption() {
    const emptyOption = {};
    emptyOption[this.optionValueField] = null;
    emptyOption[this.optionLabelField] = '-- None --';
    if (this.options && this.options[0] && typeof this.options[0] === 'object') {
      this.options.unshift(emptyOption);
    } else {
      this.options.unshift('-- None --');
    }
  }

  setOptionType() {
    if (
      this.options &&
      this.options[0] &&
      typeof this.options[0] === 'object' &&
      this.optionValueField
    ) {
      this.optionType = 'object';
    } else {
      this.optionType = 'string';
    }
  }

  sortOptions() {
    if (this.optionValues && this.optionValues.length > 0 && this.optionType === 'object') {
      this.optionValues = this.optionValues.sort((a, b) => {
        return a.sequence - b.sequence;
      });
    }
  }

  resetControl() {
    this.control.setValue(null);
    this.triggerAcceptChanges();
  }

  onClick(): void {
    super.setModeToEdit();
  }

  onChange($event: unknown): void {
    this.triggerAcceptChanges();
  }

  getDisplayText(): string {
    if (this.control && this.control.value) {
      let outputLabel = '';
      // will be array for select multiple
      if (Array.isArray(this.control.value)) {
        const outputArray = this.control.value.map((value) => {
          return this.getLabelByValue(value);
        });
        outputLabel = outputArray.join(', ');
      } else {
        outputLabel = this.getLabelByValue(this.control.value);
      }
      return outputLabel;
    }
    return '';
  }

  // return Label by type
  getLabelByValue(value: string): string {
    const tempOption =
      this.optionType === 'object'
        ? this.options.find((option) => option[this.optionValueField] === value)
        : value;
    return this.getLabelByOption(tempOption);
  }

  getTooltipByValue(value: string): string {
    const tempOption =
      this.optionType === 'object'
        ? this.options.find((option) => option[this.optionValueField] === value)
        : value;
    return this.getTooltipByOption(tempOption);
  }

  // return Label by type
  getLabelByOption(option: any, skipEllipsis = false): string {
    const optionLabel = this.getLabel(option);
    return optionLabel.length > this.ellipsisAfter && !skipEllipsis
      ? optionLabel.slice(0, this.ellipsisAfter) + ' ...'
      : optionLabel;
  }

  // return Label by type
  getValueByOption(option: any): string {
    return this.getValue(option);
  }

  getTooltipByOption(option: any): string {
    return option && option[this.optionTooltip]
      ? option[this.optionTooltip]
      : this.getLabel(option).length > this.ellipsisAfter
        ? this.getLabel(option)
        : '';
  }

  getLabel(option: any): string {
    return option ? option[this.optionLabelField] || option : '';
  }

  getValue(option: any): string {
    return option ? option[this.optionValueField] || option.value || 'no_value' : '';
  }

  getHistory$(): Observable<any> {
    const history = this.getHistory();
    if (history && history.length > 0) {
      return of(this.getHistory());
    }
    return of([]);
  }

  // compares value to prepopulate selected options in multi select
  compareByValue(optionValue: any, formValue: any): any {
    if (typeof optionValue === 'object') {
      if (this.primaryKeyInValue) {
        return (
          optionValue &&
          formValue &&
          optionValue[this.primaryKeyInValue] === formValue[this.primaryKeyInValue]
        );
      } else {
        // return optionValue && formValue && JSON.stringify(optionValue) === JSON.stringify(formValue);
        let isEqual = true;
        const optionValueKeys = Object.keys(optionValue);
        const formValueKeys = Object.keys(formValue);
        if (optionValueKeys.length !== formValueKeys.length) {
          isEqual = false;
        }
        for (const key of optionValueKeys) {
          if (optionValue[key] !== formValue[key]) {
            isEqual = false;
          }
        }
        return optionValue && formValue && isEqual;
      }
    }
    return optionValue === formValue;
  }

  onSelectingOption(value) {
    if (
      (typeof this.control.value === 'string' &&
        this.valuesWhereOtherOptionsDisabled.includes(value)) ||
      this.valuesWhereOtherOptionsDisabled.filter((item) => value.includes(item)).length > 0
    ) {
      this.controlValueChangesSubscription$.unsubscribe();
      this.control.setValue(value);
      this.subscribeToControlValueChanges();
      this.disableOtherOptions = true;
    } else {
      this.disableOtherOptions = false;
    }
  }

  isOptionDisabled(option: any): boolean {
    if (this.disabledOptionsList) {
      const optionName = this.optionValueField
        ? option[this.optionValueField]
        : option.name
          ? option.name
          : option;
      return !!this.disabledOptionsList.filter(
        (item) => item === optionName || item.name === optionName,
      )[0];
    }

    if (!this.disableOtherOptions) {
      return false;
    }
    const optionValue = this.optionType === 'string' ? option : option[this.optionValueField];
    return (
      !this.control.value.includes(optionValue) &&
      !this.valuesWhereOtherOptionsDisabled.includes(optionValue) &&
      this.disableOtherOptions
    );
  }

  ngOnDestroy(): void {
    if (this.controlValueChangesSubscription$) {
      this.controlValueChangesSubscription$.unsubscribe();
    }
  }
}
