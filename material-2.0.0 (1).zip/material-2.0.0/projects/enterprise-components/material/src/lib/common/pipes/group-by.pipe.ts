/*
Sample Input and output:

Input:

[{ name: "Apple",color: "Green"},
  {name: "Banana",color: "Yellow"},
  { name: "Grape", color: "Green" },
  { name: "Melon", color: "Yellow" },
  { name: "Orange", color: "Orange" }
];

Output:

[{ key: "Green",
   value: [{ name: "Apple", color: "Green" },
            { name: "Grape", color: "Green" }]
  },
  { key: "Yellow",
    value: [{ name: "Banana", color: "Yellow" },
          { name: "Melon", color: "Yellow" }]
  },
  { key: "Orange",
    value: [ { name: "Orange", color: "Orange" }
  }
];

*/

import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'aalGroupBy',
})
export class AALGroupByPipe implements PipeTransform {
  transform(collection: Array<any>, property: string): Array<any> {
    // prevents the application from breaking if the array of objects doesn't exist yet
    // if(!collection) {
    if (collection.length === 0) {
      return null;
    }

    const groupedCollection = collection.reduce((previous, current) => {
      if (!previous[current[property]]) {
        previous[current[property]] = [current];
      } else {
        previous[current[property]].push(current);
      }

      return previous;
    }, {});

    // this will return an array of objects, each object containing a group of objects
    return Object.keys(groupedCollection).map((key) => ({ key, value: groupedCollection[key] }));
  }
}
