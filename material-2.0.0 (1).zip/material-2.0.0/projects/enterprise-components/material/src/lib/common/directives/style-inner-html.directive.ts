import { Directive, ElementRef, Input, OnChanges, SimpleChanges } from '@angular/core';

@Directive({
  selector: '[aalStyleInnerHTML]',
})
export class AALStyleInnerHTMLDirective implements OnChanges {
  @Input()
  customStyle: string;

  @Input()
  text: string;

  @Input()
  specialCharacter: any;

  constructor(public el: ElementRef) {}

  ngOnChanges(changes: SimpleChanges) {
    let elementQuery = '';
    if (changes && changes.text && changes.text.currentValue) {
      changes.text.currentValue.split(this.specialCharacter).forEach((element, index) => {
        if (index === 0 || index % 2 === 0) {
          elementQuery = elementQuery + `<span>${element}</span>`;
        } else {
          elementQuery = elementQuery + `<span style='${this.customStyle}'>${element}</span>`;
        }
      });
      this.el.nativeElement.innerHTML = elementQuery;
    }
  }
}
