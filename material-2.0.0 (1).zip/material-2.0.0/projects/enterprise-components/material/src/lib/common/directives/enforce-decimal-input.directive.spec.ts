import { Component, DebugElement, OnInit, ViewChild } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { AALEnforceDecimalInputDirective } from './enforce-decimal-input.directive';

@Component({
  template: `
    <input
      id="myInput"
      #myInput
      type="text"
      [formControl]="testControl"
      aalEnforceDecimalInput
      [regex]="regex" />
  `,
})
class TestComponent implements OnInit {
  testControl: FormControl;
  regex: RegExp;
  @ViewChild('myInput') myInput;
  constructor(private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.regex = /^-\d+$/;
    this.testControl = new FormControl('001');
  }
}

describe('AALEnforceDecimalInputDirective', () => {
  let component: TestComponent;
  let directive: AALEnforceDecimalInputDirective;
  let fixture: ComponentFixture<TestComponent>;
  let debugElement: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestComponent, AALEnforceDecimalInputDirective],
      imports: [FormsModule, ReactiveFormsModule],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should remove leading zeros from positive number', () => {
    component.testControl.setValue('0002');
    const input = debugElement.query(By.css('#myInput'));
    const inputElement = input.nativeElement;
    inputElement.dispatchEvent(new Event('blur'));
    fixture.detectChanges();
    expect(fixture.componentInstance.testControl.value).toBe('2');
  });

  it('should convert - (negative sign  without trailing digits)  to empty', () => {
    component.testControl.setValue('-');
    const input = debugElement.query(By.css('#myInput'));
    const inputElement = input.nativeElement;
    inputElement.dispatchEvent(new Event('blur'));
    fixture.detectChanges();
    expect(fixture.componentInstance.testControl.value).toBe('0');
  });

  it('should change control value to new value', () => {
    fixture.componentInstance.regex = /^-?\d+$/;
    const input = debugElement.query(By.css('#myInput'));
    const inputElement = input.nativeElement;
    inputElement.value = '-34';
    inputElement.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    expect(fixture.componentInstance.testControl.value).toBe('-34');
  });

  it('should change control value to empty', () => {
    fixture.componentInstance.regex = /^-?\d+$/;
    const input = debugElement.query(By.css('#myInput'));
    const inputElement = input.nativeElement;
    inputElement.value = 'ABC';
    inputElement.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    expect(fixture.componentInstance.testControl.value).toBe('001');
  });

  it('should change control value on event input', () => {
    // fixture.componentInstance.regex = /^-\d+$/;
    const input = debugElement.query(By.css('#myInput'));
    fixture.detectChanges();
    const inputElement = component.myInput.nativeElement;
    inputElement.value = '-';
    inputElement.dispatchEvent(new Event('input'));
    expect(fixture.componentInstance.testControl.value).toBe('-');
  });
});
