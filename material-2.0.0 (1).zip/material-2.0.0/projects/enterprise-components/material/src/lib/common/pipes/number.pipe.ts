import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'aalNumber',
})
export class AALNumberPipe implements PipeTransform {
  static special = [
    '',
    'First',
    'Second',
    'Third',
    'Fourth',
    'Fifth',
    'Sixth',
    'Seventh',
    'Eighth',
    'Ninth',
    'Tenth',
    'Eleventh',
    'Twelfth',
    'Thirteenth',
    'Fourteenth',
    'Fifteenth',
    'Sixteenth',
    'Seventeenth',
    'Eighteenth',
    'Nineteenth',
  ];
  static deca = ['Twent', 'Thirt', 'Fort', 'Fift', 'Sixt', 'Sevent', 'Eight', 'Ninet'];

  private static toWord(n: any): any {
    if (n < 20) {
      return AALNumberPipe.special[n];
    }
    if (n % 10 === 0) {
      return `${AALNumberPipe.deca[Math.floor(n / 10) - 2]}ieth`;
    }
    return `${AALNumberPipe.deca[Math.floor(n / 10) - 2]}y-${AALNumberPipe.special[n % 10]}`;
  }

  transform(value: any, args?: any): any {
    if (args === 'to-word') {
      return AALNumberPipe.toWord(value);
    } else {
      return value;
    }
  }
}
