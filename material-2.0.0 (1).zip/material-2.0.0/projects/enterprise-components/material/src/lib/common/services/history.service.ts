import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class HistoryService {
  constructor() {}

  addItem(key: string, value: any) {
    if (!key || !value) {
      return;
    }
    let currentValue = JSON.parse(localStorage.getItem(key)) || [];
    const currentNumberOfItems = currentValue.length;
    const historyLimit = 4;
    const isValueAnArray = value instanceof Array;
    const resultArray = isValueAnArray
      ? value.concat(currentValue.filter((item) => value.indexOf(item) < 0))
      : [];
    let isValueAlreadyPresent = false;
    let uniqueList = [];
    let valuesList = [];
    // if its an auto complete multiple control
    if (Array.isArray(value)) {
      if (resultArray && resultArray.length) {
        // below code is to store values in the form of array of strings in local storage, as it has both strings and objects.
        resultArray.filter((item) => {
          if (typeof item === 'object' && Object.values(item).length === 1) {
            // if item is an object with only one key value, then only we are making it as string. (ex. id: '1234' => '1234')
            valuesList.push(Object.values(item)[0]);
          } else {
            valuesList.push(item);
          }
        });
        uniqueList = valuesList.filter(
          (v, i, a) => a.findIndex((v2) => JSON.stringify(v2) === JSON.stringify(v)) === i,
        );
        const listToStore =
          uniqueList.length > historyLimit ? uniqueList.slice(0, historyLimit) : uniqueList;
        localStorage.setItem(key, JSON.stringify(listToStore));
        isValueAlreadyPresent = true; // made it true to ignore below conditions
      }
      // if its normal control
    } else {
      isValueAlreadyPresent =
        currentValue.filter((item) => JSON.stringify(item) === JSON.stringify(value)).length > 0;
    }
    if (currentNumberOfItems === 0 && !valuesList.length) {
      // to avoid local storage when control is an array.
      localStorage.setItem(key, JSON.stringify(isValueAnArray ? value : [value]));
    } else if (!isValueAlreadyPresent && currentNumberOfItems < historyLimit) {
      if (isValueAnArray) {
        currentValue =
          resultArray.length > historyLimit ? resultArray.slice(0, historyLimit) : resultArray;
      } else {
        currentValue.unshift(value);
      }
      localStorage.setItem(key, JSON.stringify(currentValue));
    } else if (!isValueAlreadyPresent && currentNumberOfItems === historyLimit) {
      if (isValueAnArray) {
        currentValue =
          resultArray.length > historyLimit ? resultArray.slice(0, historyLimit) : resultArray;
      } else {
        currentValue.splice(historyLimit - 1, 1);
        currentValue.unshift(value);
      }
      localStorage.setItem(key, JSON.stringify(currentValue));
    } else {
      // do nothing
    }
  }

  getItems(key: string): string[] {
    if (!key) {
      return [];
    }
    const currentValue = JSON.parse(localStorage.getItem(key));
    if (currentValue && currentValue.length > 0) {
      return currentValue;
    } else {
      return [];
    }
  }
}
