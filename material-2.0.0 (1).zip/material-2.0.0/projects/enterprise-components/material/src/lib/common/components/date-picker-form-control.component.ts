import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { DateTime } from 'luxon';

import { EndDate } from '../models/presentation.model';
import { HistoryService } from '../services/history.service';
import { AALFixedInputFormControlComponent } from './fixed-input-form-control.component';

@Component({
  template: ``,
})
export class AALDatePickerFormControlComponent
  extends AALFixedInputFormControlComponent
  implements OnInit
{
  @ViewChild('dateSelectInput') dateSelectInput: any;
  selectedValue: Date;
  @Input()
  minDate: Date;
  @Input()
  isPastDateRange: boolean;
  datePickerSelection: any;
  today: Date;
  listValueSelected: boolean;
  endDateForm: EndDate[];
  dateOptions: string[] = ['One Week', 'Two Weeks', 'Three Weeks', 'One Month', 'Two Months'];
  pastDateOptions: string[] = [
    'Last One Week',
    'Last Two Weeks',
    'Last Three Weeks',
    'Last One Month',
    'Last Two Months',
  ];

  constructor(historyService: HistoryService) {
    super(historyService);
    this.listValueSelected = false;
  }

  ngOnInit() {
    super.setDefaultValue();
    this.endDateForm = [];
    this.today = new Date();
    this.minDate = this.minDate || this.today;
    if (this.isPastDateRange) {
      this.dateOptions = this.pastDateOptions;
    }
    this.dateOptions.forEach((date, idx) => {
      const tempDate = {} as EndDate;
      tempDate.name = date;
      tempDate.date = this.getPresetDate(date);
      this.listValueSelected =
        this.listValueSelected || new Date(this.control.value) === tempDate.date;
      this.endDateForm.push(tempDate);
    });
  }

  onClick(): void {
    super.setModeToEdit();
    setTimeout(() => {
      if (this.dateSelectInput) {
        this.dateSelectInput.open();
      }
    }, 100);
  }

  onChange($event?: Event) {
    if (!$event) {
      super.onChange($event);
    }
  }

  getPresetDate(date: string): Date {
    switch (date) {
      case 'One Week':
      case 'Last One Week':
        return this.isPastDateRange
          ? DateTime.now().minus({ weeks: 1 }).toJSDate()
          : DateTime.now().plus({ weeks: 1 }).toJSDate();
      case 'Two Weeks':
      case 'Last Two Weeks':
        return this.isPastDateRange
          ? DateTime.now().minus({ weeks: 2 }).toJSDate()
          : DateTime.now().plus({ weeks: 2 }).toJSDate();
      case 'Three Weeks':
      case 'Last Three Weeks':
        return this.isPastDateRange
          ? DateTime.now().minus({ weeks: 3 }).toJSDate()
          : DateTime.now().plus({ weeks: 3 }).toJSDate();
      case 'One Month':
      case 'Last One Month':
        return this.isPastDateRange
          ? DateTime.now().minus({ months: 1 }).toJSDate()
          : DateTime.now().plus({ months: 1 }).toJSDate();
      case 'Two Months':
      case 'Last Two Months':
        return this.isPastDateRange
          ? DateTime.now().minus({ months: 2 }).toJSDate()
          : DateTime.now().plus({ months: 2 }).toJSDate();
    }
  }
}
