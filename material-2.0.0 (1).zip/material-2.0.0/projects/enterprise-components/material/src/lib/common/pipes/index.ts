import { AALBooleanPipe } from './boolean.pipe';
import { AALDatePipe } from './date.pipe';
import { AALDurationPipe } from './duration.pipe';
import { AALGroupByPipe } from './group-by.pipe';
import { AALHighlightPipe } from './highlight.pipe';
import { AALNumberPipe } from './number.pipe';
import { AALReplacePipe } from './replace.pipe';
import { AALSafePipe } from './safe.pipe';
import { AALSortPipe } from './sort.pipe';

export {
  AALBooleanPipe,
  AALDatePipe,
  AALDurationPipe,
  AALGroupByPipe,
  AALHighlightPipe,
  AALNumberPipe,
  AALReplacePipe,
  AALSafePipe,
  AALSortPipe,
};

export const COMMON_PIPES = [
  AALBooleanPipe,
  AALDatePipe,
  AALDurationPipe,
  AALHighlightPipe,
  AALNumberPipe,
  AALSortPipe,
  AALReplacePipe,
  AALGroupByPipe,
  AALSafePipe,
];
