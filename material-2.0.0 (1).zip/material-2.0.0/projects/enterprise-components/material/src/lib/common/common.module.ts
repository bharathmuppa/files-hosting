import { NgModule } from '@angular/core';
import { COMMON_DIRECTIVES } from './directives/index';
import { AALGroupByPipe } from './pipes/group-by.pipe';
import { COMMON_PIPES } from './pipes/index';

@NgModule({
  declarations: [COMMON_PIPES, COMMON_DIRECTIVES, AALGroupByPipe],
  imports: [],
  exports: [COMMON_PIPES, COMMON_DIRECTIVES],
})
export class AALCommonModule {}
