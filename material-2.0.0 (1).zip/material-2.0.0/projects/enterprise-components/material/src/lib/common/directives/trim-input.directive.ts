import { Directive, HostListener } from '@angular/core';
import { NgControl } from '@angular/forms';

@Directive({
  selector: '[aalTrimInput]',
})
export class AALTrimInputDirective {
  constructor(private readonly ngControl: NgControl) {}

  @HostListener('blur', ['$event']) onBlur() {
    this.trimInputValue();
  }

  @HostListener('keyup.enter', ['$event']) onKeyUp() {
    this.trimInputValue();
  }

  trimInputValue() {
    if (
      this.ngControl &&
      this.ngControl.control &&
      this.ngControl.control.value &&
      this.ngControl.value.length > 0
    ) {
      this.ngControl.control.patchValue(this.ngControl.control.value.trim());
    }
  }
}
