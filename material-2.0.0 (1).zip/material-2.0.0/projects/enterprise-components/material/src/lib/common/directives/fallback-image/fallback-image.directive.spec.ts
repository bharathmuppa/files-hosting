import { Component, ElementRef, Renderer2, runInInjectionContext, signal } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FallbackImageDirective } from './fallback-image.directive';

@Component({
  template: ` <img src="invalid-image.jpg" aalFallbackImage="assets/custom-fallback.png" /> `,
  imports: [FallbackImageDirective],
  standalone: true,
})
class TestHostComponent {}

describe('FallbackImageDirective', () => {
  let fixture: ComponentFixture<TestHostComponent>;
  let mockRenderer: Renderer2;
  let directive: FallbackImageDirective;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TestHostComponent],
      providers: [
        {
          provide: Renderer2,
          useValue: jasmine.createSpyObj('Renderer2', ['setAttribute']),
        },
      ],
    });

    fixture = TestBed.createComponent(TestHostComponent);
    mockRenderer = TestBed.inject(Renderer2);

    // Initialize the directive in an injection context
    runInInjectionContext(fixture.debugElement.injector, () => {
      const hostElement: ElementRef = new ElementRef(fixture.nativeElement.querySelector('img'));
      directive = new FallbackImageDirective(hostElement, mockRenderer);
    });
  });

  it('should create an instance', () => {
    expect(directive).toBeTruthy();
  });

  it('should use the custom fallback image on error', () => {
    // Assign fallbackImage using the provided workaround
    directive.fallbackImage = signal(
      'custom-fallback.png',
    ) as unknown as typeof directive.fallbackImage;

    directive.onError();

    expect(mockRenderer.setAttribute).toHaveBeenCalledWith(
      fixture.nativeElement.querySelector('img'),
      'src',
      'custom-fallback.png',
    );
  });

  it('should use the default image on the second error', () => {
    directive.defaultImage = './assets/fallback-image.png';

    directive.onError(); // First retry
    directive.onError(); // Second retry

    expect(mockRenderer.setAttribute).toHaveBeenCalledWith(
      fixture.nativeElement.querySelector('img'),
      'src',
      './assets/fallback-image.png',
    );
  });

  it('should log an error after exceeding retry attempts', () => {
    spyOn(console, 'error');

    directive.fallbackImage = signal(
      'custom-fallback.png',
    ) as unknown as typeof directive.fallbackImage;
    fixture.detectChanges();
    directive.onError(); // First retry
    directive.onError(); // Second retry
    directive.onError(); // Exceeds retry limit

    expect(console.error).toHaveBeenCalledWith(
      'Image load failed for both source and fallback images after 3 attempts.',
      fixture.nativeElement.querySelector('img'),
    );
  });
});
