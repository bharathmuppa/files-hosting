import { TestBed } from '@angular/core/testing';

import { HistoryService } from './history.service';

describe('HistoryService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({});
  });
  afterEach(() => {
    localStorage.removeItem('keyTest');
    localStorage.removeItem('test');
    localStorage.removeItem('test1');
    localStorage.removeItem('test2');
    localStorage.removeItem('test3');
    localStorage.removeItem('test4');
  });

  it('should be created', () => {
    const service: HistoryService = TestBed.get(HistoryService);
    expect(service).toBeTruthy();
  });

  it('should get empty array when key is not set', () => {
    const service: HistoryService = TestBed.get(HistoryService);
    const noKey = service.getItems('noKey');
    expect(noKey).toEqual([]);
  });

  it('should get return value when key is set in localstorage', () => {
    const service: HistoryService = TestBed.get(HistoryService);
    const noKey = service.getItems('');
    expect(noKey).toEqual([]);
  });

  it('should get empty array when key is not available in localstorage', () => {
    const service: HistoryService = TestBed.get(HistoryService);
    service.addItem('keyTest', 'key test value');
    const key = service.getItems('keyTest');
    expect(key).toEqual(['key test value']);
  });

  it('should return undefined when key or value is not set', () => {
    const service: HistoryService = TestBed.get(HistoryService);
    const returnValue = service.addItem('', '');
    expect(returnValue).toEqual(undefined);
  });

  it('should add value to local storage', () => {
    const service: HistoryService = TestBed.get(HistoryService);
    service.addItem('test', 'test value');
    const localStorageValue = JSON.parse(localStorage.getItem('test'));
    expect(localStorageValue).toEqual(['test value']);
  });

  it('should add array value to local storage', () => {
    const service: HistoryService = TestBed.get(HistoryService);
    service.addItem('test', ['abc', '123', 'def']);
    service.addItem('test', 'test value');
    const localStorageValue = JSON.parse(localStorage.getItem('test'));
    expect(localStorageValue).toContain('test value');
  });

  it('should add strings to history with same key when trigger with different key', () => {
    const service: HistoryService = TestBed.get(HistoryService);
    service.addItem('test1', [
      { abbreviation: 'TST1', departmentName: 'IT', email: 'test1@org.com' },
    ]);
    service.addItem('test2', [
      { abbreviation: 'TST2', departmentName: 'IT', email: 'test2@org.com' },
      { abbreviation: 'TST3', departmentName: 'IT', email: 'test3@org.com' },
      { abbreviation: 'TST4', departmentName: 'IT', email: 'test4@org.com' },
      { abbreviation: 'TST5', departmentName: 'IT', email: 'test5@org.com' },
    ]);
    service.addItem('test2', ['03d', '02d', '02mo', '2yr 3mo 2d']);
    service.addItem('test2', ['04d', '04d', '04mo', '4yr 4mo 4d']);
    service.addItem('test3', ['string1']);
    service.addItem('test4', [2324, 11111]);
    service.addItem('test4', 'this is a test string1');
    service.addItem('test4', 'this is a test string2');
    service.addItem('test4', 'this is a test string3');
    service.addItem('test4', 'this is a test string4');
    const localStorageValue = JSON.parse(localStorage.getItem('test4'));
    expect(localStorageValue).toEqual([
      'this is a test string4',
      'this is a test string3',
      'this is a test string2',
      'this is a test string1',
    ]);
  });
});
