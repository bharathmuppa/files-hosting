import { DomSanitizer } from '@angular/platform-browser';
import { AALSafePipe } from './safe.pipe';

describe('AALSafePipe', () => {
  let domSanitizerMock: DomSanitizer = null;

  beforeAll(() => {
    domSanitizerMock = {
      sanitize(ctx, value) {
        return null;
      },
      bypassSecurityTrustHtml: (value: any) => value.toString(),
      bypassSecurityTrustStyle: (value: any) => value.toString(),
      bypassSecurityTrustScript: (value: any) => value.toString(),
      bypassSecurityTrustUrl: (value: any) => value.toString(),
      bypassSecurityTrustResourceUrl: (value: any) => value.toString(),
    };
  });

  it('create an instance', () => {
    const pipe = new AALSafePipe(domSanitizerMock);
    expect(pipe).toBeTruthy();
  });

  it('it should sanitize html', () => {
    const pipe = new AALSafePipe(domSanitizerMock);
    const result = pipe.transform('asdasd', 'html');
    expect(result).toBeTruthy();
  });

  it('it should sanitize style', () => {
    const pipe = new AALSafePipe(domSanitizerMock);
    const result = pipe.transform('asdasd', 'style');
    expect(result).toBeTruthy();
  });

  it('it should sanitize script', () => {
    const pipe = new AALSafePipe(domSanitizerMock);
    const result = pipe.transform('asdasd', 'script');
    expect(result).toBeTruthy();
  });

  it('it should sanitize url', () => {
    const pipe = new AALSafePipe(domSanitizerMock);
    const result = pipe.transform('asdasd', 'url');
    expect(result).toBeTruthy();
  });

  it('it should sanitize resourceUrl', () => {
    const pipe = new AALSafePipe(domSanitizerMock);
    const result = pipe.transform('asdasd', 'resourceUrl');
    expect(result).toBeTruthy();
  });
  it('it should throw error when type is not matched', () => {
    const pipe = new AALSafePipe(domSanitizerMock);
    const result = pipe.transform('asdasd', 'invalidType');
    expect(result).toEqual(new Error(`Invalid safe type specified: invalidType`));
  });
});
