import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormControl, Validators } from '@angular/forms';

import { Modes, Statuses } from '../models/enumeration.model';
import { Info } from '../models/presentation.model';
import { HistoryService } from '../services/history.service';
import { AALCommonFormControlComponent } from './common-form-control.component';

class HistoryServiceMock {
  historyContainer = { ID: ['sample history with key id'] };

  addItem(key: string, value: string): void {
    this.historyContainer[key] = this.historyContainer[key] || [];
    this.historyContainer[key].push(value);
  }

  getItems(key: string): string[] {
    return this.historyContainer[key];
  }
}

describe('AALCommonFormControlComponent', () => {
  let component: AALCommonFormControlComponent;
  let fixture: ComponentFixture<AALCommonFormControlComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALCommonFormControlComponent],
      providers: [{ provide: HistoryService, useClass: HistoryServiceMock }],
    })
      .compileComponents()
      .then(() => {});
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALCommonFormControlComponent);
    component = fixture.componentInstance;
    component.control = new FormControl('actual value', Validators.compose([Validators.required]));
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should return history (getHistory) length greater then zero when ID is set', () => {
    component.ID = 'ID';
    component.isHistoryEnabled = true;
    expect(component.getHistory().length).toBeGreaterThan(0);
  });

  it('should return control (getControl)', () => {
    expect(component.control).isPrototypeOf(FormControl);
  });

  it('should not show busy indicator initially', () => {
    component.setDefaultValue();
    expect(component.isBusy).toBeFalsy();
  });

  it('should not show toolbar when component is created (setDefaultValue)', () => {
    component.setDefaultValue();
    expect(component.showConfirmationToolbar).toBeFalsy();
  });

  it('should show help in default manner when not specified (setDefaultValue)', () => {
    component.control = new FormControl('test value');
    component.setDefaultValue();
    expect(component.useDefaultAlertDisplay).toBeTruthy();
  });

  it('should set help as Info object if help passed as string (setDefaultValue)', () => {
    component.help = 'test help';
    component.setDefaultValue();
    expect(component.help).isPrototypeOf(Info);
  });

  it('should show validation errors in default manner when not specified (setDefaultValue)', () => {
    component.setDefaultValue();
    expect(component.useDefaultValidationDisplay).toBeTruthy();
  });

  it('should show component in READ mode when not specified (setDefaultValue)', () => {
    component.setDefaultValue();
    expect(component.isModeRead).toBeTruthy();
  });

  it('should disable history when not specified (setDefaultValue)', () => {
    component.setDefaultValue();
    expect(component.isHistoryEnabled).toBeFalsy();
  });

  it('should set status to DRAFT when not specified (setDefaultValue)', () => {
    component.setDefaultValue();
    expect(component.status).toEqual('DRAFT');
  });

  it('has validator should return the validation value', () => {
    component.control = new FormControl('actual val', Validators.compose([Validators.required]));
    expect(component.hasRequiredValidator()).toBe(true);
    component.control.clearValidators();
    expect(component.hasRequiredValidator()).toBe(false);
  });

  it('should return validation message (getValidatorMessage)', () => {
    component.control = new FormControl(
      '',
      Validators.compose([Validators.required, Validators.maxLength(10)]),
    );
    let validationMessage = component.getValidatorMessage('required');
    expect(validationMessage).toEqual('Failed validation: required');

    component.placeholder = 'Text';
    component.control.setValue('Sample text to test the max length of the input field sample text');
    validationMessage = component.getValidatorMessage('maxlength');
    expect(validationMessage).toBe(
      'Text should be less than or equal to 10 characters, actual length is 65 characters.',
    );
  });

  it('should return validation messages (getValidatorMessages) without maxlength required', () => {
    component.control = new FormControl('', Validators.compose([Validators.required]));
    const validationMessage = component.getValidatorMessages();
    expect(validationMessage[0]).toEqual('Failed validation: required');
    component.control.setErrors(null);
    const validationMessageEmpty = component.getValidatorMessages();
    expect(validationMessageEmpty).toEqual([]);
  });

  it('should status be ACCEPTED (triggerAcceptChanges)', () => {
    component.oldValue = 'old value';
    component.isHistoryEnabled = true;
    component.triggerAcceptChanges();
    expect(component.status).toEqual('ACCEPTED');
  });

  it('should not show confirmation toolbar in PROTECTED mode (setModeToEdit)', () => {
    component.showConfirmationToolbar = false;
    component.mode = Modes.PROTECTED;
    component.setModeToEdit();
    expect(component.showConfirmationToolbar).toBeFalsy();
  });

  it('should not show confirmation toolbar in PRIVATE mode (setModeToEdit)', () => {
    component.showConfirmationToolbar = false;
    component.mode = Modes.PRIVATE;
    component.setModeToEdit();
    expect(component.showConfirmationToolbar).toBeFalsy();
  });

  it('should not show confirmation toolbar when BUSY (setModeToEdit)', () => {
    component.control = new FormControl('current value');
    component.showConfirmationToolbar = false;
    component.isBusy = true;
    component.setModeToEdit();
    expect(component.showConfirmationToolbar).toBeFalsy();
  });

  it('should show confirmation toolbar in EDIT mode and NOT BUSY and (setModeToEdit)', () => {
    component.showConfirmationToolbar = false;
    component.mode = Modes.EDIT;
    component.isBusy = false;
    component.setModeToEdit();
    expect(component.showConfirmationToolbar).toBeTruthy();
  });

  it('should return true as mode is EDIT (isModeEdit)', () => {
    component.mode = Modes.EDIT;
    expect(component.isModeEdit()).toBeTruthy();
  });

  it('should return false as mode is NOT EDIT (isModeEdit)', () => {
    component.mode = Modes.PRIVATE;
    expect(component.isModeEdit()).toBeFalsy();
  });

  it('should return true as mode is READ (isModeRead)', () => {
    component.mode = Modes.READ;
    expect(component.isModeRead()).toBeTruthy();
  });

  it('should return false as mode is NOT READ (isModeRead)', () => {
    component.mode = Modes.PRIVATE;
    expect(component.isModeRead()).toBeFalsy();
  });

  it('should return true as mode is PROTECTED (isModeProtected)', () => {
    component.mode = Modes.PROTECTED;
    expect(component.isModeProtected()).toBeTruthy();
  });

  it('should return false as mode is NOT PROTECTED (isModeProtected)', () => {
    component.mode = Modes.PRIVATE;
    expect(component.isModeProtected()).toBeFalsy();
  });

  it('should return true as mode is PRIVATE (isModePrivate)', () => {
    component.mode = Modes.PRIVATE;
    expect(component.isModePrivate()).toBeTruthy();
  });

  it('should return false as mode is NOT PRIVATE (isModePrivate)', () => {
    component.mode = Modes.PROTECTED;
    expect(component.isModePrivate()).toBeFalsy();
  });

  it('should return ID with . (dot) converted to - (hyphens) (getHyphenatedID)', () => {
    component.ID = 'A.B.C.D';
    expect(component.getHyphenatedID()).toBe('A_B_C_D');
  });

  it('should return ID with nothing replaced (getHyphenatedID)', () => {
    component.ID = 'A_B-C_D';
    expect(component.getHyphenatedID()).toBe('A_B-C_D');
  });

  it('should return ID with nothing to replaced (getHyphenatedID)', () => {
    component.ID = '';
    expect(component.getHyphenatedID()).toBe('');
  });

  it('should trigger reject changes & set mode to Read when alert is set (set alert) and mode is EDIT', () => {
    component.mode = Modes.EDIT;
    component['valueToRevert'] = 'sample';
    component.alert = new Info('error message');
    expect(component.mode).toEqual('READ');
  });

  it('should set control to its old value (triggerRejectChanges)', () => {
    component.oldValue = 'old value';
    component.triggerRejectChanges();
    expect(component.control.value).toEqual('old value');
  });

  it('should set control to rejected status (triggerRejectChanges)', () => {
    component.oldValue = 'old value';
    component.triggerRejectChanges();
    expect(component.status).toEqual('REJECTED');
  });

  it('should not set control to REJECTED as old and current values are same (triggerRejectChanges)', () => {
    component.oldValue = 'actual value';
    component.status = Statuses.DRAFT;
    component.triggerRejectChanges();
    expect(component.status).toEqual('DRAFT');
  });

  it('should return placeholder string when it is been triggered', () => {
    component.control = new FormControl(
      { value: 'actual val', disabled: true },
      Validators.compose([Validators.required]),
    );
    fixture.detectChanges();
    component.placeholder = 'test placeholder';
    const returnVal = component.getPlaceholder();
    expect(returnVal).toBe('test placeholder');
  });

  it('should call getFieldLabel return to be string with asterisk', () => {
    component.control = new FormControl(
      { value: 'actual val', disabled: true },
      Validators.compose([Validators.required]),
    );
    fixture.detectChanges();
    component.label = 'test label';
    const returnVal = component.getFieldLabel();
    expect(returnVal).toBe('test label');
  });

  it('should not append asterisk to label when control does not have required validator', () => {
    component.control = new FormControl({ value: 'actual val', disabled: true }, []);
    fixture.detectChanges();
    component.label = 'test label';
    const returnVal = component.getFieldLabel();
    expect(returnVal).toBe('test label');
  });

  it('should call setMode when Control value is set and setDefaultValue is trigger', () => {
    spyOn(component, 'setMode');
    component.control = new FormControl(
      { value: 'actual val', disabled: true },
      Validators.compose([Validators.required]),
    );
    component.setDefaultValue();
    expect(component.setMode).toHaveBeenCalled();
  });

  it('should set the validation message the minimum value length validation', () => {
    component.placeholder = 'Text';
    component.control = new FormControl(
      'test',
      Validators.compose([Validators.required, Validators.minLength(5)]),
    );
    const validationMessage = component.getValidatorMessages();
    expect(validationMessage).toEqual([
      'Text should be more than or equal to 5 characters, actual length is 4 characters.',
    ]);
  });

  it('should set status be ACCEPTED (triggerAcceptChanges) when control value is in object', () => {
    component.newValue = { t1: 'test value' };
    component.oldValue = 'test sample text';
    component.triggerAcceptChanges();
    expect(component.status).toEqual('ACCEPTED');
  });

  it('should set  status be rejected (triggerRejectChanges) when control value is invalid', () => {
    component.control.setErrors({ sampleError: 'sample test error' });
    component.oldValue = 'test sample text';
    component.triggerAcceptChanges();
    expect(component.status).toEqual('REJECTED');
  });
});
