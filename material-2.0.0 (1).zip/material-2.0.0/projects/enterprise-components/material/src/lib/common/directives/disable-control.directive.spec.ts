import { Component, DebugElement, OnInit } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AALDisableControlDirective } from './disable-control.directive';

@Component({
  template: `
    <input
      id="myInput"
      type="text"
      [formControl]="testControl"
      [disableControl]="disableControl"
      aalDisableControl />
  `,
})
class TestComponent implements OnInit {
  testControl: FormControl;
  disableControl: boolean;

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.testControl = this.formBuilder.control(' test value ');
  }
}

describe('AALDisableControlDirective', () => {
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;
  let debugElement: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestComponent, AALDisableControlDirective],
      imports: [FormsModule, ReactiveFormsModule],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create component', () => {
    expect(component).toBeDefined();
  });

  it('should disable control', () => {
    fixture.componentInstance.disableControl = true;
    fixture.detectChanges();
    expect(fixture.componentInstance.testControl.disabled).toBeTruthy();
  });

  it('should enable control', () => {
    fixture.componentInstance.disableControl = false;
    fixture.detectChanges();
    expect(fixture.componentInstance.testControl.disabled).toBeFalsy();
  });
});
