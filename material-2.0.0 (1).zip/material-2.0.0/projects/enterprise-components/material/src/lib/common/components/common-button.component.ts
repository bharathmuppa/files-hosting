import { Component, EventEmitter, Input, Output } from '@angular/core';
import {
  BadgePosition,
  BadgePositions,
  BadgeSize,
  BadgeSizes,
  BadgeType,
  BadgeTypes,
  ButtonTypes,
  IconSize,
  IconSizes,
  ThemeColor,
  ThemeColors,
} from '../models/enumeration.model';
import { HistoryService } from '../services/history.service';
import { AALCommonFormControlComponent } from './common-form-control.component';

@Component({
  template: ``,
})
export class AALCommonButtonComponent extends AALCommonFormControlComponent {
  @Input()
  icon: string;
  @Input()
  svgIcon: string;
  @Input()
  image: string;
  @Input()
  name: string;
  @Input()
  color: ThemeColor;
  @Input()
  tooltip: string;
  @Input()
  hasBadge: boolean = false;
  @Input()
  referenceBadgeData: number;
  @Input()
  badgeType: BadgeType;

  @Input()
  set badgeData(data: number) {
    this.setActualBadgeData(data);
  }

  @Input()
  disabled: boolean;
  @Input()
  iconSize: IconSize;
  @Input()
  badgeColor: ThemeColor;
  @Input()
  isBadgeDisabled: boolean;
  @Input()
  badgePosition: BadgePosition;
  @Input()
  badgeSize: BadgeSize;
  @Output() onClick = new EventEmitter<any>();
  buttonTypes = ButtonTypes;
  @Input()
  iconSizes = IconSizes;
  themeColors = ThemeColors;
  badgePositions = BadgePositions;
  badgeSizes = BadgeSizes;
  actualBadgeData: string;

  constructor(historyService: HistoryService) {
    super(historyService);
    this.setDefaultConfiguration();
  }

  setActualBadgeData(badgeData: number) {
    if (this.badgeType !== 'single') {
      this.actualBadgeData = String(badgeData) + '/' + String(this.referenceBadgeData);
    } else {
      this.actualBadgeData = String(badgeData);
    }
  }

  click($event): void {
    this.onClick.emit($event);
  }

  getBadgeClass() {
    if (!this.actualBadgeData) {
      return '';
    }
    if (String(this.actualBadgeData).length <= 3) {
      return 'raiseBadge--small';
    } else if (String(this.actualBadgeData).length === 4) {
      return 'raiseBadge--medium';
    } else if (
      String(this.actualBadgeData).length > 4 &&
      String(this.actualBadgeData).length <= 7
    ) {
      return 'raiseBadge--large';
    }
  }

  getClassByIconSize(): string {
    if (this.iconSize) {
      return this.iconSize !== this.iconSizes.ExtraLarge
        ? `icon--${this.iconSize}`
        : 'icon--extra-large';
    }
  }

  setDefaultConfiguration(): void {
    this.color = this.color || ThemeColors.Accent;
    this.badgePosition = this.badgePosition || BadgePositions.After;
    this.badgeSize = this.badgeSize || BadgeSizes.Medium;
    this.badgeType = this.badgeType || BadgeTypes.Single;
  }

  getHyphenatedID() {
    return this.ID ? this.ID.replace(/\./g, '_') : '';
  }
}
