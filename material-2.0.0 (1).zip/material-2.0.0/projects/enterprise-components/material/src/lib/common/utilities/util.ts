export class AALUtil {
  static areEqual(obj1: any, obj2: any): boolean {
    if ((obj1 && !obj2) || (!obj1 && obj2) || typeof obj1 !== typeof obj2) {
      return false;
    } else if (typeof obj1 === 'string') {
      return obj1 === obj2;
    } else if (typeof obj1 === 'object') {
      return JSON.stringify(obj1) === JSON.stringify(obj2);
    } else {
      return false;
    }
  }

  static isValuePresentInList(value: any, list: any[]): boolean {
    if (!value || !list || !(list.length > 0)) {
      return false;
    }
    for (const item of list) {
      if (AALUtil.areEqual(value, item)) {
        return true;
      }
    }
    return false;
  }

  static getDateInISOFormat(date: Date | string): string {
    if (!date) {
      return '';
    }
    if (typeof date === 'string') {
      return date;
    }
    return AALUtil.getDateFromDateTime(date).split('T')[0] + 'T12:00:00Z';
  }

  static getDateTimeInISOFormat(date: Date | string): string {
    if (!date) {
      return '';
    }
    if (typeof date === 'string') {
      return date;
    }
    return AALUtil.getDateFromDateTime(date);
  }

  static setDateDefaultTime(date: any): Date {
    if (typeof date === 'string') {
      date = new Date(date); // Convert string to Date object
    }

    if (!(date instanceof Date) || isNaN(date.getTime())) {
      throw new Error('Invalid date argument');
    }

    const dateInUTC = AALUtil.getDateTimeInUTC(date);
    return new Date(dateInUTC);
  }

  static getDateTimeInUTC(date: Date): string {
    const year = date.getUTCFullYear();
    const month = ('0' + (date.getUTCMonth() + 1)).slice(-2);
    const day = ('0' + date.getUTCDate()).slice(-2);
    const hours = ('0' + date.getUTCHours()).slice(-2);
    const minutes = ('0' + date.getUTCMinutes()).slice(-2);
    const seconds = ('0' + date.getUTCSeconds()).slice(-2);
    return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}Z`;
  }

  static getDateFromDateTime(date: Date): string {
    const year = date.getFullYear();
    const month = ('0' + (date.getMonth() + 1)).slice(-2);
    const day = ('0' + date.getDate()).slice(-2);
    const hours = ('0' + date.getHours()).slice(-2);
    const minutes = ('0' + date.getMinutes()).slice(-2);
    const seconds = ('0' + date.getSeconds()).slice(-2);
    return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
  }
}
