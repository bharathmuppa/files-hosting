import { Component, DebugElement, ElementRef, SimpleChange, ViewChild } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { FontTypes, ValueFontSizes } from '../models/enumeration.model';
import { AALChangeFontSizeDirective } from './change-font-size.directive';

describe('AALChangeFontSizeDirective', () => {
  let directive: AALChangeFontSizeDirective;
  let fixture: ComponentFixture<FontSizeComponentTestComponent>;
  let newComponent: FontSizeComponentTestComponent;
  let directiveDeBug: DebugElement;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALChangeFontSizeDirective],
    })
      .compileComponents()
      .then(() => {
        directive = new AALChangeFontSizeDirective(null);
      });
    fixture = TestBed.createComponent(FontSizeComponentTestComponent);
    newComponent = fixture.componentInstance;
    directiveDeBug = fixture.debugElement.query(By.directive(AALChangeFontSizeDirective));

    fixture.detectChanges();
  }));

  it('should create an instance', () => {
    directive = new AALChangeFontSizeDirective(null);
    expect(directive).toBeTruthy();
  });

  it('should set size', () => {
    directive = new AALChangeFontSizeDirective(null);
    directive.fontSize = 'small';
    expect(directive.fontSize).toEqual('small');
  });

  it('should return 16px', () => {
    expect(directive.getFontValue('small')).toEqual('16px');
  });

  it('should return 20px', () => {
    expect(directive.getFontValue('regular')).toEqual('20px');
  });

  it('should return 28px', () => {
    expect(directive.getFontValue('large')).toEqual('28px');
  });

  it('should return 16px (default)', () => {
    expect(directive.getFontValue('something else')).toEqual('16px');
  });

  it('should label return 12px', () => {
    directive.isLabel = true;
    expect(directive.getFontValue('small')).toEqual('12px');
  });

  it('should label return 16px', () => {
    directive.isLabel = true;
    expect(directive.getFontValue('regular')).toEqual('16px');
  });

  it('should label return 20px', () => {
    directive.isLabel = true;
    expect(directive.getFontValue('large')).toEqual('20px');
  });

  it('should label return 12px (default)', () => {
    directive.isLabel = true;
    expect(directive.getFontValue('something else')).toEqual('12px');
  });

  it('should SubLabel return 14px', () => {
    directive.isSubLabel = true;
    expect(directive.getFontValue('small')).toEqual('14px');
  });

  it('should SubLabel return 18px', () => {
    directive.isSubLabel = true;
    expect(directive.getFontValue('regular')).toEqual('18px');
  });

  it('should SubLabel return 24px', () => {
    directive.isSubLabel = true;
    expect(directive.getFontValue('large')).toEqual('24px');
  });

  it('should SubLabel return 14px (default)', () => {
    directive.isSubLabel = true;
    expect(directive.getFontValue('something else')).toEqual('14px');
  });

  it('should verify ElementRef for fontSize is set', () => {
    const currentValue = FontTypes.Large;
    const changeObject = {
      fontSize: new SimpleChange(null, currentValue, false),
    };
    directive.element = newComponent.fontSizeDirective;
    directive.ngOnChanges(changeObject);
    expect(directive.element.nativeElement.style.fontSize).toBe(ValueFontSizes.Large);
  });

  it('should verify ElementRef for lineHeight  is set', () => {
    const currentValue = FontTypes.Large;
    const changeObject = {
      fontSize: new SimpleChange(null, currentValue, false),
    };
    directive.element = newComponent.fontSizeDirective;
    directive.ngOnChanges(changeObject);
    expect(directive.element.nativeElement.style.lineHeight).toBe('28px');
  });
});

@Component({
  selector: 'aal-font-size-selector',
  template: `
    <div aalChangeFontSize #font [fontSize]="'small'">Sample text</div>
  `,
})
export class FontSizeComponentTestComponent {
  @ViewChild('font') fontSizeDirective: ElementRef;
}
