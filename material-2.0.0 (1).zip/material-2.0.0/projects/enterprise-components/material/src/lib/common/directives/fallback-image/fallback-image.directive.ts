import { computed, Directive, ElementRef, HostListener, input, Renderer2 } from '@angular/core';

/**
 * FallbackImageDirective
 *
 * Automatically replaces a broken or invalid image source (`src`) with a fallback image.
 *
 * Usage:
 * - Add the `aalFallbackImage` directive to an `<img>` element.
 * - Optionally, provide a custom fallback image using the `aalFallbackImage` attribute.
 * - If no fallback image is specified, the default image (`./assets/fallback-image.png`) will be used.
 *
 * Examples:
 * 1. Default Fallback:
 *    <img src="invalid-image.jpg" aalFallbackImage alt="Avatar" />
 *
 * 2. Custom Fallback:
 *    <img src="invalid-image.jpg" aalFallbackImage="assets/custom-fallback.png" alt="Avatar" />
 */
@Directive({
  selector: '[aalFallbackImage]',
  standalone: true, // Enables standalone use without importing into a module
})
export class FallbackImageDirective {
  /**
   * Default fallback image for when no custom fallback is provided.
   * This value will be used as a last resort.
   */
  defaultImage = './assets/fallback-image.png';

  /**
   * Custom fallback image, if provided through the directive's attribute.
   */
  fallbackImage = input<string>('', {
    alias: 'aalFallbackImage', // Binds to the `aalFallbackImage` attribute
  });

  /**
   * Resolves the fallback image to use, prioritizing the custom value if provided.
   */
  finalFallbackImage = computed(() => this.fallbackImage() || this.defaultImage);

  /**
   * Tracks the number of retries when attempting to load an image.
   * First retry attempts the custom fallback; subsequent failures log an error.
   */
  private retries = 0;

  constructor(
    private readonly el: ElementRef, // Direct reference to the host DOM element
    private readonly renderer: Renderer2, // Angular service for safely manipulating the DOM
  ) {}

  /**
   * Event listener for the `error` event.
   * Replaces the image source with a fallback and limits retries to prevent infinite loops.
   */
  @HostListener('error') onError() {
    this.retries += 1;

    if (this.retries === 1) {
      // First retry: attempt to load the custom fallback image
      this.updateUrl(this.finalFallbackImage());
    } else if (this.retries === 2) {
      // Second retry: fallback to the default image
      this.updateUrl(this.defaultImage);
    } else {
      // Exceeded retries: log an error
      console.error(
        `Image load failed for both source and fallback images after ${this.retries} attempts.`,
        this.el.nativeElement,
      );
    }
  }

  /**
   * Updates the `src` attribute of the host `<img>` element to the specified URL.
   * @param imageUrl The URL to set as the `src` attribute.
   */
  updateUrl(imageUrl: string) {
    this.renderer.setAttribute(this.el.nativeElement, 'src', imageUrl);
  }
}
