import { AALSortPipe } from './sort.pipe';

describe('AALSortPipe', () => {
  it('create an instance', () => {
    const pipe = new AALSortPipe();
    expect(pipe).toBeTruthy();
  });

  it('should sort array bases on field provided', () => {
    const arrayObject = [
      { name: 'Apple', color: 'Green' },
      { name: 'Banana', color: 'Yellow' },
      { name: 'Grape', color: 'Green' },
      { name: 'Melon', color: 'Yellow' },
      { name: 'Orange', color: 'Orange' },
    ];
    const pipe = new AALSortPipe();
    expect(pipe.transform(arrayObject, 'color')).toEqual([
      { name: 'Apple', color: 'Green' },
      { name: 'Grape', color: 'Green' },
      { name: 'Orange', color: 'Orange' },
      { name: 'Banana', color: 'Yellow' },
      { name: 'Melon', color: 'Yellow' },
    ]);
  });
});
