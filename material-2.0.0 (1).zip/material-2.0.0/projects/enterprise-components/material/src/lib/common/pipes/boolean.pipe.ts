import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'aalBoolean',
})
export class AALBooleanPipe implements PipeTransform {
  transform(value) {
    return value ? 'Yes' : 'No';
  }
}
