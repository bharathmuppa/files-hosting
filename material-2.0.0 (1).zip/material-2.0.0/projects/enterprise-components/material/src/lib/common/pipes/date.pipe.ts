import { DatePipe as ACDatePipe } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';
import { DateTime } from 'luxon';
@Pipe({
  name: 'aalDate',
})
// TODO: This whole pipe needs makeover using luxon
export class AALDatePipe extends ACDatePipe implements PipeTransform {
  transform(value: any, args?: any): any {
    if (value) {
      const currentDate = new Date(new Date().setHours(0, 0, 0, 0));
      const valueDate = new Date(new Date(value).setHours(0, 0, 0, 0));
      const weekNo = this.getWeekNumber(valueDate);
      const weekDay = this.getWeekDay(valueDate);
      const formattedDate = super.transform(value, 'dd MMM yyyy');
      if (args && args === 'dueDate') {
        const dueDay = this.dueDay(currentDate, valueDate);
        const suffix =
          currentDate > valueDate
            ? dueDay === 0
              ? 'Today'
              : `${dueDay}d ago`
            : dueDay === 0
              ? 'Today'
              : `in ${dueDay}d`;
        return `${formattedDate} (${weekNo}.${weekDay}) ${suffix}`;
      } else if (args && args === 'dueDays') {
        const dueDay = this.dueDay(currentDate, valueDate);
        return dueDay === 0 ? 'Today' : `${dueDay}d ago`;
      } else if (args && args === 'dueDateTime') {
        const dueDay = this.dueDay(currentDate, valueDate);
        const suffix =
          currentDate > valueDate
            ? dueDay === 0
              ? 'Today'
              : `${dueDay}d ago`
            : dueDay === 0
              ? 'Today'
              : `in ${dueDay}d`;
        const date = DateTime.fromJSDate(new Date(value)).setZone('local');
        if (!date.isValid) {
          throw new Error('invalid date. Please check the date time you have passed to date pipe');
        }
        return `${formattedDate} (${weekNo}.${weekDay}) ${suffix} ${date.toFormat('HH:mm')}`;
      } else if (args && args === 'time') {
        const time = value.split('T')[1].match(/\d\d:\d\d/);
        return `${formattedDate} (${weekNo}.${weekDay}) ${time[0] || ''}`;
      } else if (args && args === 'week-day') {
        return `wk${weekNo}.${weekDay}`;
      } else {
        return `${formattedDate} (${weekNo}.${weekDay})`;
      }
    }
    return '';
  }

  private dueDay(current, d: Date): number {
    const timeDiff = Math.abs(current.getTime() - d.getTime());
    if (Math.ceil(timeDiff / (1000 * 3600 * 24)) === 1) {
      return current.getDate() === d.getDate() ? 0 : 1;
    }
    return Math.ceil(timeDiff / (1000 * 3600 * 24));
  }

  private getWeekDay(d: Date): number {
    return d.getDay() === 0 ? 7 : d.getDay();
  }

  private getWeekNumber(d: Date): number {
    d = new Date(+d);
    d.setHours(0, 0, 0);
    d.setDate(d.getDate() + 4 - (d.getDay() || 7));
    const yearStart = new Date(d.getFullYear(), 0, 1);
    return Math.ceil(((d.valueOf() - yearStart.valueOf()) / 86400000 + 1) / 7);
  }
}
