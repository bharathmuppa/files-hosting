export class AcceptedChange {
  ID: string;
  value: any;
  oldValue: any;

  constructor(ID: string, value: any, oldValue: any) {
    this.ID = ID;
    this.value = value;
    this.oldValue = oldValue;
  }
}

export class RejectedChange {
  ID: string;
  value: any;
  rejectedValue: any;

  constructor(ID: string, value: any, rejectedValue: any) {
    this.ID = ID;
    this.value = value;
    this.rejectedValue = rejectedValue;
  }
}
