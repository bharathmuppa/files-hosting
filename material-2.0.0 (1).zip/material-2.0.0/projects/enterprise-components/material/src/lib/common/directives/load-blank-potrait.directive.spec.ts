import { Component, DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { AALLoadBlankPortraitDirective } from './load-blank-potrait.directive';

@Component({
  template: `
    <div>
      <img aalLoadBlankPortrait [src]="user?.userID" alt="" />
    </div>
  `,
})
class TestComponent {
  user: any;
  constructor() {}
}

describe('AALLoadBlankPortraitDirective', () => {
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;
  let debugElement: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestComponent, AALLoadBlankPortraitDirective],
    }).compileComponents();
    fixture = TestBed.createComponent(TestComponent);
    debugElement = fixture.debugElement.query(By.directive(AALLoadBlankPortraitDirective));
    component = fixture.componentInstance;
  });

  it('should create an instance', () => {
    const directive = new AALLoadBlankPortraitDirective(null, null);
    expect(directive).toBeTruthy();
  });

  it('should display blank image, when src of the image is not found', () => {
    const event = new ErrorEvent('error', {});
    debugElement.nativeElement.dispatchEvent(event);
    const img: HTMLImageElement = fixture.nativeElement.querySelector('img');
    expect(img.src.includes('data:image/png;base64')).toBe(true);
  });
});
