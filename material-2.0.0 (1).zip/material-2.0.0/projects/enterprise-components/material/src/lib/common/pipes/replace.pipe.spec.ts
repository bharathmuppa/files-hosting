import { AALReplacePipe } from './replace.pipe';

describe('AALReplacePipe', () => {
  let pipe: AALReplacePipe;

  beforeEach(() => {
    pipe = new AALReplacePipe();
  });

  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  it('should replace . with ,', () => {
    expect(pipe.transform(1000000.0, '[.]', ',')).toBe(1000000.0);
  });

  it('should replace , with .', () => {
    expect(pipe.transform('1000000,00', '[,]', '.')).toBe('1000000.00');
  });

  it('should return null when empty value is set,', () => {
    expect(pipe.transform('', '[.]', ',')).toBe(null);
  });
});
