import { AfterViewInit, Directive, HostListener, Input } from '@angular/core';
import { NgControl } from '@angular/forms';

@Directive({
  selector: '[aalEnforceDecimalInput]',
})
export class AALEnforceDecimalInputDirective implements AfterViewInit {
  @Input()
  regex: string;
  previousValue = '';

  constructor(private readonly ngControl: NgControl) {}

  ngAfterViewInit() {
    this.previousValue = this.ngControl.control.value;
  }

  @HostListener('input', ['$event']) onInput(event) {
    const regex = RegExp(this.regex);

    if (this.regex && !regex.test(event.target.value) && event.target.value.length > 0) {
      if (event.target.value.charAt(0) === '-' && event.target.value.length === 1) {
        this.previousValue = event.target.value;
      }
      event.target.value = this.previousValue;
    } else {
      this.previousValue = event.target.value;
    }

    this.ngControl.control.patchValue(event.target.value); // updates the model
  }

  @HostListener('blur', ['$event']) onBlur(event) {
    const hasLeadingZeros = /^0+/;
    if (event.target.value.charAt(0) === '-' && event.target.value.length === 1) {
      event.target.value = 0;
    }
    if (hasLeadingZeros.test(event.target.value) && event.target.value.length !== 1) {
      event.target.value = event.target.value.replace(/^0+/, '');
    }

    this.ngControl.control.patchValue(event.target.value); // updates the model
  }
}
