import { NgClass, NgStyle } from '@angular/common';
import { Component } from '@angular/core';
import { MatBadge } from '@angular/material/badge';
import { MatIconButton } from '@angular/material/button';
import { MatIcon } from '@angular/material/icon';
import { MatTooltip } from '@angular/material/tooltip';
import { AALCommonButtonComponent } from '@enterprise-components/common';

@Component({
  selector: 'aal-button-icon',
  templateUrl: './button-icon.component.html',
  styleUrls: ['./button-icon.component.scss'],
  standalone: true,
  imports: [MatIconButton, NgClass, MatTooltip, MatIcon, NgStyle, MatBadge],
})
export class ButtonIconComponent extends AALCommonButtonComponent {}
