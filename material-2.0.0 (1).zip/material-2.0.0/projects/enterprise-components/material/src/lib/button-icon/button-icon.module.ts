import { NgModule } from '@angular/core';
import { ButtonIconComponent } from './button-icon.component';

@NgModule({
  imports: [ButtonIconComponent],
  exports: [ButtonIconComponent],
})
export class ButtonIconModule {}
