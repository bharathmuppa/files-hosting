import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatBadgeModule } from '@angular/material/badge';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AALCommonComponentsModule } from '@enterprise-components/common';

import { SharedFormModule } from '../shared/shared-form.module';
import { SharedMaterialModule } from '../shared/shared-material.module';
import { SharedModule } from '../shared/shared.module';
import { ToastModule } from '../toast/toast.module';
import { ButtonDynamicComponent } from './button-dynamic.component';
import { ButtonStates } from './button-dynamic.model';
import createSpyObj = jasmine.createSpyObj;

describe('ButtonDynamicComponent', () => {
  let component: ButtonDynamicComponent;
  let fixture: ComponentFixture<ButtonDynamicComponent>;
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        MatBadgeModule,
        ToastModule,
        BrowserAnimationsModule,
        ButtonDynamicComponent,
      ],
    })
      .compileComponents()
      .then(() => {});
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ButtonDynamicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get the state value on click', () => {
    const event = new MouseEvent('click');
    component.click(event);
    expect(component.currentState).toBe('INPROGRESS');
  });

  it('should set currentStateData in setStateData method', () => {
    component.stateConfigurationValue = {
      initial: {
        icon: 'cloud_download',
        tooltip: 'Create Delta 1 In Teamcenter, then Download Excel File',
        toast: 'Delta 1 created in Teamcenter',
        toastDuration: 2000,
      },
      inprogress: {
        icon: '',
        tooltip: 'Preparing To Download Excel File',
        toast: 'Download in progress',
        toastDuration: 2000,
      },
      success: {
        icon: 'check',
        tooltip: 'Successful',
        toast: 'Download Started. Check Your Downloads Folder',
        toastDuration: 2000,
      },
      failure: {
        icon: 'warning',
        tooltip: 'Failed',
        toast: 'Something went wrong',
        toastDuration: 2000,
      },
    };
    component.currentState = 'INITIAL';
    component.setStateData();

    expect(component.currentStateData).toEqual({
      icon: 'cloud_download',
      tooltip: 'Create Delta 1 In Teamcenter, then Download Excel File',
      toast: 'Delta 1 created in Teamcenter',
      toastDuration: 2000,
    });
  });

  it('should get the button disabled on state changes to success or failure ', () => {
    component.currentState = ButtonStates.SUCCESS;
    expect(component.isDisabled()).toBeTruthy();
  });

  it('should setToast when button status is success', () => {
    spyOn(component.toastBar, 'openFromComponent');
    component.currentStateData = createSpyObj('toast', ['toast Message Sample text']);
    component.state = ButtonStates.SUCCESS;
    /*component.currentState = ButtonStates.SUCCESS;
    component.currentStateData = {
      toast: 'toast Message Sample text',
      tooltip: 'toast Message Sample text',
      toastDuration: 10
    } as ButtonStateData;*/

    expect(component.toastBar.openFromComponent).toHaveBeenCalled();
  });

  it('Should call setStateData on StateConfiguration on set', () => {
    spyOn(component, 'setStateData');
    component.currentState = 'initial';
    component.stateConfiguration = {
      initial: {
        icon: 'cloud_download',
        tooltip: 'Create Delta 1 In Teamcenter, then Download Excel File',
        toast: 'Delta 1 created in Teamcenter',
        toastDuration: 2000,
      },
      inprogress: {
        icon: '',
        tooltip: 'Preparing To Download Excel File',
        toast: 'Download in progress',
        toastDuration: 2000,
      },
      success: {
        icon: 'check',
        tooltip: 'Successful',
        toast: 'Download Started. Check Your Downloads Folder',
        toastDuration: 2000,
      },
      failure: {
        icon: 'warning',
        tooltip: 'Failed',
        toast: 'Something went wrong',
        toastDuration: 2000,
      },
    };
    expect(component.setStateData).toHaveBeenCalled();
  });
});
