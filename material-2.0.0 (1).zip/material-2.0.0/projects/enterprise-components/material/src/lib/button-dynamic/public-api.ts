/*
 * Public API Surface of material
 */

export * from './button-dynamic.component';
export * from './button-dynamic.model';
export * from './button-dynamic.module';
