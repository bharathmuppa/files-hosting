export class ButtonStateConfiguration {
  initial: ButtonStateData;
  inprogress: ButtonStateData;
  success: ButtonStateData;
  failure: ButtonStateData;
}

export class ButtonStateData {
  icon?: string;
  tooltip: string;
  imageURL?: string;
  svgIcon?: string;
  toast?: string;
  toastDuration?: number;
}

export type ButtonState = 'INITIAL' | 'INPROGRESS' | 'SUCCESS' | 'FAILURE';

export enum ButtonStates {
  INITIAL = 'INITIAL',
  INPROGRESS = 'INPROGRESS',
  SUCCESS = 'SUCCESS',
  FAILURE = 'FAILURE',
}
