import { NgModule } from '@angular/core';
import { ButtonDynamicComponent } from './button-dynamic.component';

@NgModule({
  imports: [ButtonDynamicComponent],
  exports: [ButtonDynamicComponent],
})
export class ButtonDynamicModule {}
