import { NgClass } from '@angular/common';
import { Component } from '@angular/core';
import { MatBadge } from '@angular/material/badge';
import { MatButton } from '@angular/material/button';
import { MatTooltip } from '@angular/material/tooltip';
import { AALCommonButtonComponent } from '@enterprise-components/common';

@Component({
  selector: 'aal-button-contained',
  templateUrl: './button-contained.component.html',
  styleUrls: ['./button-contained.component.scss'],
  standalone: true,
  imports: [MatButton, MatTooltip, MatBadge, NgClass],
})
export class ButtonContainedComponent extends AALCommonButtonComponent {}
