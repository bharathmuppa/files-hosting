import { NgModule } from '@angular/core';
import { ButtonContainedComponent } from './button-contained.component';

@NgModule({
  imports: [ButtonContainedComponent],
  exports: [ButtonContainedComponent],
})
export class ButtonContainedModule {}
