/*
 * Public API Surface of material
 */

export * from './button-contained.component';
export * from './button-contained.module';
