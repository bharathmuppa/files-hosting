import { NgModule } from '@angular/core';
import { InputLinkComponent } from './input-link.component';

@NgModule({
  imports: [InputLinkComponent],
  exports: [InputLinkComponent],
})
export class InputLinkModule {}
