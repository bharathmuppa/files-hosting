import { Meta, StoryObj } from '@storybook/angular';
import { ButtonIconComponent } from './button-icon.component';

const meta: Meta<ButtonIconComponent> = {
  title: 'Enterprise Components/Atoms/Button Icon',
  tags: ['autodocs'],
  component: ButtonIconComponent,
  argTypes: {
    size: {
      control: 'select',
      options: ['sm', 'md', 'lg'],
      description: 'Size of the button',
    },
    color: {
      control: 'select',
      options: ['default', 'primary', 'accent', 'warn'],
      description: 'Color of the button',
    },
    icon: {
      control: 'text',
      description: 'Material icon name',
    },
    tooltip: {
      control: 'text',
      description: 'Tooltip text for the button',
    },
    disabled: {
      control: 'boolean',
      description: 'Disables the button if true',
    },
  },
};

export default meta;
type Story = StoryObj<ButtonIconComponent>;

// Contained Button Story
export const Default: Story = {
  name: 'Icon Button (Default)',
  args: {
    icon: 'close',
    color: 'default',
  },
};
