import { Meta, StoryObj } from '@storybook/angular';
import { AALButtonOverlayComponent } from './button-overlay.component';

const meta: Meta<AALButtonOverlayComponent> = {
  title: 'Enterprise Components/Atoms/Overlay Button',
  tags: ['autodocs'],
  component: AALButtonOverlayComponent,
  argTypes: {
    name: {
      control: 'text',
      type: 'string',
    },
    icon: {
      control: 'text',
      type: 'string',
    },
    trailingIcon: {
      control: 'text',
      type: 'string',
    },
  } as any,
};

export default meta;
type Story = StoryObj<AALButtonOverlayComponent>;

// Contained Button Story
export const Default: Story = {
  name: 'Overlay Button with Text (Default)',
  args: {
    name: 'Overlay Button with Text',
  },
};

// Contained Button with Icon Story
export const ContainedWithIconButton: Story = {
  name: 'Overlay Button with Icon',
  args: {
    icon: 'edit',
  },
};
