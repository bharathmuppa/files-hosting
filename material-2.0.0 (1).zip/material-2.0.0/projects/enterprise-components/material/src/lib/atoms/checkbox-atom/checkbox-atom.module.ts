import { NgModule } from '@angular/core';
import { CheckboxAtomComponent } from './checkbox-atom.component';

@NgModule({
  imports: [CheckboxAtomComponent],
  exports: [CheckboxAtomComponent],
})
export class CheckboxAtomModule {}
