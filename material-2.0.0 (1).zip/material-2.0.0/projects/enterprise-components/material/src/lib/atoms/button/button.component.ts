import { NgClass } from '@angular/common';
import { Component, input } from '@angular/core';
import { MatBadgeModule } from '@angular/material/badge';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { AALCommonButtonComponent, ButtonType } from '@enterprise-components/common';

@Component({
  selector: 'aal-button',
  standalone: true,
  imports: [MatBadgeModule, MatButtonModule, MatIconModule, MatTooltipModule, NgClass],
  templateUrl: './button.component.html',
  styleUrl: './button.component.scss',
})
export class ButtonComponent extends AALCommonButtonComponent {
  type = input<ButtonType>('contained');
  trailingIcon = input<string>('');
}
