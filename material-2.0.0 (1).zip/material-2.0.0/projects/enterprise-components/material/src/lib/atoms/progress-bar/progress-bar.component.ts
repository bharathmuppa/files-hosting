import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { MatProgressBar } from '@angular/material/progress-bar';

@Component({
  selector: 'aal-progress-bar',
  standalone: true,
  imports: [MatProgressBar],
  templateUrl: './progress-bar.component.html',
  styleUrl: './progress-bar.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProgressBarComponent {
  /**
   * Mode of the progress bar.
   */
  mode = input<'indeterminate' | 'buffer' | 'query'>('indeterminate');
}
