import { BooleanInput } from '@angular/cdk/coercion';
import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { MatSlideToggle } from '@angular/material/slide-toggle';

@Component({
  selector: 'aal-slide-toggle',
  standalone: true,
  imports: [MatSlideToggle],
  templateUrl: './slide-toggle.component.html',
  styleUrl: './slide-toggle.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SlideToggleComponent {
  /**
   * The color theme of the slide toggle.
   */
  color = input<string>('accent');
  /**
   * The checked state of the slide toggle.
   */
  checked = input<BooleanInput>(false);
  /**
   * Disables the slide toggle.
   */
  disabled = input<BooleanInput>(false);
  /**
   * The message to display.
   */
  message = input<string>();
}
