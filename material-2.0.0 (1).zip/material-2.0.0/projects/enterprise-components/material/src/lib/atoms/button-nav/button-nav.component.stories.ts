import { Meta, StoryObj } from '@storybook/angular';
import { AALButtonNavComponent } from './button-nav.component';

const meta: Meta<AALButtonNavComponent> = {
  title: 'Enterprise Components/Atoms/Nav Button',
  tags: ['autodocs'],
  component: AALButtonNavComponent,
  argTypes: {
    condition: {
      control: { type: 'radio' },
      options: ['collapsed', 'expanded'],
      description: 'Controls whether nav button is expanded or collapsed',
      type: 'string',
    },
    name: {
      control: 'text',
      type: 'string',
    },
    icon: {
      control: 'text',
      type: 'string',
    },
    level: {
      control: 'number',
      type: 'number',
    },
  } as any,
};

export default meta;
type Story = StoryObj<AALButtonNavComponent>;

// Nav Button Default Story
export const Default: Story = {
  name: 'Nav Button (Default)',
  args: {
    icon: 'home',
  },
};

// Nav Button with expanded Story
export const NavButtonExpanded: Story = {
  name: 'Nav Button Expanded',
  args: {
    icon: 'home',
    name: 'Nav Button Expanded',
    condition: 'expanded',
  },
};

// Nav Button with level Story
export const NavButtonLevelExpanded: Story = {
  name: 'Nav Button Expanded with Level',
  args: {
    icon: 'home',
    name: 'Nav Button Expanded',
    condition: 'expanded',
    level: 1,
  },
};

// Nav Button with level2 Story
export const NavButtonLevel2Expanded: Story = {
  name: 'Nav Button Expanded with nested Level',
  args: {
    icon: 'home',
    name: 'Nav Button Expanded',
    condition: 'expanded',
    level: 2,
  },
};
