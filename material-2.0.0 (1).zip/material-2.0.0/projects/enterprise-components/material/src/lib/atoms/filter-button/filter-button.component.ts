import { BooleanInput } from '@angular/cdk/coercion';
import { NgClass, NgTemplateOutlet } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, input, model, output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatCheckbox } from '@angular/material/checkbox';
import { MatLabel } from '@angular/material/form-field';
import { MatIcon } from '@angular/material/icon';
import { CheckboxAtomComponent } from '../checkbox-atom/checkbox-atom.component';
import { DividerComponent } from '../divider/divider.component';
import { IconComponent } from '../icon/icon.component';

// Defines size options for the component
export type Size = 'sm' | 'md' | 'lg';

// Defines layout options for the component
export type layout = 'col' | 'row';

@Component({
  selector: 'aal-filter-button',
  standalone: true,
  imports: [
    NgClass,
    MatCheckbox,
    NgTemplateOutlet,
    MatIcon,
    DividerComponent,
    IconComponent,
    CheckboxAtomComponent,
    FormsModule,
    MatLabel,
  ],
  templateUrl: './filter-button.component.html',
  styleUrl: './filter-button.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FilterButtonComponent {
  /**
   * Unique identifier for the component instance.
   */
  uid = input<string>();

  /**
   * Size of the button ('sm', 'md', 'lg'). Default: 'lg'.
   */
  size = input<Size>('lg');

  /**
   * Label text displayed on the button.
   */
  label = input<string>();

  /**
   * Numeric value to display (e.g., count or badge).
   */
  count = input<number>();

  /**
   * Controls the checkbox state (checked/unchecked). Accepts BooleanInput.
   */
  checkbox = model<BooleanInput>();

  /**
   * Layout of the button: 'col' for vertical, 'row' for horizontal. Default: 'col'.
   */
  layout = input<layout>('col');

  /**
   * Name of the Material icon to display.
   */
  icon = input<string>();

  /**
   * Name or path of an SVG icon to display.
   */
  svg = input<string>();

  /**
   * Event emitted when the checkbox state changes.
   */
  readonly change = output();

  /**
   * Emits the `change` event when called.
   */
  checked() {
    this.change.emit();
  }

  /**
   * Computes the CSS class for the layout based on the `layout` input.
   */
  layoutClass = computed(() =>
    this.layout() === 'row' ? 'flex flex-row justify-between items-center' : 'flex flex-col',
  );
}
