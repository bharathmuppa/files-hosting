import { UntypedFormBuilder, UntypedFormControl } from '@angular/forms';
import { BrowserAnimationsModule, provideAnimations } from '@angular/platform-browser/animations';
import { Modes } from '@enterprise-components/common';
import { applicationConfig, moduleMetadata, type Meta, type StoryObj } from '@storybook/angular';
import { fn } from '@storybook/test';
import { ButtonRadioComponent } from './button-radio.component';

const meta: Meta<ButtonRadioComponent> = {
  title: 'Enterprise Components/Atoms/Radio Button',
  tags: ['autodocs'],
  component: ButtonRadioComponent,
  decorators: [
    moduleMetadata({
      imports: [BrowserAnimationsModule],
    }),
    applicationConfig({
      providers: [provideAnimations()],
    }),
  ],
};

export default meta;
type Story = StoryObj<ButtonRadioComponent>;

const stringOptions1 = ['Lorem Ipsum', 'Lorem Ipsum'];
const fb2: UntypedFormBuilder = new UntypedFormBuilder();
const stringFormControl1: UntypedFormControl = fb2.control(null);

export const PlainRadioButton: Story = {
  args: {
    ID: 'button_radio_string',
    hideClearSelection: true,
    mode: Modes.EDIT,
    lockMode: Modes.EDIT,
    options: stringOptions1,
    control: stringFormControl1,
    showHyphenForValues: [null, ''],
    acceptChanges: fn(),
    rejectChanges: fn(),
    hideHelp: true,
  },
  // Render is not needed, just kept to see show how we render the HTML
  render: (args) => {
    return {
      props: args,
      template: `
      <aal-button-radio
        [ID]="ID"
        [hideClearSelection]="hideClearSelection"
        [mode]="mode"
        [lockMode]="lockMode"
        [options]="options"
        [control]="control"
        [showHyphenForValues]="showHyphenForValues"
        (rejectChanges)="rejectChanges($event)"
        (acceptChanges)="acceptChanges($event)"
        [hideHelp]="hideHelp"
        >
      </aal-button-radio>
      `,
    };
  },
};
