import { UntypedFormBuilder } from '@angular/forms';
import { BrowserAnimationsModule, provideAnimations } from '@angular/platform-browser/animations';
import { Info, Modes } from '@enterprise-components/common';
import { applicationConfig, moduleMetadata, type Meta, type StoryObj } from '@storybook/angular';
import { fn } from '@storybook/test';
import { ButtonRadioComponent } from './button-radio.component';

const meta: Meta<ButtonRadioComponent> = {
  title: 'Enterprise Components/Atoms/Radio Button [Design]',
  tags: ['autodocs'],
  component: ButtonRadioComponent,
  decorators: [
    moduleMetadata({
      imports: [BrowserAnimationsModule],
    }),
    applicationConfig({
      providers: [provideAnimations()],
    }),
  ],
};

export default meta;
type Story = StoryObj<ButtonRadioComponent>;

const errorTitle = 'Error Title';
const errorMessage =
  'This is error message with <a target="_blank" href="https://www.google.com">link </a>';
const errorAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
const errorThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ec_Holding_N.V._logo.svg';
const errorLevel = 'ERROR';
const alert: Info = new Info(errorTitle, errorMessage, errorAnimation, errorThumbnail, errorLevel);
const helpTitle = 'Help Title';
const helpMessage =
  'This is help message with <a target="_blank" href="https://www.google.com">link </a>';
const helpAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
const helpThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ec_Holding_N.V._logo.svg';
const help = new Info(helpTitle, helpMessage, helpAnimation, helpThumbnail, null);
const stringOptions1 = [
  'Radio button list item text1',
  'Radio button list item text2',
  'Radio button list item text3',
];

export const RadioButtonEmpty: Story = {
  args: {
    ID: 'button_radio_string',
    label: 'Radio Button (Empty)',
    placeholder: 'select string',
    isNullable: false,
    hideClearSelection: false,
    displayWarning: help,
    help: help,
    // alert: alert,
    mode: Modes.EDIT,
    lockMode: Modes.EDIT,
    options: stringOptions1,
    showHyphenForValues: [null, ''],
    acceptChanges: fn(),
    rejectChanges: fn(),
  },
  // Render is not needed, just kept to see show how we render the HTML
  render: (args) => {
    const fb = new UntypedFormBuilder();
    const control = fb.control(null);
    return {
      props: {
        ...args,
        control,
      },
      template: `
      <aal-button-radio
        [ID]="ID"
        [label]="label"
        [placeholder]="placeholder"
        [isNullable]="isNullable"
        [help]="help"
        [hideClearSelection]="hideClearSelection"
        [options]="options"
        [lockMode]="lockMode"
        [control]="control"
        [displayWarning]="displayWarning"
        [showHyphenForValues]="showHyphenForValues"
        (rejectChanges)="rejectChanges($event)"
        (acceptChanges)="acceptChanges($event)"
        >
      </aal-button-radio>
      `,
    };
  },
};

export const PlainRadioButton: Story = {
  args: {
    ID: 'button_radio_string',
    label: 'Select String',
    placeholder: 'select string',
    isNullable: true,
    hideClearSelection: false,
    displayWarning: help,
    // help: help,
    // alert: alert,
    // mode: Modes.EDIT,
    // lockMode: Modes.EDIT,
    options: stringOptions1,
    showHyphenForValues: [null, ''],
    acceptChanges: fn(),
    rejectChanges: fn(),
  },
  // Render is not needed, just kept to see show how we render the HTML
  render: (args) => {
    const fb = new UntypedFormBuilder();
    const control = fb.control(null);
    return {
      props: {
        ...args,
        control,
      },
      template: `
      <aal-button-radio
        [ID]="ID"
        [label]="label"
        [placeholder]="placeholder"
        [isNullable]="isNullable"
        [hideClearSelection]="hideClearSelection"
        [options]="options"
        [control]="control"
        [displayWarning]="displayWarning"
        [showHyphenForValues]="showHyphenForValues"
        (rejectChanges)="rejectChanges($event)"
        (acceptChanges)="acceptChanges($event)"
        >
      </aal-button-radio>
      `,
    };
  },
};
