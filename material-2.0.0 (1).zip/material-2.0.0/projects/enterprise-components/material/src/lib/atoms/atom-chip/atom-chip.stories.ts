import { MatChipListbox } from '@angular/material/chips';
import { Meta, moduleMetadata, StoryObj } from '@storybook/angular';
import { AtomChipComponent } from './atom-chip.component';

const meta: Meta<AtomChipComponent> = {
  title: 'Enterprise Components/Atoms/Chip',
  component: AtomChipComponent,
  decorators: [
    moduleMetadata({
      imports: [MatChipListbox],
    }),
  ],
  argTypes: {
    label: {
      control: 'text',
      description: 'Text displayed inside the chip',
    },
    removable: {
      control: 'boolean',
      description: 'Determines if the chip has a remove button',
    },
    avatarWithIcon: {
      control: 'text',
      description: 'URL or text for the avatar; if invalid, falls back to an icon',
    },
    avatarWithImage: {
      control: 'text',
      description: 'Image URL for the avatar, if available',
    },
    avatarWithInitials: {
      control: 'text',
      description: 'Initials for the avatar if image URL is not available',
    },
    color: {
      control: 'select',
      options: ['default', 'in-progress', 'rejected', 'done'],
      description: 'Sets the color theme for the chip',
    },
    size: {
      control: 'select',
      options: ['md', 'sm'],
      description: 'Sets the color theme for the chip',
    },
    maxCharacters: {
      control: { type: 'number', min: 1 },
      description: 'Maximum characters before truncating with ellipsis',
    },
  },
};

export default meta;
type Story = StoryObj<AtomChipComponent>;

export const Default: Story = {
  args: {
    label: 'Default Chip',
    color: 'default',
  },
};

export const WithavatarWithIcon: Story = {
  args: {
    label: 'Chip with Avatar',
    removable: false,

    avatarWithImage: 'https://material.angular.io/assets/img/examples/shiba1.jpg', // If avatar is an image URL
    color: 'default',
    maxCharacters: 32,
  },
};

export const RemovableChip: Story = {
  args: {
    label: 'Removable Chip',
    removable: true,
    avatarWithIcon: '',
    color: 'default',
    maxCharacters: 32,
  },
};

export const TruncatedLabel: Story = {
  args: {
    label: 'A very long chip label that should be truncated after a certain number of characters',
    removable: true,
    avatarWithInitials: 'John Doe',
    color: 'default',
    maxCharacters: 20,
  },
};

export const ColoredChip: Story = {
  render: (args) => ({
    template: `
      <mat-chip-listbox>
        <aal-atom-chip
          [label]="label"
          [removable]="removable"
          [avatarWithIcon]="avatar"
          [avatarWithImage]="avatarWithImage"
          [avatarWithInitials]="avatarWithInitials"
          [color]="'in-progress'"
          [size]="size"
          [maxCharacters]="maxCharacters">
        </aal-atom-chip>
         <aal-atom-chip
          [label]="label"
          [removable]="removable"
          [avatarWithIcon]="avatar"
          [avatarWithImage]="avatarWithImage"
          [avatarWithInitials]="avatarWithInitials"
          [color]="'rejected'"
          [size]="size"
          [maxCharacters]="maxCharacters">
        </aal-atom-chip>
         <aal-atom-chip
          [label]="label"
          [removable]="removable"
          [avatarWithIcon]="avatar"
          [avatarWithImage]="avatarWithImage"
          [avatarWithInitials]="avatarWithInitials"
          [color]="'done'"
          [size]="size"
          [maxCharacters]="maxCharacters">
        </aal-atom-chip>
         <aal-atom-chip
          [label]="label"
          [removable]="removable"
          [avatarWithIcon]="avatar"
          [avatarWithImage]="avatarWithImage"
          [avatarWithInitials]="avatarWithInitials"
          [color]="'default'"
          [size]="size"
          [maxCharacters]="maxCharacters">
        </aal-atom-chip>
      </mat-chip-listbox>
    `,
    props: args,
  }),
  args: {
    label: 'Colored Chip',
    removable: false,
    avatarWithInitials: 'Jane Smith',
    maxCharacters: 32,
    size: 'sm',
  },
};
