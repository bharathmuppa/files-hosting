import { MatButtonModule } from '@angular/material/button';
import { Meta, moduleMetadata, StoryObj } from '@storybook/angular';

import { TooltipDirective } from './tooltip.directive';

const meta: Meta = {
  title: 'Enterprise Components/Atoms/Tooltip',
  component: TooltipDirective,
  decorators: [
    moduleMetadata({
      imports: [MatButtonModule, TooltipDirective],
    }),
  ],
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'A custom tooltip directive extending MatTooltip with default show and hide delays.',
      },
    },
  },
  argTypes: {
    message: { control: { type: 'text' }, table: { disable: false, readonly: true } },
    position: {
      control: { type: 'select' },
      options: ['above', 'below', 'left', 'right'],
      table: { disable: false, readonly: true },
    },
  },
};

export default meta;

type Story = StoryObj;

// Playground Story - Fully interactive
export const Playground: Story = {
  render: (args) => ({
    props: args,
    template: `
      <button mat-button [aalTooltip]="message" [aalTooltipPosition]="position">
        Hover me (Button)
      </button>
    `,
  }),
  argTypes: {
    message: { control: { type: 'text' }, table: { disable: false, readonly: false } },
    position: {
      control: { type: 'select' },
      options: ['above', 'below', 'left', 'right'],
      table: { disable: false, readonly: false },
    },
  },
  args: {
    message: 'Tooltip message',
    position: 'above',
  },
};

// Read-only Stories
export const TooltipOnAbove: Story = {
  render: (args) => ({
    props: args,
    template: `
      <button mat-button [aalTooltip]="message" [aalTooltipPosition]="position">
        Hover me (Button)(Above)
      </button>
    `,
  }),
  args: {
    message: 'Tooltip on Button',
    position: 'above',
  },
};

export const TooltipOnBelow: Story = {
  render: (args) => ({
    props: args,
    template: `
      <button mat-button [aalTooltip]="message" [aalTooltipPosition]="position">
        Hover me (Button)(Below)
      </button>
    `,
  }),
  args: {
    message: 'Tooltip on Button',
    position: 'below',
  },
};

export const TooltipOnButtonRight: Story = {
  render: (args) => ({
    props: args,
    template: `
      <button mat-button [aalTooltip]="message" [aalTooltipPosition]="position">
        Hover me (Button)(Right)
      </button>
    `,
  }),
  args: {
    message: 'Tooltip on Button',
    position: 'right',
  },
};

export const TooltipOnDiv: Story = {
  render: (args) => ({
    props: args,
    template: `
      <div [aalTooltip]="message" [aalTooltipPosition]="position" style="padding: 8px; border: 1px solid #ccc; display: inline-block;">
        Hover over me (Div)(Below)
      </div>
    `,
  }),
  args: {
    message: 'Tooltip on Div',
    position: 'below',
  },
};

export const TooltipOnSpan: Story = {
  render: (args) => ({
    props: args,
    template: `
      <span [aalTooltip]="message" [aalTooltipPosition]="position" style="display: inline-block; margin-top: 16px;">
        Hover over me (Span)(Tooltip adjusts position)
      </span>
    `,
  }),
  args: {
    message: 'Tooltip on Span',
    position: 'above',
  },
};
