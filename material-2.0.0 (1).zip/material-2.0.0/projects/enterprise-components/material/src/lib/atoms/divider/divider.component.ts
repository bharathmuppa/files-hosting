import { ChangeDetectionStrategy, Component, input, InputSignal } from '@angular/core';
import { MatDivider } from '@angular/material/divider';
import { BooleanInput } from '@angular/cdk/coercion';

/**
 * `DividerComponent` provides a customizable divider that can be either horizontal or vertical.
 * It extends Angular Material's MatDivider and adds signal-based properties to manage its orientation, size, and inset.
 * The component utilizes signals to dynamically adjust its height and width based on its orientation.
 */
@Component({
  selector: 'aal-divider',
  standalone: true,
  templateUrl: './divider.component.html',
  styleUrls: ['./divider.component.scss'],
  imports: [MatDivider],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DividerComponent {
  /**
   * Controls whether the divider is vertical.
   * - `true` renders the divider vertically, with a height of 100% and a width of `size`.
   * - `false` renders the divider horizontally, with a width of 100% and a height of `size`.
   */
  vertical: InputSignal<BooleanInput> = input<BooleanInput>();

  /**
   * Applies an optional inset to the divider, adding spacing before rendering.
   * When `true`, the divider is indented according to its orientation.
   */
  inset: InputSignal<BooleanInput> = input<BooleanInput>();
}
