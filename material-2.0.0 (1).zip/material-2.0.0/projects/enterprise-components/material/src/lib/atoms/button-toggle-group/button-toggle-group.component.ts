import { BooleanInput } from '@angular/cdk/coercion';
import { NgClass, NgTemplateOutlet } from '@angular/common';
import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  inject,
  Injector,
  input,
  OnInit,
  Output,
  signal,
  TemplateRef,
} from '@angular/core';
import {
  ControlValueAccessor,
  NG_VALUE_ACCESSOR,
  NgControl,
  ReactiveFormsModule,
} from '@angular/forms';
import { MatButtonToggle, MatButtonToggleGroup } from '@angular/material/button-toggle';

/**
 * A wrapper component for Angular Material's Button Toggle Group that integrates
 * with Angular Forms API through ControlValueAccessor.
 */
@Component({
  selector: 'aal-button-toggle-group',
  standalone: true,
  imports: [MatButtonToggleGroup, MatButtonToggle, ReactiveFormsModule, NgClass, NgTemplateOutlet],
  templateUrl: './button-toggle-group.component.html',
  styleUrl: './button-toggle-group.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    /**
     * Provides the `NG_VALUE_ACCESSOR` token to register this component as a
     * ControlValueAccessor for Angular Forms. This allows the component to
     * participate in Angular's form control lifecycle and be used with
     * `formControlName`, `formControl`, and other form directives.
     */
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: ButtonToggleGroupComponent,
      // useExisting: forwardRef(() => ButtonToggleGroupComponent),
      multi: true,
    },
  ],
})
export class ButtonToggleGroupComponent<T> implements ControlValueAccessor, OnInit {
  /** The available options for the button toggle group. */
  options = input.required<T[]>();

  /** Whether the toggle group supports multiple selection. */
  multiple = input<BooleanInput>(false);

  /** Internal state signal representing the current selected value(s). */
  value = signal<T>(null);

  /** Size of the button toggle group ('small', 'medium', 'large'). */
  size = input<'md' | 'lg'>('lg');

  /**
   * Callback function invoked when the value changes.
   * This is provided by Angular Forms during registration.
   */
  private onChange: (value: T) => void = () => {};

  /**
   * Template reference to render the button toggle options
   */
  buttonTemplate = input<TemplateRef<any>>();

  /**
   * Key to be used for the button toggle option
   */
  useThisKeyToDisplay = input<string>();

  /**
   * Value to be used for the button toggle option
   */
  useThisKeyAsValue = input<string>();

  /**
   * Emits an event when the value changes.
   */
  // eslint-disable-next-line @angular-eslint/no-output-native
  @Output() change = new EventEmitter<T>();

  /**
   * Callback function invoked when the component is touched (focused or blurred).
   * This is provided by Angular Forms during registration.
   */
  private onTouched: () => void = () => {};

  injector = inject(Injector);

  #cdr = inject(ChangeDetectorRef);

  ngOnInit() {
    // ⬇ It can cause a circular dependency if injected in the constructor
    const ngControl = this.injector.get(NgControl, null, { self: true, optional: true });
    if (ngControl) {
      // Assign this component as the value accessor for the associated control.
      // ngControl.valueAccessor = this;
    }
  }

  /**
   * Registers a callback to be invoked when the value changes.
   *
   * @param fn The callback function.
   */
  registerOnChange(fn: (value: T) => void): void {
    this.onChange = fn;
  }

  /**
   * Registers a callback to be invoked when the component is touched.
   *
   * @param fn The callback function.
   */
  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  /**
   * Handles selection changes in the button toggle group.
   * Updates the internal value state and invokes the registered callbacks.
   *
   * @param value The new selected value(s).
   */
  onSelectionChange(value: any): void {
    this.writeValue(value);
    this.onChange(value);
    this.change.emit(value);
    this.onTouched();
  }

  /**
   * Writes a new value to the component. This is called by Angular Forms
   * when the value of the parent form control changes.
   *
   * @param value The value to set.
   */
  writeValue(value: any): void {
    this.value.set(value);
  }
}
