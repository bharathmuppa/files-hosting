import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { ButtonToggleGroupComponent } from './button-toggle-group.component';

describe('ButtonToggleGroupComponent', () => {
  let component: ButtonToggleGroupComponent<any>;
  let fixture: ComponentFixture<ButtonToggleGroupComponent<any>>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ButtonToggleGroupComponent, ReactiveFormsModule],
    }).compileComponents();

    fixture = TestBed.createComponent(ButtonToggleGroupComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // TODO: Enable below tests
  // describe('FormControl Integration', () => {
  //   let formControl: FormControl;
  //
  //   beforeEach(() => {
  //     formControl = new FormControl(null);
  //     component.options = signal([
  //       'Option 1',
  //       'Option 2',
  //       'Option 3',
  //     ]) as unknown as typeof component.options;
  //     component.multiple = signal(false) as unknown as typeof component.multiple;
  //     fixture.detectChanges();
  //     component.registerOnChange(formControl.setValue.bind(formControl));
  //     component.registerOnTouched(() => {});
  //   });
  //
  //   it('should update FormControl value on selection change', () => {
  //     const buttonToggleGroup = fixture.debugElement.query(By.css('mat-button-toggle-group'));
  //
  //     // Simulate selecting the first button toggle
  //     const buttonToggle = buttonToggleGroup.query(
  //       By.css('mat-button-toggle[ng-reflect-value="Option 1"]'),
  //     );
  //     buttonToggle.nativeElement.click();
  //     fixture.detectChanges();
  //
  //     expect(formControl.value).toBe('Option 1');
  //   });
  //
  //   it('should update component value when FormControl value changes', () => {
  //     // Update FormControl value programmatically
  //     formControl.setValue('Option 2');
  //     fixture.detectChanges();
  //
  //     expect(component.value()).toBe('Option 2');
  //   });
  // });
  //
  // describe('Multiple Selection', () => {
  //   let formControl: FormControl;
  //
  //   beforeEach(() => {
  //     formControl = new FormControl([]);
  //     component.options = signal([
  //       'Option 1',
  //       'Option 2',
  //       'Option 3',
  //     ]) as unknown as typeof component.options;
  //     component.multiple = signal(false) as unknown as typeof component.multiple;
  //     fixture.detectChanges();
  //     component.registerOnChange(formControl.setValue.bind(formControl));
  //     component.registerOnTouched(() => {});
  //   });
  //
  //   it('should allow multiple selections and update FormControl value', () => {
  //     const buttonToggleGroup = fixture.debugElement.query(By.css('mat-button-toggle-group'));
  //
  //     // Simulate selecting multiple button toggles
  //     const buttonToggleA = buttonToggleGroup.query(By.css('mat-button-toggle[value="Option A"]'));
  //     const buttonToggleB = buttonToggleGroup.query(By.css('mat-button-toggle[value="Option B"]'));
  //     buttonToggleA.nativeElement.click();
  //     buttonToggleB.nativeElement.click();
  //     fixture.detectChanges();
  //
  //     expect(formControl.value).toEqual(['Option A', 'Option B']);
  //   });
  // });
  //
  // describe('Size Input', () => {
  //   it('should apply the correct size class based on input', () => {
  //     component.size = signal('lg') as unknown as typeof component.size;
  //     fixture.detectChanges();
  //
  //     const buttonToggleGroup = fixture.debugElement.query(By.css('mat-button-toggle-group'));
  //     expect(buttonToggleGroup.nativeElement.classList).toContain('large');
  //   });
  // });
});
