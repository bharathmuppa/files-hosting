import { NgClass } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatError, MatFormField, MatHint, MatLabel } from '@angular/material/form-field';
import { MatProgressSpinner } from '@angular/material/progress-spinner';
import { MatTooltip } from '@angular/material/tooltip';
import { AALCommonModule } from '@enterprise-components/common';
import { OverlayCardErrorModule } from '../../overlay-card-alert/overlay-card-alert.module';
import { OverlayCardHelpModule } from '../../overlay-card-help/overlay-card-help.module';
import { ToolbarConfirmModule } from '../../toolbar-confirm/toolbar-confirm.module';
import { InputTextAreaComponent } from '../input-text-area/input-text-area.component';
import { MatContenteditableDirective } from './mat-contenteditable.directive';

@Component({
  selector: 'aal-editable-div-text-area',
  templateUrl: './editable-div-text-area.component.html',
  styleUrls: ['./editable-div-text-area.component.scss'],
  standalone: true,
  imports: [
    OverlayCardHelpModule,
    MatProgressSpinner,
    MatFormField,
    MatLabel,
    MatContenteditableDirective,
    FormsModule,
    ReactiveFormsModule,
    MatError,
    MatHint,
    ToolbarConfirmModule,
    MatTooltip,
    NgClass,
    AALCommonModule,
    OverlayCardErrorModule,
  ],
})
export class EditableDivTextAreaComponent extends InputTextAreaComponent {
  setFocusInInput() {
    this.onClick();
    setTimeout(() => {
      document.execCommand('selectAll', false, null);
      // collapse selection to the end
      if (document.getSelection()) {
        document.getSelection().collapseToEnd();
      }
    }, 1);
  }
}
