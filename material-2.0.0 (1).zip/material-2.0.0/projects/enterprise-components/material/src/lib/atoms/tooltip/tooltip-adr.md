# ADR: Extend Angular Material `MatTooltip` for Custom `TooltipDirective`

**Status:** Accepted  
**Date:** November 4, 2024  
**Decision Owner:** RGB Dev Team

---

## Context and Problem Statement

We are building a reusable UI component library that includes a custom `TooltipDirective`. This directive should provide similar functionality to Angular Material’s `MatTooltip` while allowing users of the library to avoid directly importing Angular Material components.

We initially explored alternatives such as rebuilding the tooltip entirely or using input mapping to re-implement `MatTooltip` features. However, due to specific constraints with tooltips being directives in Angular Material, these approaches were not feasible. Extending `MatTooltip` directly emerged as the most practical solution, allowing us to inherit existing tooltip behaviors and configurations without extensive customization or re-implementation.

## Decision

We decided to extend `MatTooltip` directly in `TooltipDirective`, allowing `TooltipDirective` to inherit its properties, behaviors, and configurations. This decision leverages Angular Material’s established tooltip functionality, minimizing maintenance and code complexity, and ensuring consistent behavior across Angular Material updates.

### Key Reasons for Extending `MatTooltip`

- **Access to Tooltip Features**: `MatTooltip` provides built-in properties and behaviors such as `showDelay`, `hideDelay`, `position`, and `message`. Extending it enables us to reuse this functionality without manual re-implementation.
- **Directive Constraints**: Since Angular Material’s `MatTooltip` is a directive, options like component wrapping or custom input mapping were less feasible, as they would either limit the tooltip’s functionality or require extensive rework of built-in features.
- **Consistency with Angular Material**: Extending `MatTooltip` ensures that our directive remains in line with Angular Material’s tooltip behavior, minimizing the risk of functional divergence.

## Alternatives Considered

1. **Rebuild Tooltip from Scratch**
  - **Pros**: Complete control over functionality and configuration, fully independent of Angular Material.
  - **Cons**: Rebuilding core tooltip functionality (e.g., positioning, delay handling, accessibility, and gesture support) would be complex and error-prone, requiring substantial maintenance to keep feature parity with Angular Material.

2. **Use Input Mapping Instead of Extension**
  - **Pros**: Custom control over properties, allowing greater independence from Angular Material.
  - **Cons**: Tooltip functionality cannot be fully replicated through input mapping alone, as `MatTooltip` is a directive with specific behaviors. This would limit functionality and require workarounds to manage overlays and positioning.

3. **Extend `MatTooltip` (Selected Option)**
  - **Pros**: Directly leverages Angular Material’s tooltip functionality, inheriting configuration options and behaviors with minimal custom code.
  - **Cons**: Creates a dependency on Angular Material’s internal implementation, requiring adjustments if `MatTooltip` changes in future versions.

## Rationale

Extending `MatTooltip` provides the best balance of functionality, maintainability, and adherence to Angular Material’s intended behavior for tooltips. Given the directive nature of `MatTooltip`, this approach allows us to inherit necessary functionality without reinventing complex tooltip logic, keeping `TooltipDirective` efficient and consistent.

## Consequences

- **Positive**:
  - Minimal maintenance effort due to reuse of `MatTooltip`’s configuration and behaviors.
  - Consistent behavior aligned with Angular Material’s tooltip updates.
  - Efficient, fully functional tooltip implementation with minimal custom code.

- **Negative**:
  - Dependency on Angular Material’s internal implementation, which may require updates in the future.
  - Limited ability to customize beyond `MatTooltip`’s existing functionality.

## Implementation

1. Extend `MatTooltip` in `TooltipDirective`, inheriting its properties and behaviors.
2. Expose relevant properties (e.g., `showDelay`, `hideDelay`, `position`, `message`) through `TooltipDirective` for full compatibility.
3. Write unit tests to verify the inherited behavior and functionality of `TooltipDirective`.

---

**Decision:** Extend `MatTooltip` for Custom `TooltipDirective`
