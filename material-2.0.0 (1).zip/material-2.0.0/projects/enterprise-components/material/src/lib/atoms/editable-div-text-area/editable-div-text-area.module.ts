import { NgModule } from '@angular/core';

import { EditableDivTextAreaComponent } from './editable-div-text-area.component';

@NgModule({
  // NOTE: Removed MatContenteditableDirective because we no longer use modules
  // we use standalone components which directly imports the required directive
  imports: [EditableDivTextAreaComponent],
  exports: [EditableDivTextAreaComponent],
})
export class EditableDivTextAreaModule {}
