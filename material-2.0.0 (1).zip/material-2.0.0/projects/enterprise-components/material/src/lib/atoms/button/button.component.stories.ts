import { ButtonTypes } from '@enterprise-components/common';
import { Meta, StoryObj } from '@storybook/angular';
import { ButtonComponent } from './button.component';

const meta: Meta<ButtonComponent> = {
  title: 'Enterprise Components/Atoms/Main Button',
  tags: ['autodocs'],
  component: ButtonComponent,
  argTypes: {
    type: {
      control: 'select',
      type: ButtonTypes,
      default: 'contained',
      options: ['contained', 'outlined', 'text'],
    },
    name: {
      control: 'text',
      type: 'string',
    },
    icon: {
      control: 'text',
      type: 'string',
    },
  } as any,
};

export default meta;
type Story = StoryObj<ButtonComponent>;

// Contained Button Story
export const Default: Story = {
  name: 'Contained Button (Default)',
  args: {
    name: 'Contained Button',
  },
};

// Contained Button with Icon Story
export const ContainedWithIconButton: Story = {
  args: {
    type: 'contained',
    name: 'Contained Button Icon',
    icon: 'group',
  },
};

// Contained Button with Icon disabled Story
export const ContainedDisabledButton: Story = {
  args: {
    type: 'contained',
    name: 'Contained Button Disabled',
    icon: 'group',
  },
};

// Outline Button Story
export const OutlineButton: Story = {
  args: {
    type: 'outlined',
    name: 'Outlined Button',
  },
};

// Outline Button Story
export const OutlineWithIconButton: Story = {
  args: {
    type: 'outlined',
    name: 'Outlined Button Icon',
    icon: 'group',
  },
};

// Outline Button Story
export const OutlineDisabledButton: Story = {
  args: {
    type: 'outlined',
    name: 'Outlined Disabled Button',
    icon: 'group',
  },
};

// Text Button Story
export const TextButton: Story = {
  args: {
    type: 'text',
    name: 'Text Button',
  },
};

// Text disabled Button Story
export const TextDisabledButton: Story = {
  args: {
    type: 'text',
    name: 'Text Disabled Button',
    disabled: true,
  },
};

// Contained Icon Story
export const ContainedIconButton: Story = {
  args: {
    type: 'contained',
    icon: 'group',
  },
};

// Contained Icon Disabled Story
export const ContainedIconDisabledButton: Story = {
  args: {
    type: 'contained',
    icon: 'group',
    disabled: true,
  },
};

// Outline Button Story
export const OutlineIconButton: Story = {
  args: {
    type: 'outlined',
    icon: 'group',
  },
};

// Outline Icon Disabled Story
export const OutlineIconDisabledButton: Story = {
  args: {
    type: 'outlined',
    icon: 'group',
    disabled: true,
  },
};
