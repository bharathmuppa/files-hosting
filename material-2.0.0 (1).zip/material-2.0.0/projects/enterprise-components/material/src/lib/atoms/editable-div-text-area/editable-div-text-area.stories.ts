import { importProvidersFrom } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Info, Modes } from '@enterprise-components/common';
import { applicationConfig, type Meta, type StoryObj } from '@storybook/angular';
import { fn } from '@storybook/test';
import { EditableDivTextAreaComponent } from './editable-div-text-area.component';

const meta: Meta<EditableDivTextAreaComponent> = {
  title: 'Enterprise Components/Legacy/Editable Div Text Area',
  component: EditableDivTextAreaComponent,
  tags: ['autodocs'],
  decorators: [
    applicationConfig({
      providers: [importProvidersFrom(BrowserAnimationsModule)],
    }),
  ],
};

export default meta;
type Story = StoryObj<EditableDivTextAreaComponent>;

const errorTitle = 'Error Title';
const errorMessage =
  'This is error message with <a target="_blank" href="https://www.google.com">link </a>';
const errorAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
const errorThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ec_Holding_N.V._logo.svg';
const errorLevel = 'ERROR';
const errorAlert = new Info(errorTitle, errorMessage, errorAnimation, errorThumbnail, errorLevel);

// <!-- Storybook:DONE editable-div-text-area.stories Variant1-->
export const Variant1: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    alert: errorAlert,
    mode: Modes.READ,
    pressAcceptEvent: fn(),
    pressRejectEvent: fn(),
  },
  render: (args) => {
    const fb = new UntypedFormBuilder();
    const control = fb.control('', [Validators.required, Validators.maxLength(100)]);
    return {
      props: {
        ...args,
        control,
      },
      template: `
      <aal-editable-div-text-area
        (acceptChanges)="acceptChanges($event)"
        (rejectChanges)="rejectChanges($event)"
        (pressAcceptEvent)="pressAcceptEvent($event)"
        (pressRejectEvent)="pressRejectEvent($event)"
        [ID]="'DivEditable'"
        [control]="control"
        [alert]="alert"
        [help]=""
        [isBusy]="false"
        [isHistoryEnabled]="false"
        [mode]="mode"
        [showLengthHint]="true"
        [maxLength]="100"
        [compositePlaceholder]="'Enter number'"
        [label]="'Number'"
        [placeholder]="'number'">
      </aal-editable-div-text-area>
      `,
    };
  },
};

// <!-- Storybook:DONE editable-div-text-area.stories Variant2-->
export const Variant2: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    alert: errorAlert,
    mode: Modes.PRIVATE,
    pressAcceptEvent: fn(),
    pressRejectEvent: fn(),
  },
  render: (args) => {
    const fb = new UntypedFormBuilder();
    const control = fb.control('', [Validators.required, Validators.maxLength(100)]);
    return {
      props: {
        ...args,
        control,
      },
      template: `
      <aal-editable-div-text-area
        (acceptChanges)="acceptChanges($event)"
        (rejectChanges)="rejectChanges($event)"
        (pressAcceptEvent)="pressAcceptEvent($event)"
        (pressRejectEvent)="pressRejectEvent($event)"
        [ID]="'DivEditable'"
        [control]="control"
        [alert]="alert"
        [help]=""
        [isBusy]="false"
        [isHistoryEnabled]="false"
        [mode]="mode"
        [showLengthHint]="true"
        [maxLength]="100"
        [compositePlaceholder]="'Enter number'"
        [label]="'Number'"
        [placeholder]="'number'">
      </aal-editable-div-text-area>
      `,
    };
  },
};

export const F1: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    alert: errorAlert,
    mode: Modes.EDIT,
    pressAcceptEvent: fn(),
    pressRejectEvent: fn(),
    ID: 'F1',
  },
  render: (args) => {
    const fb = new UntypedFormBuilder();
    const control = fb.control('', [Validators.required, Validators.maxLength(100)]);
    return {
      props: {
        ...args,
        control,
      },
      template: `
      <aal-editable-div-text-area
        (acceptChanges)="acceptChanges($event)"
        (rejectChanges)="rejectChanges($event)"
        (pressAcceptEvent)="pressAcceptEvent($event)"
        (pressRejectEvent)="pressRejectEvent($event)"
        [ID]="ID"
        [control]="control"
        [isBusy]="false"
        [isHistoryEnabled]="false"
        [mode]="mode"
        [showLengthHint]="true"
        [maxLength]="100"
        [compositePlaceholder]="'Enter number'"
        [label]="'Number'"
        [placeholder]="'number'">
      </aal-editable-div-text-area>
      `,
    };
  },
};
