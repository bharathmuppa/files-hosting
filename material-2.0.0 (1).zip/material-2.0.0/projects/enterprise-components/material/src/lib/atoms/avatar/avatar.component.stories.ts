import type { Meta, StoryObj } from '@storybook/angular';
import { AvatarComponent } from './avatar.component';

const meta: Meta<AvatarComponent> = {
  title: 'Enterprise Components/Atoms/Avatar',
  component: AvatarComponent,
  argTypes: {
    size: {
      control: { type: 'radio' },
      options: ['sm', 'md', 'lg'],
      description: 'Controls whether avatar is small, medium or large',
    },
    fullName: {
      control: 'text',
      description: 'Full name for avatar, contains lastname and firstname separated by space',
    },
    disabled: {
      control: 'boolean',
      description: 'Disables avatar component',
    },
    image: {
      control: 'text',
      description: 'URL of image. Example https://www.w3schools.com/howto/img_avatar.png',
    },
  },
  args: {
    size: 'md',
  },
};

export default meta;
type Story = StoryObj<AvatarComponent>;

// default is medium icon
export const Default: Story = {};

export const IconSmall: Story = {
  args: {
    size: 'sm',
  },
  argTypes: {
    size: {
      control: false,
    },
    fullName: { control: false },
    disabled: { control: false },
    image: { control: false },
  },
};

export const IconMedium: Story = {
  argTypes: {
    size: {
      control: false,
    },
    fullName: { control: false },
    disabled: { control: false },
    image: { control: false },
  },
};

export const IconLarge: Story = {
  args: {
    size: 'lg',
  },
  argTypes: {
    size: {
      control: false,
    },
    fullName: { control: false },
    disabled: { control: false },
    image: { control: false },
  },
};

// default is small icon
export const ImageSmall: Story = {
  args: {
    size: 'sm',
    image: 'https://www.w3schools.com/howto/img_avatar.png',
  },
  argTypes: {
    size: {
      control: false,
    },
    fullName: { control: false },
    disabled: { control: false },
    image: { control: false },
  },
};

export const ImageMedium: Story = {
  args: {
    image: 'https://www.w3schools.com/howto/img_avatar.png',
  },
  argTypes: {
    size: {
      control: false,
    },
    fullName: { control: false },
    disabled: { control: false },
    image: { control: false },
  },
};

export const ImageLarge: Story = {
  args: {
    image: 'https://www.w3schools.com/howto/img_avatar.png',
    size: 'lg',
  },
  argTypes: {
    size: {
      control: false,
    },
    fullName: { control: false },
    disabled: { control: false },
    image: { control: false },
  },
};

// default is small icon
export const InitialsSmall: Story = {
  args: {
    size: 'sm',
    fullName: 'John Doe',
  },
  argTypes: {
    size: {
      control: false,
    },
    fullName: { control: false },
    disabled: { control: false },
    image: { control: false },
  },
};

export const InitialsMedium: Story = {
  args: {
    fullName: 'John Doe',
  },
  argTypes: {
    size: {
      control: false,
    },
    fullName: { control: false },
    disabled: { control: false },
    image: { control: false },
  },
};

export const InitialsLarge: Story = {
  args: {
    fullName: 'John Doe',
    size: 'lg',
  },
  argTypes: {
    size: {
      control: false,
    },
    fullName: { control: false },
    disabled: { control: false },
    image: { control: false },
  },
};

export const IconSmallDisabled: Story = {
  args: {
    disabled: true,
    size: 'sm',
  },
  argTypes: {
    size: {
      control: false,
    },
    fullName: { control: false },
    disabled: { control: false },
    image: { control: false },
  },
};

export const IconMediumDisabled: Story = {
  args: {
    disabled: true,
  },
  argTypes: {
    size: {
      control: false,
    },
    fullName: { control: false },
    disabled: { control: false },
    image: { control: false },
  },
};

export const IconLargeDisabled: Story = {
  args: {
    disabled: true,
    size: 'lg',
  },
  argTypes: {
    size: {
      control: false,
    },
    fullName: { control: false },
    disabled: { control: false },
    image: { control: false },
  },
};

// default is small icon
export const ImageSmallDisabled: Story = {
  args: {
    size: 'sm',
    disabled: true,
    image: 'https://www.w3schools.com/howto/img_avatar.png',
  },
  argTypes: {
    size: {
      control: false,
    },
    fullName: { control: false },
    disabled: { control: false },
    image: { control: false },
  },
};

export const ImageMediumDisabled: Story = {
  args: {
    disabled: true,
    image: 'https://www.w3schools.com/howto/img_avatar.png',
  },
  argTypes: {
    size: {
      control: false,
    },
    fullName: { control: false },
    disabled: { control: false },
    image: { control: false },
  },
};

export const ImageLargeDisabled: Story = {
  args: {
    disabled: true,
    image: 'https://www.w3schools.com/howto/img_avatar.png',
    size: 'lg',
  },
  argTypes: {
    size: {
      control: false,
    },
    fullName: { control: false },
    disabled: { control: false },
    image: { control: false },
  },
};

// default is small icon
export const InitialsSmallDisabled: Story = {
  args: {
    size: 'sm',
    disabled: true,
    fullName: 'John Doe',
  },
  argTypes: {
    size: {
      control: false,
    },
    fullName: { control: false },
    disabled: { control: false },
    image: { control: false },
  },
};

export const InitialsMediumDisabled: Story = {
  args: {
    disabled: true,
    fullName: 'John Doe',
  },
  argTypes: {
    size: {
      control: false,
    },
    fullName: { control: false },
    disabled: { control: false },
    image: { control: false },
  },
};

export const InitialsLargeDisabled: Story = {
  args: {
    disabled: true,
    fullName: 'John Doe',
    size: 'lg',
  },
  argTypes: {
    size: {
      control: false,
    },
    fullName: { control: false },
    disabled: { control: false },
    image: { control: false },
  },
};
