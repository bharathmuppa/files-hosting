import { Component, forwardRef, input, model, Optional, Self } from '@angular/core';
import {
  ControlValueAccessor,
  NG_VALUE_ACCESSOR,
  NgControl,
  ReactiveFormsModule,
} from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';

@Component({
  selector: 'aal-checkbox-atom',
  standalone: true,
  imports: [MatCheckboxModule, ReactiveFormsModule],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => CheckboxAtomComponent),
      multi: true,
    },
  ],
  templateUrl: './checkbox-atom.component.html',
  styleUrls: ['./checkbox-atom.component.scss'],
})
export class CheckboxAtomComponent implements ControlValueAccessor {
  /** Determines if the checkbox should be in an indeterminate state. */
  indeterminate = model(false);

  /** Tracks the checked state of the checkbox. */
  checked = model(false);

  /** Determines if the checkbox should be disabled. */
  disabled = model(false);

  /** Sets the position of the label relative to the checkbox: 'before' or 'after'. */
  labelPosition = input<'before' | 'after'>('after');

  /** The label text displayed next to the checkbox. */
  label = input<string>('');

  private onChange: (value: boolean) => void = () => {};
  private onTouched: () => void = () => {};

  constructor(@Optional() @Self() public ngControl: NgControl) {
    if (this.ngControl) {
      // Assign this component as the value accessor for the control
      this.ngControl.valueAccessor = this;
    }
  }

  /** Handles the checkbox change event and updates the form control value. */
  onCheckboxChange(checked: boolean) {
    this.checked.set(checked);
    this.onChange(checked);
    this.onTouched();
  }

  /** Writes a value to the component when the form control value changes. */
  writeValue(value: boolean): void {
    this.checked.set(value);
  }

  /** Registers a callback function triggered when the checkbox value changes. */
  registerOnChange(fn: (value: boolean) => void): void {
    this.onChange = fn;
  }

  /** Registers a callback function triggered when the checkbox is touched. */
  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  /** Sets the disabled state of the checkbox. */
  setDisabledState(isDisabled: boolean): void {
    this.disabled.set(isDisabled);
  }
}
