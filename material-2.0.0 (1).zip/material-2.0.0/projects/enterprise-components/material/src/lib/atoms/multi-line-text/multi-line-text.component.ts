import { NgClass } from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ElementRef,
  inject,
  Input,
  OnInit,
  ViewChild,
} from '@angular/core';
import { MatTooltip } from '@angular/material/tooltip';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { IconComponent } from '../icon/icon.component';

@Component({
  selector: 'aal-multi-line-text',
  standalone: true,
  imports: [IconComponent, MatTooltip, NgClass],
  templateUrl: './multi-line-text.component.html',
  styleUrl: './multi-line-text.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MultiLineTextComponent implements OnInit, AfterViewInit {
  /**
   * Flag to show showMore, if the content is more than desired height.
   */
  @Input() showMore: boolean = true;

  /**
   * Height after which show more/show less will be visible (in px).
   * @example [showMore]="true" [showMoreAfterHeight]="80"
   */
  @Input() showMoreAfterHeight: number = 80;

  /**
   * Show the asterisk mark for mandatory fields.
   */
  @Input() isMandatory: boolean = false;

  /**
   * Tooltip for the mandatory field.
   */
  @Input() mandatoryToolTip: string = '';

  /**
   * Label for the field.
   */
  @Input() label: string = '';

  /**
   * Content to be displayed.
   */
  @Input() text: string = '';

  /**
   * Controls the initial expansion state.
   */
  @Input() expand: boolean = false;

  @ViewChild('readModeDivision') readModeDivision!: ElementRef<HTMLDivElement>;

  cdr = inject(ChangeDetectorRef);

  public isInShowMoreState: boolean = false;
  public isShowMoreRequired: boolean = false;
  safeText!: SafeHtml;

  constructor(private sanitizer: DomSanitizer) {}

  ngOnInit(): void {
    this.safeText = this.sanitizer.bypassSecurityTrustHtml(this.text);
    this.isInShowMoreState = this.expand;
  }

  ngAfterViewInit(): void {
    if (this.showMore) {
      this.checkShowMoreRequired();
      this.cdr.detectChanges();
    }
  }

  checkShowMoreRequired() {
    const contentHeight = this.readModeDivision?.nativeElement?.scrollHeight ?? 0;
    return contentHeight > this.showMoreAfterHeight;
  }

  toggleShowMoreContent(event: Event): void {
    this.isInShowMoreState = !this.isInShowMoreState;
    event.stopPropagation();
  }
}
