import { Meta } from '@storybook/angular';
import { TileButtonComponent } from './tile-button.component';

export default {
  title: 'Enterprise Components/Atoms/Tile Button',
  component: TileButtonComponent,
  parameters: {
    docs: {
      description: {
        component:
          'A tile button component that displays a title, description, icon, and allows toggling its state.',
      },
    },
  },
  argTypes: {
    title: { control: 'text', description: 'The title of the tile button' },
    icon: { control: 'text', description: 'The icon name for the tile button' },
    message: { control: 'text', description: 'A description for the tile button' },
    state: { control: 'boolean', description: 'The toggle state of the tile button' },
  },
} as Meta<TileButtonComponent>;

export const Default = {
  args: {
    title: 'Notifications',
    icon: 'notifications',
    message: 'Manage your notifications',
    state: false,
  },
};

export const ActiveState = {
  args: {
    title: 'Notifications',
    icon: 'notifications',
    message: 'Manage your notifications',
    state: true,
  },
};
