# ADR: Use Input Mapping Instead of Extending Angular Material `MatDivider`

**Status:** Accepted  
**Date:** October 29, 2024  
**Decision Owner:** RGB Dev Team

---

## Context and Problem Statement

We are developing a reusable UI component library that includes a custom `DividerComponent`. The intent is to replicate the functionality of Angular Material’s `MatDivider` while abstracting away the dependency on Angular Material. This allows users of the library to use `DividerComponent` without needing to import Angular Material components directly.

Our initial approach was to extend `MatDivider` directly, but this proved problematic due to issues with styling and functionality inheritance. These issues, likely related to Angular Material’s transition from Material Design 2 (M2) to Material Design 3 (M3), resulted in inconsistent behavior and customization limitations.

## Decision

Instead of extending `MatDivider`, we will create individual inputs in `DividerComponent` that map directly to each relevant property of `MatDivider`. This approach allows `DividerComponent` to maintain similar functionality while gaining flexibility in styling and customization.

### Key Inputs to Map

- **`vertical`**: Controls the orientation of the divider.
- **`inset`**: Adjusts the divider alignment within its container.

Each input will be defined in `DividerComponent` and will apply styles or properties directly, allowing the component to function as expected without relying on Angular Material’s internal component inheritance.

## Alternatives Considered

1. **Extend `MatDivider`**

- **Pros**: Direct reuse of existing functionality and styles, theoretically reducing code duplication.
- **Cons**: Issues with styling and behavior inheritance, especially around theme compatibility with Material Design 3 (M3). Dependency on Angular Material’s internal implementation creates potential for instability.

2. **Implement Input Mapping (Selected Option)**

- **Pros**: Full control over each property, making it adaptable to custom themes and easier to maintain. Users do not require direct Angular Material imports.
- **Cons**: Requires creating and maintaining mappings for each property, which introduces some initial development overhead.

3. **Use Composition Instead of Inheritance**

- **Pros**: Cleaner separation, full control over customization and styling.
- **Cons**: Slightly more complex implementation, as it would involve creating and managing a nested child `MatDivider` component.

## Rationale

The selected approach—using individual input mappings—provides better flexibility, control, and long-term stability for the `DividerComponent`. This method ensures that `DividerComponent` behaves consistently across Angular Material versions and gives the library independence from Angular Material’s internal API changes. This approach also streamlines the experience for users, as they won’t need to manage Angular Material dependencies.

## Consequences

- **Positive**:
  - Independence from Angular Material’s internal component structure and future updates.
  - Consistent customization, styling, and theming across all components in the library.
  - Enhanced maintainability and predictable behavior in future Angular versions.

- **Negative**:
  - Initial development requires mapping each `MatDivider` property to a custom `DividerComponent` input.
  - Potential maintenance if Angular Material’s `MatDivider` component gains new properties or functionality that need manual mapping.

## Implementation

1. Define `DividerComponent` inputs for properties like `vertical`, `inset`.
2. Add necessary SCSS for custom theming, ensuring compatibility with the library’s design requirements.

---

**Decision:** Use Input Mapping to Implement `DividerComponent`
