import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { AALCommonComponentsModule } from '@enterprise-components/common';

import { OverlayCardErrorModule } from '../../overlay-card-alert/overlay-card-alert.module';
import { OverlayCardHelpModule } from '../../overlay-card-help/overlay-card-help.module';
import { SharedFormModule } from '../../shared/shared-form.module';
import { SharedMaterialModule } from '../../shared/shared-material.module';
import { ToolbarConfirmModule } from '../../toolbar-confirm/toolbar-confirm.module';
import { EditableDivTextAreaComponent } from './editable-div-text-area.component';

describe('AAAEditableDivTextAreaComponent', () => {
  let component: EditableDivTextAreaComponent;
  let fixture: ComponentFixture<EditableDivTextAreaComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        OverlayCardHelpModule,
        OverlayCardErrorModule,
        ToolbarConfirmModule,
        EditableDivTextAreaComponent,
      ],
    })
      .compileComponents()
      .then(() => {});
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditableDivTextAreaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call onClick, when setFocusInInput is triggered', () => {
    const spy = spyOn(component, 'onClick');
    component.setFocusInInput();
    expect(spy).toHaveBeenCalled();
  });
});
