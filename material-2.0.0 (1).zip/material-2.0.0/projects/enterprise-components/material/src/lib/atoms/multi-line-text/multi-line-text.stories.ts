import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Meta, moduleMetadata, StoryObj } from '@storybook/angular';
import { MultiLineTextComponent } from './multi-line-text.component';

const meta: Meta<MultiLineTextComponent> = {
  title: 'Enterprise Components/Atoms/Multi Line Text',
  component: MultiLineTextComponent,
  decorators: [
    moduleMetadata({
      imports: [BrowserAnimationsModule],
    }),
  ],
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'A readonly rich text area that displays text content with optional "Show More" functionality to expand or collapse the content based on the specified height.',
      },
    },
  },
  argTypes: {
    showMore: {
      control: 'boolean',
      description: 'Flag to enable or disable the "Show More"/"Show Less" functionality.',
      defaultValue: true,
    },
    showMoreAfterHeight: {
      control: 'number',
      description: 'The height in pixels after which the "Show More"/"Show Less" link appears.',
      defaultValue: 80,
    },
    isMandatory: {
      control: 'boolean',
      description: 'Flag to indicate if the field is mandatory.',
      defaultValue: false,
    },
    mandatoryToolTip: {
      control: 'text',
      description: 'Tooltip text displayed when hovering over the mandatory asterisk.',
      defaultValue: 'This field is required.',
    },
    label: {
      control: 'text',
      description: 'Label for the text area.',
      defaultValue: 'Description',
    },
    text: {
      control: 'text',
      description: 'The content to be displayed inside the text area.',
      defaultValue: 'This is a sample text.',
    },
    expand: {
      control: 'boolean',
      description: 'Flag to set the initial expansion state.',
      defaultValue: false,
    },
  },
};

export default meta;
type Story = StoryObj<MultiLineTextComponent>;

/**
 * Default Story
 * Displays the component with basic text without the "Show More" functionality.
 */
export const Default: Story = {
  args: {
    showMore: false,
    showMoreAfterHeight: 80,
    isMandatory: false,
    mandatoryToolTip: '',
    label: 'Basic Label',
    text: 'This is a simple readonly text area without the show more functionality.',
    expand: false,
  },
};

/**
 * With Show More
 * Displays text that exceeds the specified height with "Show More"/"Show Less" functionality enabled.
 */
export const WithShowMore: Story = {
  args: {
    showMore: true,
    showMoreAfterHeight: 80,
    isMandatory: false,
    mandatoryToolTip: '',
    label: 'Expandable Label',
    text: `Lorem ipsum dolor sit amet, consectetur adipiscing elit.
           Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
           Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
           nisi ut aliquip ex ea commodo consequat.
           i am bigger
           test
           la
           la`,
    expand: false,
  },
};

/**
 * Without Show More
 * Even if the text exceeds the height, the "Show More" functionality is disabled.
 */
export const WithoutShowMore: Story = {
  args: {
    showMore: false,
    showMoreAfterHeight: 80,
    isMandatory: false,
    mandatoryToolTip: '',
    label: 'Non-Expandable Label',
    text: `Lorem ipsum dolor sit amet, consectetur adipiscing elit.
           Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
           Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
           nisi ut aliquip ex ea commodo consequat.`,
    expand: false,
  },
};

/**
 * Mandatory Field
 * Displays the component as a mandatory field with an asterisk and tooltip.
 */
export const Mandatory: Story = {
  args: {
    showMore: true,
    showMoreAfterHeight: 80,
    isMandatory: true,
    mandatoryToolTip: 'This field is required.',
    label: 'Mandatory Label',
    text: `This is a mandatory field. The asterisk indicates that the field is required.`,
    expand: false,
  },
};

/**
 * Initially Expanded
 * The component starts in the expanded state, showing all content by default.
 */
export const InitiallyExpanded: Story = {
  args: {
    showMore: true,
    showMoreAfterHeight: 80,
    isMandatory: false,
    mandatoryToolTip: '',
    label: 'Expanded Label',
    text: `Lorem ipsum dolor sit amet, consectetur adipiscing elit.
           Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
           Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
           nisi ut aliquip ex ea commodo consequat.`,
    expand: true,
  },
};

/**
 * Custom Height
 * Demonstrates the component with a different `showMoreAfterHeight` value.
 */
export const CustomHeight: Story = {
  args: {
    showMore: true,
    showMoreAfterHeight: 150, // Increased height
    isMandatory: false,
    mandatoryToolTip: '',
    label: 'Custom Height Label',
    text: `This text area has a larger height threshold.
           If the content exceeds 150px, the "Show More" link will appear.`,
    expand: false,
  },
};

/**
 * HTML Content
 * Displays HTML content safely inside the text area.
 */
export const HTMLContent: Story = {
  args: {
    showMore: true,
    showMoreAfterHeight: 80,
    isMandatory: false,
    mandatoryToolTip: '',
    label: 'HTML Content Label',
    text: `<strong>Bold Text</strong><br/>
           <em>Italic Text</em><br/>
           <a href="https://www.example.com">Example Link</a><br/>
           <ul>
             <li>List Item 1</li>
             <li>List Item 2</li>
             <li>List Item 3</li>
           </ul>`,
    expand: false,
  },
};
