# ADR: Custom Checkbox Component with ControlValueAccessor

## Context

Our project requires a reusable checkbox component with advanced customization options that can integrate smoothly with Angular's Reactive Forms. The goal is to create a component that adheres to our design system while providing standard form control functionality, including the ability to:
- Manage the checked, indeterminate, and disabled states.
- Integrate seamlessly with reactive forms using `formControlName` or `formControl`.
- Allow for configurable label position and label content.
- Provide a clean API for future reuse in multiple forms across the application.

### Requirements

1. **Reactive Forms Compatibility**: The component should integrate with Angular’s Reactive Forms, enabling use as a form control without requiring additional setup.
2. **Customizable Label Position and Indeterminate State**: The component must allow customization for label position and an optional indeterminate state, making it suitable for use cases like tri-state selection.
3. **Component Isolation and Standalone Setup**: It should work independently as a standalone Angular component to improve maintainability and support modular development.

## Decision

We created a `CheckboxAtomComponent` implementing the `ControlValueAccessor` interface, leveraging `NG_VALUE_ACCESSOR` and `NgControl` to achieve our objectives.

### Key Implementation Details

- **ControlValueAccessor Implementation**: By implementing `ControlValueAccessor`, the component conforms to Angular’s Reactive Forms API, allowing it to interact with form controls seamlessly.
- **Providers Configuration**:
  - The component is registered with the `NG_VALUE_ACCESSOR` token in its `providers` array. This registration allows Angular to recognize it as a form control, providing automatic handling of value changes, disable states, and touched events.
  - The `multi: true` option ensures this component can coexist with other form controls if needed.
- **NgControl Injection in Constructor**:
  - Injecting `NgControl` using `@Self()` and `@Optional()` decorators allows the component to conditionally act as a form control when used within a form.
  - The `this.ngControl.valueAccessor = this` assignment explicitly registers the component as the control's `valueAccessor`. This registration establishes a link between the form control and this component, ensuring that value changes and state transitions propagate correctly.

### Sample Component Code

The key code is shown below, with `ControlValueAccessor` implementation, `providers` setup, and `NgControl` injection in the constructor:

```typescript
@Component({
  selector: 'aal-checkbox-atom',
  standalone: true,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => CheckboxAtomComponent),
      multi: true,
    },
  ],
  templateUrl: './checkbox-atom.component.html',
})
export class CheckboxAtomComponent implements ControlValueAccessor {
  // Checkbox properties
  indeterminate = model(false);
  checked = model(false);
  disabled = model(false);
  labelPosition = input<'before' | 'after'>('after');
  label = input<string>('');

  private onChange: (value: boolean) => void = () => {};
  private onTouched: () => void = () => {};

  constructor(@Optional() @Self() public ngControl: NgControl) {
    if (this.ngControl) {
      this.ngControl.valueAccessor = this;
    }
  }

  // ControlValueAccessor methods
  onCheckboxChange(checked: boolean) {
    this.checked.set(checked);
    this.onChange(checked);
    this.onTouched();
  }
  writeValue(value: boolean): void { this.checked.set(value); }
  registerOnChange(fn: (value: boolean) => void): void { this.onChange = fn; }
  registerOnTouched(fn: () => void): void { this.onTouched = fn; }
  setDisabledState(isDisabled: boolean): void { this.disabled.set(isDisabled); }
}
```

## Rationale

1. **Reusable and Consistent**: Implementing `ControlValueAccessor` allows the `CheckboxAtomComponent` to function as a native form control, ensuring consistent behavior across forms and simplifying form binding.
2. **Declarative API**: By providing customization options through component inputs, we support various checkbox configurations while maintaining a declarative approach for users of the component.
3. **Improved Maintainability**: The standalone configuration and adherence to Angular’s Reactive Forms API make this component modular, maintainable, and future-proof for potential expansion.

## Consequences

- **Positive**:
  - **Simplified Form Integration**: The component is fully compatible with Angular Reactive Forms, simplifying form control integration.
  - **Customizability**: The component’s properties (e.g., `indeterminate`, `labelPosition`, `label`) allow it to be easily adapted for multiple use cases.
  - **Future Flexibility**: By using Angular’s forms infrastructure, the component is positioned for easy expansion or modification.

- **Negative**:
  - **Increased Complexity for Non-Form Use Cases**: The reliance on `ControlValueAccessor` and `NgControl` may add some complexity if the component is used outside of a form, though this is mitigated by making `ngControl` optional.

## Status

**Accepted**: This approach is implemented and working as intended, fulfilling our requirements for a reusable, form-compatible checkbox component.
