import { CommonModule } from '@angular/common';
import { Component, input, signal } from '@angular/core';
import { MatBadgeModule } from '@angular/material/badge';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { AALCommonButtonComponent } from '@enterprise-components/common';
export type Condition = 'expanded' | 'collapsed';
@Component({
  selector: 'aal-button-nav',
  standalone: true,
  imports: [CommonModule, MatBadgeModule, MatButtonModule, MatIconModule, MatTooltipModule],
  templateUrl: './button-nav.component.html',
  styleUrls: ['./button-nav.component.scss'],
})
export class AALButtonNavComponent extends AALCommonButtonComponent {
  condition = input<Condition>('collapsed');
  level = input<number>(0);
  isActive = signal<boolean>(false);

  toggleActive() {
    this.isActive.set(!this.isActive());
  }
}
