import { HarnessLoader } from '@angular/cdk/testing';
import { TestbedHarnessEnvironment } from '@angular/cdk/testing/testbed';
import { signal } from '@angular/core';
import { ComponentFixture, fakeAsync, TestBed } from '@angular/core/testing';
import { MatSlideToggleHarness } from '@angular/material/slide-toggle/testing';
import { SlideToggleComponent } from './slide-toggle.component';

describe('SlideToggleComponent', () => {
  let fixture: ComponentFixture<SlideToggleComponent>;
  let loader: HarnessLoader;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SlideToggleComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(SlideToggleComponent);
    loader = TestbedHarnessEnvironment.loader(fixture);
    fixture.detectChanges();
  });

  it('should render slide toggle with default properties', async () => {
    const slideToggle = await loader.getHarness(MatSlideToggleHarness);

    expect(await slideToggle.isChecked()).toBe(false); // Default checked state
    expect(await slideToggle.isDisabled()).toBe(false); // Default disabled state
  });

  it('should update the checked state', async () => {
    fakeAsync(async () => {
      const slideToggle = await loader.getHarness(MatSlideToggleHarness);

      // Update signal using the workaround
      fixture.componentInstance.checked = signal(
        true,
      ) as unknown as typeof fixture.componentInstance.checked;
      fixture.detectChanges();

      expect(await slideToggle.isChecked()).toBe(true);
    });
  });

  it('should disable the slide toggle', async () => {
    fakeAsync(async () => {
      const slideToggle = await loader.getHarness(MatSlideToggleHarness);

      // Update signal using the workaround
      fixture.componentInstance.disabled = signal(
        true,
      ) as unknown as typeof fixture.componentInstance.disabled;
      fixture.detectChanges();

      expect(await slideToggle.isDisabled()).toBe(true);
    });
  });

  it('should update the color', async () => {
    fakeAsync(async () => {
      const slideToggle = await loader.getHarness(MatSlideToggleHarness);

      // Update signal using the workaround
      fixture.componentInstance.color = signal(
        'accent',
      ) as unknown as typeof fixture.componentInstance.color;
      fixture.detectChanges();

      // Validate color (custom logic may be required)
      const ariaLabel = await slideToggle.getAriaLabel();
      expect(ariaLabel).toBe('accent'); // Adjust based on your implementation
    });
  });

  it('should display the message', async () => {
    fakeAsync(async () => {
      const slideToggle = await loader.getHarness(MatSlideToggleHarness);

      // Update signal using the workaround
      fixture.componentInstance.message = signal(
        'Test Message',
      ) as unknown as typeof fixture.componentInstance.message;
      fixture.detectChanges();

      const labelText = await slideToggle.getLabelText();
      expect(labelText).toContain('Test Message');
    });
  });
});
