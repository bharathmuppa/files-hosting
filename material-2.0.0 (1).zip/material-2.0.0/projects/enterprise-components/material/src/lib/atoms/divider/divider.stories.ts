import { MatList, MatListModule } from '@angular/material/list';
import { argsToTemplate, Meta, moduleMetadata, StoryObj } from '@storybook/angular';
import { DividerComponent } from './divider.component';

const meta: Meta<DividerComponent> = {
  title: 'Enterprise Components/Atoms/Divider',
  component: DividerComponent,
  tags: ['autodocs'],
  decorators: [moduleMetadata({ imports: [MatList, MatListModule] })],
  parameters: {
    docs: {
      description: {
        component:
          'The Divider component is used to visually separate content into distinct sections. It supports both horizontal and vertical orientations, as well as optional insets for indentation. When using a vertical orientation, a specific height is applied to ensure it displays correctly within the container.',
      },
    },
  },
  argTypes: {
    inset: { control: { type: 'boolean' }, table: { readonly: true } },
    vertical: { control: { type: 'boolean' }, table: { readonly: true } },
  },
};

export default meta;

type Story = StoryObj<DividerComponent>;

// Playground - fully interactive story with `vertical` and `inset` controls
export const Playground: Story = {
  args: {
    inset: false,
    vertical: false,
  },

  parameters: {
    docs: {
      description: {
        story:
          'This story provides a fully interactive playground for the Divider component. You can toggle the `inset` and `vertical` properties to see how they change the appearance and layout of the divider. Use this variant to explore the customization options available.',
      },
    },
  },

  argTypes: {
    inset: { control: { type: 'boolean' }, table: { readonly: false } },
    vertical: { control: { type: 'boolean' }, table: { readonly: false } },
  },
};

// Horizontal - basic horizontal divider
export const Horizontal: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Displays a basic horizontal divider, used to visually separate sections horizontally within a layout.',
      },
    },
  },
};

// Horizontal with Inset - horizontal divider with inset
export const HorizontalWithInset: Story = {
  args: {
    inset: true,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Displays a horizontal divider with an inset, creating an indented look. Useful for separating sections with a subtle margin.',
      },
    },
  },
};

// Vertical - basic vertical divider with style height set
export const Vertical: Story = {
  args: {
    vertical: true,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Displays a basic vertical divider with a specified height. **Note**: We apply a height to vertical dividers to ensure they render as intended within containers. Without an explicit height, vertical dividers may not display correctly.',
      },
    },
  },
  render: (args) => ({
    template: `
      <div style="height: 200px; display: flex; align-items: center; justify-content: center; border: 1px solid gray;">
        <aal-divider ${argsToTemplate(args)} style="height: 150px;"></aal-divider>
      </div>`,
    props: args,
  }),
};

// Vertical with Inset - vertical divider with inset and style height set
export const VerticalWithInset: Story = {
  args: {
    vertical: true,
    inset: true,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Displays a vertical divider with an inset and a specified height. **Note**: Setting an explicit height for vertical dividers ensures they appear consistently and don’t collapse due to lack of content height in the parent container.',
      },
    },
  },
  render: (args) => ({
    template: `
      <div style="height: 200px; display: flex; align-items: center; justify-content: center; border: 1px solid gray;">
       <aal-divider [vertical]="vertical" [inset]="inset" style="height: 150px;"></aal-divider>
      </div>`,
    props: args,
  }),
};

// In Flex Container - divider within a flex container
export const InFlexContainer: Story = {
  args: {
    vertical: true,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Shows the divider within a flex container, demonstrating how it aligns and separates content within a flexible layout. **Note**: An explicit height is added to the vertical divider here to ensure it displays consistently between flex items.',
      },
    },
  },
  render: (args) => ({
    template: `
      <div style="display: flex; height: 200px; align-items: center; justify-content: space-between; border: 1px solid gray;">
        <div>Content Block 1</div>
        <aal-divider [vertical]="vertical"  style="height: 150px;"></aal-divider>
        <div>Content Block 2</div>
      </div>`,
    props: args,
  }),
};

// In Block Container - divider within a block-level container
export const InBlockContainer: Story = {
  args: {
    vertical: true,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Displays the divider within a block-level container, showing its behavior in a standard block layout.',
      },
    },
  },
  render: (args) => ({
    template: `
      <div style="width: 100%; height: 200px; border: 1px solid gray; display: block;">
        <aal-divider [vertical]="vertical"  style="height: 150px;"></aal-divider>
      </div>`,
    props: args,
  }),
};

// Divider in a Mat List
export const InVerticalMatList: Story = {
  args: {
    vertical: true,
    inset: true,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Displays the divider within a `mat-list`, separating list items vertically. This configuration provides clear section breaks in structured lists, improving readability and organization in lists like side navigation or categorized item lists.',
      },
    },
  },
  render: (args) => ({
    template: `
      <mat-list>
        <mat-list-item>Item 1</mat-list-item>
        <aal-divider></aal-divider>
        <mat-list-item>Item 2</mat-list-item>
        <aal-divider></aal-divider>
        <mat-list-item>Item 3</mat-list-item>
      </mat-list>
    `,
    props: args,
    moduleMetadata: {
      imports: [MatList],
    },
  }),
};

// Divider in a Mat List
export const InHorizontalMatList: Story = {
  args: {
    vertical: true,
    inset: true,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Displays the divider within a horizontal `mat-list`, separating items side by side. This setup is useful in navigation layouts, where items are placed horizontally but need clear separation. **Note**: Using `height: 100%` on a vertical divider within a horizontal container does not work as expected, because the list items are not stretching the full height of the container. Instead, set an explicit height (e.g., `24px`) for consistent display.',
      },
    },
  },
  render: (args) => ({
    template: `
      <mat-list style="display: flex; flex-direction: row; gap: 1rem; align-items: center; padding: 8px 16px; background-color: #f5f5f5; border-bottom: 1px solid #ddd;">
        <mat-list-item>Item 1</mat-list-item>
        <aal-divider [vertical]="vertical" [style.height]="'24px'"></aal-divider>
        <mat-list-item>Item 2</mat-list-item>
        <aal-divider [vertical]="vertical" [style.height]="'24px'"></aal-divider>
        <mat-list-item>Item 3</mat-list-item>
      </mat-list>
    `,
    props: args,
    moduleMetadata: {
      imports: [MatList],
    },
  }),
};

// Divider in a Horizontal Header Menu
export const InHorizontalHeader: Story = {
  args: {
    vertical: true,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Displays the divider in a horizontal header layout, separating menu items. This setup is particularly useful for navigation headers, where distinct sections between items improve readability. **Note**: Using `height: 100%` on a vertical divider in this scenario does not work, as each header item has an independent height rather than a shared container height. Set a specific height (e.g., `24px`) for consistent alignment with the menu items.',
      },
    },
  },
  render: (args) => ({
    template: `
      <div style="display: flex; align-items: center; padding: 8px 16px; background-color: #f5f5f5; border-bottom: 1px solid #ddd; gap: 1rem;">
        <div>Home</div>
        <aal-divider [vertical]="vertical" [style.height]="'24px'"></aal-divider>
        <div>About</div>
        <aal-divider [vertical]="vertical" [style.height]="'24px'"></aal-divider>
        <div>Contact</div>
      </div>
    `,
    props: args,
  }),
};

// Note: The argsToTemplate helper function converts the args to property and event bindings.
// You could also write the template in plain HTML and bind to the component's inputs and outputs yourself:
// <storybook-button ["label"]="label" (onClick)="onClick($event)">
// We don't recommend the latter since it can conflict with how Storybook applies arguments via its controls addon.
// Binding to the component's inputs and outputs yourself will conflict with default values set inside the component's class.
// In edge-case scenarios, you may need to define the template yourself, though.
