# AALButtonOverlayComponent Documentation

The `AALButtonOverlayComponent` is a reusable Angular component that displays a customizable button with optional text and icons. This component is highly flexible and allows developers to create buttons with various styles by providing inputs for names and icons.



## Component Selector

```html
<aal-button-overlay></aal-button-overlay>
```

## Imports

To use the `AALButtonOverlayComponent`, ensure that your Angular module includes any necessary dependencies, such as Angular Material for icon rendering or other utilities based on your implementation. No external modules are required beyond those normally used in Angular component setups.

```typescript
import { AALButtonOverlayComponent } from '@enterprise-components/material/button-overlay';
```

## Properties

### Inputs

The `AALButtonOverlayComponent` accepts several inputs for customization:

| Input       | Type                   | Default Value | Description |
|-------------|------------------------|---------------|-------------|
| `name`      | `string`               | ``             | The text displayed inside the button. |
| `icon`      | `string`               | ``             | The name of the Material icon to display inside the button. derived from this input. |

## Usage Examples

### Basic Button with Text (Default)

The following example demonstrates how to use the `aal-button-overlay` component with text only:

```html
<aal-button-overlay [name]="'Overlay Button with Text'"></aal-button-overlay>
```

This will render a button labeled "Overlay Button with Text."

### Button with Icon

To create a button with only an icon, provide the `icon` input:

```html
<aal-button-overlay [icon]="'edit'"></aal-button-overlay>
```

This will render a button that displays the Material Design "edit" icon.
