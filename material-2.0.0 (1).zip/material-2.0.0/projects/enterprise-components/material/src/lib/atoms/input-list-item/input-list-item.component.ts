import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'aal-input-list-item',
  standalone: true,
  imports: [],
  templateUrl: './input-list-item.component.html',
  styleUrl: './input-list-item.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class InputListItemComponent {}
