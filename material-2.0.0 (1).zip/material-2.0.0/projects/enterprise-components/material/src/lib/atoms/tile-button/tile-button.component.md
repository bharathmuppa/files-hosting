# ADR

This tile button component is a button that is styled as a tile. It is used to represent a clickable tile in a grid or list of tiles.

## UX Specs
Button-like elements that resemble tiles or card layouts. 
These are typically visually prominent, rectangular or square, and can contain text, icons, or even images, serving as actionable items in a grid or list layout. 
In Material Design, such components might be implemented a contained buttons,cards, or image buttons within a grid layout, styled to achieve a "tile" effect.

Requirement:
- Style: Contained buttons/raised cards , use a filled background to create a visual distinction from the background.
- Padding & Spacing : Good to have consistent padding and spacing within and around Tile Buttons to ensure readability and touch target accessibility.
- Icon & Text Integration :Tile Buttons can include both an icon and text to make their purpose immediately clear.
- Elevation & Shadow for Depth : To give Tile Buttons a sense of depth, use elevation (shadow) to make them appear raised above the surface.
- Color: Tile Buttons often adopt the primary or secondary color of the app’s theme, aligning them with the brand's identity.

## Technical Specs
 This component is a simple standalone component which composes of three rows of content: icon, title and subtitle.
 styling is done based on design specs and material design guidelines.
 
