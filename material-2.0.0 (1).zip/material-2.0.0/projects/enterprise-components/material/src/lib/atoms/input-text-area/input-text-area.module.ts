import { NgModule } from '@angular/core';
import { InputTextAreaComponent } from './input-text-area.component';

@NgModule({
  imports: [InputTextAreaComponent],
  exports: [InputTextAreaComponent],
})
export class InputTextAreaModule {}
