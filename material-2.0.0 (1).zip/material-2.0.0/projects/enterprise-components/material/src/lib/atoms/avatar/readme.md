# AvatarComponent Documentation

The `AvatarComponent` is a standalone, reusable Angular component for displaying avatars with conditional rendering based on provided inputs. It can display an image, user initials, or a default icon if no other data is available. It also supports different sizes and can be disabled for specific use cases.

## Component Selector

```html
<aal-avatar></aal-avatar>
```

## Imports

To use the `AvatarComponent`, make sure your module includes the Angular Material `MatIconModule` and `CommonModule` if you're using it outside of a standalone component setup.

```typescript
import { AvatarComponent } from '@enterprise-components/material/avatar';
```

## Properties

### Inputs

The `AvatarComponent` accepts several inputs for customization:

| Input       | Type                   | Default Value | Description |
|-------------|------------------------|---------------|-------------|
| `size`      | `'sm' \| 'md' \| 'lg'` | `'md'`        | Controls the size of the avatar. Can be one of `sm` (small), `md` (medium), or `lg` (large). |
| `fullName`  | `string`               | `''`          | The full name of the user. If `image` is not provided, the component will display the initials derived from this input. |
| `disabled`  | `boolean`              | `false`       | When set to `true`, the avatar will appear in a disabled state with reduced opacity. |
| `image`     | `string \| null`       | `null`        | The URL of the image to display. If provided, this image will take precedence over initials and icon. |

### Computed Properties

| Property    | Type               | Description |
|-------------|--------------------|-------------|
| `initials`  | `string`           | A computed property that generates the initials from `fullName`. Displays up to two initials derived from the first letters of the provided name. |

## Usage Examples

### Basic Usage

The following example shows how to use the `aal-avatar` component with minimal configuration.

```html
<aal-avatar></aal-avatar>
```

This will render the default avatar icon (a person icon) with the default medium size (`md`).

### Displaying an Avatar Image

To display an avatar image, provide the `image` input.

```html
<aal-avatar [image]="'https://www.w3schools.com/howto/img_avatar.png'"></aal-avatar>
```

This configuration will display the specified image URL in place of initials or the default icon.

### Displaying Initials

If the `image` is not provided, the `fullName` input can be used to display initials.

```html
<aal-avatar [fullName]="'John Doe'"></aal-avatar>
```

This will display "JD" as the initials for "John Doe."

### Adjusting the Avatar Size

The component supports three size options: `sm`, `md`, and `lg`.

```html
<aal-avatar [size]="'lg'" [fullName]="'John Doe'"></aal-avatar>
```

This configuration will display the initials in a large avatar.

### Disabled State

To render the avatar in a disabled state, set the `disabled` input to `true`.

```html
<aal-avatar [fullName]="'John Doe'" [disabled]="true"></aal-avatar>
```

This will display the avatar with reduced opacity, indicating it is in a disabled state.

## Notes

- **Fallback Behavior**: If both `image` and `fullName` are missing, the component will display a default Material icon (`person`) to represent the avatar.

This component is designed to be flexible, offering users multiple ways to personalize avatar representations.
