import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { MatBadgeModule } from '@angular/material/badge';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { AALCommonButtonComponent } from '@enterprise-components/common';

@Component({
  selector: 'aal-button-overlay',
  standalone: true,
  imports: [CommonModule, MatButtonModule, MatBadgeModule, MatIconModule, MatTooltipModule],
  templateUrl: './button-overlay.component.html',
  styleUrls: ['./button-overlay.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AALButtonOverlayComponent extends AALCommonButtonComponent {
  trailingIcon = input<string>('');
  classes: { [key: string]: boolean };
}
