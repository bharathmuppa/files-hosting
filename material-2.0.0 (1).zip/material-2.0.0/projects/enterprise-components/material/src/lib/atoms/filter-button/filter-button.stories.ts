import { Meta, StoryObj } from '@storybook/angular';
import { FilterButtonComponent } from './filter-button.component';

const meta: Meta<FilterButtonComponent> = {
  title: 'Enterprise Components/Atoms/Filter Button',
  component: FilterButtonComponent,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: `
        The Filter Button component is a reusable button that allows users to filter content.
        It supports different sizes (\`sm\`, \`md\`, \`lg\`), layouts (\`row\`, \`col\`), and can include an optional checkbox, icon, or SVG.
        `,
      },
    },
  },
  argTypes: {
    size: {
      control: { type: 'radio' },
      options: ['sm', 'md', 'lg'],
      description: 'Determines the size of the button.',
    },
    layout: {
      control: { type: 'radio' },
      options: ['col', 'row'],
      description: 'Determines the button layout (row or column).',
    },
    checkbox: {
      control: { type: 'boolean' },
      description: 'Shows or hides the checkbox.',
    },
    label: {
      control: { type: 'text' },
      description: 'The text label displayed inside the button.',
    },
    count: {
      control: { type: 'number' },
      description: 'An optional count to display inside the button.',
    },
    icon: {
      control: { type: 'text' },
      description: 'A material icon name to display.',
    },
    svg: {
      control: { type: 'text' },
      description: 'A custom SVG icon name to display.',
    },
  },
};

export default meta;

type Story = StoryObj<FilterButtonComponent>;

// Playground - fully interactive story
export const Playground: Story = {
  args: {
    size: 'md',
    layout: 'col',
    checkbox: true,
    label: 'Filter',
    count: 10,
    icon: 'add_task',
  },
  parameters: {
    docs: {
      description: {
        story: `
        This story provides a fully interactive playground for the Filter Button component.
        You can adjust the size, layout, checkbox visibility, and icons dynamically.
        `,
      },
    },
  },
};

// Row Layout
export const RowLayout: Story = {
  args: {
    size: 'md',
    layout: 'row',
    checkbox: false,
    label: 'Filter by Category',
    count: 5,
  },
  parameters: {
    docs: {
      description: {
        story: 'Displays the filter button in a row layout with a label and count.',
      },
    },
  },
};

// Small Size
export const SmallSize: Story = {
  args: {
    size: 'sm',
    layout: 'col',
    checkbox: true,
    label: 'Small Filter',
  },
  parameters: {
    docs: {
      description: {
        story: 'A small-sized filter button with a checkbox.',
      },
    },
  },
};

// With Icon
export const WithSimpleLabelAndCount: Story = {
  args: {
    size: 'lg',
    layout: 'col',
    label: 'Filter',
    count: 500,
  },
  parameters: {
    docs: {
      description: {
        story: 'Filter Button with a label and count.',
      },
    },
  },
};

// With Checkbox
export const WithCheckbox: Story = {
  args: {
    size: 'lg',
    layout: 'row',
    label: 'Filter with Checkbox',
    checkbox: true,
  },
  parameters: {
    docs: {
      description: {
        story: 'A large filter button with a checkbox for multi-select functionality.',
      },
    },
  },
};
