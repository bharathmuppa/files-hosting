/*
 * Public API Surface of material
 */

export * from './editable-div-text-area.component';
export * from './editable-div-text-area.module';
