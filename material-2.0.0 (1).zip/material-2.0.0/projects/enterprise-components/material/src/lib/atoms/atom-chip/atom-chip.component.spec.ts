import { Component, ViewChild } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatChipListbox } from '@angular/material/chips';
import { By } from '@angular/platform-browser';
import { AtomChipComponent } from './atom-chip.component';

@Component({
  selector: 'test-chip-wrapper',
  imports: [AtomChipComponent, MatChipListbox],
  standalone: true,
  template: `
    <mat-chip-listbox>
      <aal-atom-chip
        [label]="label"
        [removable]="removable"
        [avatarWithImage]="avatarWithImage"
        [avatarWithInitials]="avatarWithInitials"
        [avatarWithIcon]="avatarWithIcon"
        [maxCharacters]="maxCharacters"
        [color]="color"
        (removed)="onRemoved($event)"></aal-atom-chip>
    </mat-chip-listbox>
  `,
})
class TestChipWrapperComponent {
  @ViewChild(AtomChipComponent) chipComponent!: AtomChipComponent;

  label = 'Sample Label';
  removable = false;
  avatarWithImage?: string;
  avatarWithInitials?: string;
  avatarWithIcon?: string;
  maxCharacters = 32;
  color: 'in-progress' | 'rejected' | 'done' | 'default' = 'default';
  removedData: any = null;

  onRemoved(data: any) {
    this.removedData = data;
  }
}

describe('AtomChipComponent', () => {
  let wrapperFixture: ComponentFixture<TestChipWrapperComponent>;
  let wrapperComponent: TestChipWrapperComponent;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TestChipWrapperComponent],
    }).compileComponents();

    wrapperFixture = TestBed.createComponent(TestChipWrapperComponent);
    wrapperComponent = wrapperFixture.componentInstance;
    wrapperFixture.detectChanges();
  });

  it('should create the AtomChipComponent inside a mat-chip-listbox', () => {
    const chipListbox = wrapperFixture.debugElement.query(By.directive(MatChipListbox));
    const chip = wrapperFixture.debugElement.query(By.directive(AtomChipComponent));
    expect(chipListbox).toBeTruthy();
    expect(chip).toBeTruthy();
  });

  it('should display the label text truncated if it exceeds maxCharacters', () => {
    wrapperComponent.label = 'This is a very long label that should be truncated';
    wrapperComponent.maxCharacters = 20;
    wrapperFixture.detectChanges();

    const chipText = wrapperFixture.debugElement.query(By.css('.aal-chip__text')).nativeElement;
    expect(chipText.textContent).toContain('This is a very long ...');
  });

  it('should display the avatar with image when avatarWithImage is provided', () => {
    wrapperComponent.avatarWithImage = 'test-image-url';
    wrapperFixture.detectChanges();

    const avatarImg = wrapperFixture.debugElement.query(By.css('.aal-avatar__image'));
    expect(avatarImg).toBeTruthy();
    expect(avatarImg.nativeElement.src).toContain('test-image-url');
  });

  it('should display initials avatar if avatarWithInitials is provided and no image is available', () => {
    wrapperComponent.avatarWithImage = null;
    wrapperComponent.avatarWithInitials = 'Alice Bob';
    wrapperFixture.detectChanges();

    const avatarInitials = wrapperFixture.debugElement.query(By.css('.aal-avatar__initials'));
    expect(avatarInitials).toBeTruthy();
    expect(avatarInitials.nativeElement.textContent).toBe('AB');
  });

  it('should display default avatar if neither image nor initials are provided', () => {
    wrapperComponent.avatarWithImage = null;
    wrapperComponent.avatarWithInitials = null;
    wrapperComponent.avatarWithIcon = 'default-avatar';
    wrapperFixture.detectChanges();

    const defaultAvatarIcon = wrapperFixture.debugElement.query(
      By.css('mat-icon.aal-avatar__icon'),
    );
    expect(defaultAvatarIcon).toBeTruthy();
  });

  it('should apply the correct color class based on color input', () => {
    wrapperComponent.color = 'in-progress';
    wrapperFixture.detectChanges();

    const chip = wrapperFixture.debugElement.query(By.css('.aal-chip'));
    expect(chip.nativeElement.classList).toContain('in-progress');

    wrapperComponent.color = 'rejected';
    wrapperFixture.detectChanges();
    expect(chip.nativeElement.classList).toContain('rejected');

    wrapperComponent.color = 'done';
    wrapperFixture.detectChanges();
    expect(chip.nativeElement.classList).toContain('done');
  });

  it('should display remove button if removable is true', () => {
    wrapperComponent.removable = true;
    wrapperFixture.detectChanges();

    const removeButton = wrapperFixture.debugElement.query(By.css('button[matChipRemove]'));
    expect(removeButton).toBeTruthy();
  });

  it('should emit removed event with data when remove button is clicked', () => {
    wrapperComponent.removable = true;
    wrapperComponent.label = 'Removable Chip';
    wrapperFixture.detectChanges();

    const removeButton = wrapperFixture.debugElement.query(By.css('button[matChipRemove]'));
    removeButton.triggerEventHandler('click', null);
    wrapperFixture.detectChanges();

    expect(wrapperComponent.removedData).toBe(wrapperComponent.chipComponent.data());
  });
});
