export * from './avatar.component';
export * from './avatar.module';
