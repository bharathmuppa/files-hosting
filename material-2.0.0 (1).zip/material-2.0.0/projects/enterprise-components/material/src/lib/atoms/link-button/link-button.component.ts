import { NgClass } from '@angular/common';
import { ChangeDetectionStrategy, Component, input, InputSignal } from '@angular/core';

/**
 * Represents the allowed sizes for the link button.
 */
export type LinkButtonSize = 'md' | 'lg';

@Component({
  selector: 'aal-link-button',
  standalone: true,
  imports: [NgClass],
  templateUrl: './link-button.component.html',
  styleUrls: ['./link-button.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LinkButtonComponent {
  /**
   * The URL the link button should navigate to.
   * Defaults to an empty string if not provided.
   */
  link: InputSignal<string> = input('');

  /**
   * The text to be displayed as the label of the link button.
   * Defaults to an empty string if not provided.
   */
  label: InputSignal<string> = input('');

  /**
   * The target attribute specifies where to open the linked document.
   * Defaults to '_blank' for opening in a new tab.
   */
  target: InputSignal<string> = input('_blank');

  /**
   * Determines the size of the link button.
   * Accepts 'md' (medium) or 'lg' (large).
   * Defaults to 'md'.
   */
  size: InputSignal<LinkButtonSize> = input<LinkButtonSize>('md');

  /**
   * Tracks whether the link button has been visited (clicked).
   */
  isVisited = false;

  /**
   * Marks the link button as visited.
   * Triggered when the button is clicked.
   */
  markAsVisited() {
    this.isVisited = true;
  }
}
