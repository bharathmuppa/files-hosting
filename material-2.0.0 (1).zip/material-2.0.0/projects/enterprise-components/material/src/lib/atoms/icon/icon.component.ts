import { NgClass } from '@angular/common';
import { ChangeDetectionStrategy, Component, HostBinding, input } from '@angular/core';
import { MatIcon } from '@angular/material/icon';

export type ICON_SIZE = 'sm' | 'md' | 'lg';

@Component({
  selector: 'aal-icon',
  standalone: true,
  imports: [MatIcon, NgClass],
  templateUrl: './icon.component.html',
  styleUrl: './icon.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class IconComponent {
  /**
   * The name of the icon to display.
   */
  svg = input<string>();

  /**
   * The name of the material icon to display.
   */
  icon = input<string>();
  /**
   * The size of the icon.
   */
  size = input<ICON_SIZE>('md');
  /**
   * The color of the icon.
   */
  color = input<string>();

  /**
   * We need to set the height of host component based on the size of the icon.
   * or else it won't match the line height of the text.
   * this should match the height of icon styles in the icon.scss
   */
  @HostBinding('style.height') get hostHeight() {
    let lnHeight = 'inherit';
    if (this.size() === 'sm') {
      lnHeight = '1rem';
    } else if (this.size() === 'md') {
      lnHeight = '1.5rem';
    } else if (this.size() === 'lg') {
      lnHeight = '2.5rem';
    }
    return lnHeight;
  }
}
