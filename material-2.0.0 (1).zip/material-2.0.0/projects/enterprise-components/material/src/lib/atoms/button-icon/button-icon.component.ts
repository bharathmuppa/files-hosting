import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { MatIconButton } from '@angular/material/button';
import { MatIcon } from '@angular/material/icon';

@Component({
  selector: 'aal-button-icon',
  standalone: true,
  imports: [MatIcon, MatIconButton],
  templateUrl: './button-icon.component.html',
  styleUrl: './button-icon.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ButtonIconComponent {
  @Input() color: 'primary' | 'secondary' | 'warn' | 'default' = 'default';
  @Input() icon: string = 'home';
  @Input() size: 'xs' | 'sm' | 'md' | 'lg' = 'lg';
  @Input() tooltip: string = '';
  @Input() disabled: boolean = false;

  @Output() onClick = new EventEmitter<Event>();
}
