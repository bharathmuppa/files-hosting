import { Meta, StoryObj } from '@storybook/angular';
import { SlideToggleComponent } from './slide-toggle.component';

const meta: Meta<SlideToggleComponent> = {
  title: 'Enterprise Components/Atoms/SlideToggle',
  component: SlideToggleComponent,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: 'Component is used to toggle the state.',
      },
    },
  },
  argTypes: {
    color: { control: { type: 'text' } },
    checked: { control: { type: 'boolean' } },
    disabled: { control: { type: 'boolean' } },
    message: { control: { type: 'text' } },
  },
};

export default meta;
type Story = StoryObj<SlideToggleComponent>;

export const Primary: Story = {
  args: {},
};

export const ProjectedContent: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Displays a snack bar with projected content instead of normal message.',
      },
    },
  },
  render: (args) => ({
    template: `
      <div>
        <aal-slide-toggle>
            <span class="aal-slide-toggle-content"> Is this a pizza 🍕? </span>
      </aal-slide-toggle>
      </div>`,
    props: args,
  }),
};
