import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { UntypedFormControl } from '@angular/forms';
import { AALCommonComponentsModule } from '@enterprise-components/common';

import { OverlayCardErrorModule } from '../../overlay-card-alert/overlay-card-alert.module';
import { OverlayCardHelpModule } from '../../overlay-card-help/overlay-card-help.module';
import { SharedFormModule } from '../../shared/shared-form.module';
import { SharedMaterialModule } from '../../shared/shared-material.module';
import { ToolbarConfirmModule } from '../../toolbar-confirm/toolbar-confirm.module';
import { ButtonRadioComponent } from './button-radio.component';

describe('ButtonRadioComponent', () => {
  let component: ButtonRadioComponent;
  let fixture: ComponentFixture<ButtonRadioComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        OverlayCardHelpModule,
        OverlayCardErrorModule,
        ToolbarConfirmModule,
        ButtonRadioComponent,
      ],
    })
      .compileComponents()
      .then(() => {});
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ButtonRadioComponent);
    component = fixture.componentInstance;
    component.control = new UntypedFormControl();
    jasmine.clock().uninstall();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set the layout to column if there are more than 3 options', () => {
    component.options = new Array(4);
    component.setLayout();
    expect(component.layout).toBe('column');
  });

  it('should set the layout to row if there are less than 3 options', () => {
    component.options = new Array(2);
    component.setLayout();
    expect(component.layout).toBe('row');
  });
  it('should set the control value to empty', () => {
    component.control = new UntypedFormControl('value');
    component.resetControl();
    expect(component.control.value).toBe(null);
  });

  it('should return line1 description, when getLine1ByOption is triggered', () => {
    component.optionLine1Field = 'line1';
    const optionText = component.getLine1ByOption({ line1: 'option text' });
    expect(optionText).toBe('option text');
  });

  it('should return, when onButtonRadioBlur is triggered and related target is one of the radio button options', () => {
    component.hyphenatedID = 'test';
    const elem = document.createElement('div');
    elem.classList.add('test');
    elem.id = 'test_button_toggle_1';
    const retValue = component.onButtonRadioBlur(new FocusEvent('blur', { relatedTarget: elem }));
    expect(retValue).toEqual(undefined);
  });

  it('should set appropriate mode, when resetMode is triggered and related target is not one of the radio button options', () => {
    component.resetMode({ relatedTarget: null });
    expect(component.mode).toBe('READ');
  });

  it('should set appropriate mode, when onButtonRadioBlur is triggered, no relatedTarget exists or related target is not one of the radio button options', () => {
    component.onButtonRadioBlur({ relatedTarget: null });
    expect(component.mode).toBe('READ');
  });

  it('should set appropriate mode, when onKeyUp is triggered and ESC key is pressed', () => {
    component.onKeyUp({
      key: 'Escape',
      currentTarget: {
        children: [],
      },
    });
    expect(component.mode).toBe('READ');
  });

  it('should set appropriate mode, when onKeyUp is triggered and ARROWRIGHT/ARROWLEFT key is pressed', () => {
    component.onKeyUp({
      key: 'ArrowRight',
      currentTarget: {
        children: [],
      },
    });
    expect(component.mode).toBe('EDIT');
  });

  it('should click the focused radio button, when onKeyUp is triggered and Enter key is pressed', () => {
    const event = {
      key: 'Enter',
      currentTarget: {
        children: [],
      },
      target: {
        click: () => {},
      },
    };
    const spy = spyOn(event.target, 'click');
    component.onKeyUp(event);
    expect(component.mode).toBe('READ');
  });

  it('should select the appropriate option, when onKeyUp is triggered and an alphabet key is pressed', () => {
    const event = {
      key: 'R',
      currentTarget: {
        children: [
          {
            innerText: 'Test',
          },
          {
            innerText: 'Radio Option',
            children: [
              {
                click: () => {},
              },
            ],
          },
        ],
      },
    };
    const spy = spyOn(event.currentTarget.children[1].children[0], 'click');
    component.onKeyUp(event);
    expect(spy).toHaveBeenCalled();
  });

  it('should reset the control, when onKeyUp is triggered, the control has a value and C key is pressed', () => {
    const spy = spyOn(component, 'resetControl');
    component.control = new UntypedFormControl('Opt 1');
    component.onKeyUp({
      key: 'C',
      currentTarget: {
        children: [
          {
            innerText: 'Test',
          },
          {
            innerText: 'Radio Option',
          },
        ],
      },
    });
    expect(spy).toHaveBeenCalled();
  });

  it('should focus on the button radio, when onClick is triggered', () => {
    component.buttonRadio = {
      focus: () => {},
    };
    const spy = spyOn(component.buttonRadio, 'focus');
    jasmine.clock().install();
    component.onClick();
    jasmine.clock().tick(300);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });
});
