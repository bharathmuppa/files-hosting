import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DividerComponent } from './divider.component';
import { Component, Input } from '@angular/core';

@Component({
  selector: 'test-divider-wrapper',
  template: `
    <aal-divider [vertical]="vertical" [inset]="inset"></aal-divider>
  `,
  standalone: true,
  imports: [DividerComponent],
})
class DividerWrapperComponent {
  @Input() vertical = false;
  @Input() inset = false;
}

describe('DividerComponent', () => {
  let wrapper: DividerWrapperComponent;
  let fixture: ComponentFixture<DividerWrapperComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DividerWrapperComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(DividerWrapperComponent);
    wrapper = fixture.componentInstance;
    fixture.detectChanges();
  });

  /**
   * Basic test to ensure the wrapper component and DividerComponent
   * are created successfully.
   */
  it('should create the wrapper and DividerComponent', () => {
    expect(wrapper).toBeTruthy();
    const divider = fixture.debugElement.query(By.directive(DividerComponent));
    expect(divider).toBeTruthy();
  });

  /**
   * Test to verify the DividerComponent defaults to horizontal orientation.
   * Uses the wrapper's `vertical` input to check the default behavior.
   */
  it('should default to horizontal orientation', () => {
    expect(wrapper.vertical).toBe(false);
    const matDivider = fixture.debugElement.query(By.css('mat-divider'));
    expect(matDivider.attributes['ng-reflect-vertical']).toBe('false');
  });

  /**
   * Test to confirm vertical orientation is applied when `vertical` is set to true.
   * Updates the wrapper's `vertical` input to verify the DividerComponent responds correctly.
   */
  it('should apply vertical orientation when `vertical` is true', () => {
    wrapper.vertical = true;
    fixture.detectChanges();

    const matDivider = fixture.debugElement.query(By.css('mat-divider'));
    expect(matDivider.attributes['ng-reflect-vertical']).toBe('true');
  });

  /**
   * Test to verify that the DividerComponent does not have an inset by default.
   * Uses the wrapper's `inset` input to check the default behavior.
   */
  it('should not have inset by default', () => {
    expect(wrapper.inset).toBe(false);
    const matDivider = fixture.debugElement.query(By.css('mat-divider'));
    expect(matDivider.attributes['ng-reflect-inset']).toBe('false');
  });

  /**
   * Test to confirm the DividerComponent applies inset when `inset` is set to true.
   * Updates the wrapper's `inset` input and verifies the DividerComponent reflects the change.
   */
  it('should apply inset when `inset` is true', () => {
    wrapper.inset = true;
    fixture.detectChanges();

    const matDivider = fixture.debugElement.query(By.css('mat-divider'));
    expect(matDivider.attributes['ng-reflect-inset']).toBe('true');
  });

  /**
   * Test to verify horizontal styling by default.
   * Checks the DividerComponent's styles to confirm it is rendered as a horizontal divider.
   */
  it('should render with horizontal styling by default', () => {
    const matDivider = fixture.debugElement.query(By.css('mat-divider'));
    const borderTopStyle = getComputedStyle(matDivider.nativeElement).borderTopStyle;
    expect(borderTopStyle).not.toBe('none'); // border-top should be applied for horizontal divider
  });

  /**
   * Test to verify vertical styling is applied when the `vertical` input is true.
   * Confirms that the DividerComponent is rendered as a vertical divider with correct styles.
   */
  it('should render with vertical styling when `vertical` is true', () => {
    wrapper.vertical = true;
    fixture.detectChanges();

    const matDivider = fixture.debugElement.query(By.css('mat-divider'));
    expect(matDivider.styles['height']).toBe('100%');
    expect(matDivider.styles['width']).toBeFalsy(); // width should not be set for vertical dividers
  });
});
