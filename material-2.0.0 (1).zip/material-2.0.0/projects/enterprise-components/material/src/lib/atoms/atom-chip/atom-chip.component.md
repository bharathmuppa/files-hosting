
# ADR: AtomChipComponent

## Status
- **Proposed**: [2024-11-05]
- **Accepted**: [Pending Approval]

## Context and Problem Statement
The `AtomChipComponent` is designed to represent a customizable and versatile UI component for displaying individual "chip" elements within an Angular application. Chips are used to represent tags, entities, or other interactive elements within a user interface. This component should support:
- Display of avatar images or initials when available.
- Truncated text labels when exceeding the maximum character limit.
- Removable functionality when specified.
- Theme-based color variations for different chip states (e.g., `in-progress`, `rejected`, `done`).

This ADR explores the design and implementation choices for this component.

## Decision
We will implement the `AtomChipComponent` as a standalone, reusable Angular component that leverages Angular Material's `mat-chip` and is configurable for various states and avatar types. This decision is driven by the need for a flexible, accessible, and consistent chip component that aligns with the application's overall design and interaction patterns.

### Key Features
1. **Avatar Support**:
  - Supports an image, initials, or default icon as an avatar.
  - Avatar size can be configured (currently fixed at 24px for this implementation).

2. **Text Truncation**:
  - Truncates the label text after 32 characters, appending ellipses if exceeded.
  - Provides a utility function `truncate()` to handle this within the component.

3. **Removable Chip**:
  - Includes a removable button that, when clicked, emits an event for parent components to handle removal.
  - The button includes an `aria-label` for accessibility.

4. **Color Variations**:
  - Uses Angular Material’s `ngClass` to dynamically apply theme-based color classes (`in-progress`, `rejected`, `done`, `default`) to support different chip states.
  - CSS styling ensures a consistent UI based on predefined color tokens or palettes.

5. **Custom Styling**:
  - The component includes custom styling to meet specific UI requirements, including unique color variations, typography, and alignment for avatar and text elements.
  - **Note**: Given the custom styles implemented, this component should be reviewed with each UI library update or design change to ensure continued alignment with the application's overall style guide.

## Alternatives Considered
1. **Standard `@Input` Decorators**:
  - Using the standard `@Input()` approach was considered but ultimately chosen for signal-based `input()` functions to stay aligned with Angular's latest reactive approach.

2. **Custom Avatar Component**:
  - Creating a custom avatar component was considered but avoided to leverage existing Angular Material components and the `aal-avatar` wrapper, ensuring consistency and reducing redundant code.

## Implications
1. **Maintainability**: The `AtomChipComponent` is built to be a standalone and encapsulated component, which aids in reusability and simplifies future modifications.
2. **Performance**: By using `ChangeDetectionStrategy.OnPush`, the component is optimized for performance, reducing unnecessary change detection cycles.
3. **Accessibility**: The design prioritizes accessibility, including the use of `aria-label` attributes on the removal button and structured fallback options for the avatar display.
4. **Custom Style Tracking**: Custom styles should be regularly reviewed and updated with each design change or Angular Material update to ensure they remain compatible and consistent.

## Risks and Mitigations
- **Risk**: Custom styles may become incompatible with future Angular Material or application design updates.
  - **Mitigation**: Keep a changelog for this component and review styles during each UI library update to address any required adjustments.

## Conclusion
The decision to implement `AtomChipComponent` as described provides a flexible, accessible, and performant UI component that aligns with the application’s requirements. Custom styles support long-term maintainability and reusability while ensuring design consistency.

