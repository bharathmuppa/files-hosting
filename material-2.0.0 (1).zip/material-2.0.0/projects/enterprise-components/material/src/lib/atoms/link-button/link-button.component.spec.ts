import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Component } from '@angular/core';
import { LinkButtonComponent } from './link-button.component'; // Import the base component

describe('Link Button', () => {
  let component: LinkButtonWrapperComponent;
  let fixture: ComponentFixture<LinkButtonWrapperComponent>;
  let compiled: HTMLElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LinkButtonWrapperComponent], // Include base component
    }).compileComponents();

    fixture = TestBed.createComponent(LinkButtonWrapperComponent);
    component = fixture.componentInstance;
    compiled = fixture.nativeElement;
  });

  it('should create the wrapper component', () => {
    expect(component).toBeTruthy();
  });

  it('should render the hyperlink with default values', () => {
    fixture.detectChanges();

    const anchor = compiled.querySelector('a');
    expect(anchor).toBeTruthy();
    expect(anchor?.getAttribute('href')).toBe('https://google.com');
    expect(anchor?.textContent).toBe('Default Label');
  });

  it('should pass URL and label inputs to the base hyperlink component', () => {
    component.link = 'https://example.com';
    component.label = 'Example Link';
    fixture.detectChanges();

    const anchor = compiled.querySelector('a');
    expect(anchor).toBeTruthy();
    expect(anchor?.getAttribute('href')).toBe('https://example.com');
    expect(anchor?.textContent).toBe('Example Link');
  });

  it('should reflect changes in inputs dynamically', () => {
    component.link = 'https://new-url.com';
    component.label = 'New Label';
    fixture.detectChanges();

    const anchor = compiled.querySelector('a');
    expect(anchor).toBeTruthy();
    expect(anchor?.getAttribute('href')).toBe('https://new-url.com');
    expect(anchor?.textContent).toBe('New Label');
  });
});

@Component({
  selector: 'app-hyperlink-wrapper',
  standalone: true,
  imports: [LinkButtonComponent],
  template: ` <aal-link-button [link]="link" [label]="label" [target]="target"></aal-link-button> `,
  styles: [],
})
export class LinkButtonWrapperComponent {
  link = 'https://google.com';
  label = 'Default Label';
  target = '_blank';
}
