import { Directive, InjectionToken } from '@angular/core';
import { MatTooltip, MatTooltipDefaultOptions } from '@angular/material/tooltip';

export const AAL_TOOLTIP_DEFAULT_OPTIONS = new InjectionToken<MatTooltipDefaultOptions>(
  'aal-tooltip-default-options',
  {
    providedIn: 'root',
    factory: () => ({
      showDelay: 500,
      hideDelay: 100,
      touchendHideDelay: 1500,
    }),
  },
);

@Directive({
  selector: '[aalTooltip]',
  standalone: true,
})
export class TooltipDirective extends MatTooltip {}
