# ADR: MultiLineText Component

**Status:** Accepted  
**Date:** 18-12-2024  
**Decision Owner:** Frontend Development Team

---

## Context and Problem Statement

In our Angular application, there is a recurring need to display read-only multi-line text content that can dynamically adjust its visibility based on the content's length. Specifically, we require a component that:

- **Displays Text Content:** Shows rich text content in a read-only format.
- **Handles Overflow:** Limits the visible text to a specified height and provides "Show More"/"Show Less" functionality to expand or collapse the content.
- **Indicates Mandatory Fields:** Optionally displays an asterisk with a tooltip to denote mandatory fields.
- **Ensures Accessibility:** Supports keyboard navigation and includes appropriate ARIA attributes for assistive technologies.
- **Sanitizes HTML Content:** Safely renders HTML content to prevent Cross-Site Scripting (XSS) attacks.

Previously, this functionality was handled by the `RichTextareaReadonlyComponent`. However, to better reflect its purpose and enhance clarity within the codebase, the component has been renamed to `MultiLineTextComponent`. This decision aims to improve the semantic meaning of the component's name, making it more intuitive for developers and stakeholders.

---

## Decision

Adopt the `MultiLineTextComponent` as a standalone Angular component to encapsulate the functionality of displaying read-only multi-line text with optional "Show More"/"Show Less" functionality. This component will streamline the implementation process across the application, ensuring consistency, reusability, and adherence to best practices in accessibility and security.

---

### Key Considerations

- **Component Inputs:**
  - `showMore` (`boolean`): Enables or disables the "Show More"/"Show Less" functionality.
  - `showMoreAfterHeight` (`number`): Specifies the pixel height after which the toggle appears.
  - `isMandatory` (`boolean`): Indicates if the field is mandatory, displaying an asterisk if `true`.
  - `mandatoryToolTip` (`string`): Tooltip text for the mandatory indicator.
  - `label` (`string`): Label text for the text area.
  - `text` (`string`): HTML content to display within the text area.
  - `expand` (`boolean`): Sets the initial expansion state of the content.

- **Accessibility:**
  - Ensuring all interactive elements are focusable and operable via keyboard.
  - Using appropriate ARIA attributes (`aria-label`, `aria-expanded`, `aria-controls`) to enhance support for assistive technologies.

- **Security:**
  - Sanitizing HTML content using Angular's `DomSanitizer` to prevent XSS attacks.

- **Styling and Responsiveness:**
  - Utilizing Angular Flex Layout for responsive design.
  - Ensuring the component adapts gracefully to different screen sizes and content lengths.

- **Change Detection:**
  - Implementing `ChangeDetectionStrategy.OnPush` to optimize performance by reducing unnecessary change detections.

---

## Alternatives Considered

1. **Continuing with `RichTextareaReadonlyComponent`:**
  - **Pros:**
    - Minimal immediate changes required.
    - Existing implementations remain unaffected.
  - **Cons:**
    - The name does not accurately reflect the component's functionality.
    - Potential confusion for new developers joining the team.

2. **Creating Separate Components for Different Use Cases:**
  - **Pros:**
    - Tailored components for specific scenarios.
    - Potentially simpler individual components.
  - **Cons:**
    - Increased maintenance overhead with multiple similar components.
    - Redundancy in codebase, leading to inconsistencies.

3. **Renaming to `MultiLineTextComponent`:**
  - **Pros:**
    - Clear and descriptive name aligning with the component's purpose.
    - Improved semantic understanding for developers and stakeholders.
    - Consolidates functionality into a single, reusable component.
  - **Cons:**
    - Requires updates to existing implementations and documentation.
    - Potential temporary confusion during the transition period.

---

## Rationale

Renaming the component to `MultiLineTextComponent` offers significant advantages in terms of clarity and semantic meaning. The new name accurately represents the component's functionality, making it easier for developers to understand its purpose at a glance. Consolidating the functionality into a single, well-named component enhances reusability and consistency across the application. Additionally, maintaining a single source of truth for this functionality reduces maintenance overhead and minimizes the risk of discrepancies between different components handling similar tasks.

---

## Consequences

- **Positive:**
  - **Improved Clarity:** The component's name now clearly indicates its purpose, aiding in better code readability and maintainability.
  - **Enhanced Reusability:** A standalone component can be easily reused across different parts of the application, promoting DRY (Don't Repeat Yourself) principles.
  - **Consistent Behavior:** Centralizing the functionality ensures uniform behavior and styling wherever the component is used.
  - **Better Accessibility:** Focused efforts on accessibility features improve the user experience for individuals relying on assistive technologies.

- **Negative:**
  - **Migration Effort:** Existing implementations using `RichTextareaReadonlyComponent` need to be updated to the new name, which may require additional development time.
  - **Potential Short-Term Confusion:** Team members familiar with the old component name might experience temporary confusion during the transition period.

---

## Implementation

1. **Component Renaming:**
  - **Rename Files:**
    - `rich-textarea-readonly.component.ts` ➔ `multi-line-text.component.ts`
    - `rich-textarea-readonly.component.html` ➔ `multi-line-text.component.html`
    - `rich-textarea-readonly.component.scss` ➔ `multi-line-text.component.scss`
  - **Update Component Decorator:**
    - Change `selector: 'aal-rich-textarea-readonly'` to `selector: 'aal-multi-line-text'`.
    - Update `templateUrl` and `styleUrls` paths accordingly.

2. **Code Refactoring:**
  - Ensure all references to `RichTextareaReadonlyComponent` in the codebase are updated to `MultiLineTextComponent`.
  - Update import statements in modules and other components.

3. **Documentation Update:**
  - Revise all documentation, including READMEs, inline comments, and Storybook stories, to reflect the new component name.
  - Update the generated Markdown documentation to align with the new name.

4. **Testing:**
  - Run existing unit and integration tests to ensure functionality remains intact after renaming.
  - Update test cases to reference `MultiLineTextComponent`.
  - Implement additional tests if necessary to cover new or renamed functionalities.

5. **Deployment:**
  - Merge changes into the main codebase following the team's deployment protocols.
  - Monitor for any issues arising from the renaming process.

6. **Communication:**
  - Inform all team members about the renaming to prevent confusion.
  - Update any internal documentation or wikis to reflect the change.

---

**Decision:**  
Adopt the `MultiLineTextComponent` as a standalone Angular component to effectively manage the display of read-only multi-line text with optional expandable functionality. This decision enhances code clarity, reusability, and maintains consistency across the application, while also ensuring accessibility and security best practices are upheld.

---
