import { HarnessLoader } from '@angular/cdk/testing';
import { TestbedHarnessEnvironment } from '@angular/cdk/testing/testbed';
import { signal } from '@angular/core';
import { ComponentFixture, fakeAsync, TestBed } from '@angular/core/testing';
import { MatProgressBarHarness } from '@angular/material/progress-bar/testing';
import { ProgressBarComponent } from './progress-bar.component';

describe('ProgressBarComponent', () => {
  let fixture: ComponentFixture<ProgressBarComponent>;
  let loader: HarnessLoader;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProgressBarComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ProgressBarComponent);
    fixture.detectChanges();
    loader = TestbedHarnessEnvironment.loader(fixture);
  });

  it('should render progress bar in default indeterminate mode', async () => {
    const progressBar = await loader.getHarness(MatProgressBarHarness);
    expect(await progressBar.getMode()).toBe('indeterminate');
  });

  it('should update the progress bar mode to buffer', async () => {
    fakeAsync(async () => {
      const progressBar = await loader.getHarness(MatProgressBarHarness);
      // Weird typescript type assignment to avoid type error
      // this is suggested as workaround for testing the input signals
      fixture.componentInstance.mode = signal(
        'buffer',
      ) as unknown as typeof fixture.componentInstance.mode;
      fixture.detectChanges();

      expect(await progressBar.getMode()).toBe('buffer');
    });
  });

  it('should update the progress bar mode to query', async () => {
    fakeAsync(async () => {
      const progressBar = await loader.getHarness(MatProgressBarHarness);
      // Weird typescript type assignment to avoid type error
      // this is suggested as workaround for testing the input signals
      fixture.componentInstance.mode = signal(
        'query',
      ) as unknown as typeof fixture.componentInstance.mode;
      fixture.detectChanges();

      expect(await progressBar.getMode()).toBe('query');
    });
  });

  it('should update the progress bar mode to indeterminate', async () => {
    fakeAsync(async () => {
      const progressBar = await loader.getHarness(MatProgressBarHarness);
      // Weird typescript type assignment to avoid type error
      // this is suggested as workaround for testing the input signals
      fixture.componentInstance.mode = signal(
        'indeterminate',
      ) as unknown as typeof fixture.componentInstance.mode;
      fixture.detectChanges();

      expect(await progressBar.getMode()).toBe('indeterminate');
    });
  });
});
