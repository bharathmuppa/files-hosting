import { NgModule } from '@angular/core';
import { ButtonRadioComponent } from './button-radio.component';

@NgModule({
  imports: [ButtonRadioComponent],
  exports: [ButtonRadioComponent],
})
export class ButtonRadioModule {}
