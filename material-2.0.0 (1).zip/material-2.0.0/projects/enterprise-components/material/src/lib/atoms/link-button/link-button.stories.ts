import { Meta, StoryObj } from '@storybook/angular';
import { LinkButtonComponent } from './link-button.component';

const meta: Meta<LinkButtonComponent> = {
  title: 'Enterprise Components/Atoms/LinkButton',
  component: LinkButtonComponent,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: 'Component is used to Show hyperlinks across application.',
      },
    },
  },
  argTypes: {},
};

export default meta;
type Story = StoryObj<LinkButtonComponent>;

export const GoToGoogleNewPage: Story = {
  args: {
    label: 'Navigate to Google',
    link: 'https://www.google.com',
    size: 'md',
  },
};

export const GoToGoogleSamePage: Story = {
  args: {
    label: 'Open Google in same page',
    link: 'https://www.google.com',
    target: '_self',
    size: 'md',
  },
};

export const LargeButton: Story = {
  args: {
    label: 'Open Google in same page',
    link: 'https://www.google.com',
    size: 'lg',
  },
};

export const MediumButton: Story = {
  args: {
    label: 'Open Google in same page',
    link: 'https://www.google.com',
    size: 'md',
  },
};
