import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  componentWrapperDecorator,
  type Meta,
  moduleMetadata,
  type StoryObj,
} from '@storybook/angular';
import { CheckboxAtomComponent } from './checkbox-atom.component';

const meta: Meta<CheckboxAtomComponent> = {
  title: 'Enterprise Components/Atoms/Checkbox Atom',
  component: CheckboxAtomComponent,
  decorators: [
    moduleMetadata({
      imports: [ReactiveFormsModule, FormsModule],
    }),
    componentWrapperDecorator((story) => `<div style="margin: 3em">${story}</div>`),
  ],
};

export default meta;

type Story = StoryObj<CheckboxAtomComponent>;

export const Default: Story = {};

export const Checked: Story = {
  args: {
    checked: true,
    label: "I'm checked",
  },
};

export const Disabled: Story = {
  args: {
    disabled: true,
  },
};

export const Indeterminate: Story = {
  args: {
    indeterminate: true,
  },
};

export const Label: Story = {
  args: {
    label: 'I am a checkbox',
  },
};

export const ModelBinding: Story = {
  render: (args) => {
    return {
      template: `

        <aal-checkbox-atom [(checked)]="value" [label]="label"></aal-checkbox-atom>

        <pre>value : {{value}}</pre>

      `,
      props: {
        ...args,
        value: true,
      },
    };
  },
  args: {
    label: 'I am a checkbox',
  },
};
