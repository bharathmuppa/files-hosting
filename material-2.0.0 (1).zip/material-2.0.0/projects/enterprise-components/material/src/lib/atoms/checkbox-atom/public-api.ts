/*
 * Public API Surface of material
 */

export * from './checkbox-atom.component';
export * from './checkbox-atom.module';
