import { CommonModule } from '@angular/common';
import { Component, computed, input } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { AALCommonModule } from '@enterprise-components/common';

export type AVATAR_SIZE = 'sm' | 'md' | 'lg';

@Component({
  selector: 'aal-avatar',
  standalone: true,
  imports: [CommonModule, MatIconModule, AALCommonModule],
  templateUrl: './avatar.component.html',
  styleUrl: './avatar.component.scss',
})
export class AvatarComponent {
  size = input<AVATAR_SIZE>('md');
  fullName = input<string>('');
  disabled = input<boolean>(false);
  image = input<string | null>(null);
  icon = input<string | null>('person');

  initials = computed(() =>
    this.fullName()
      ? this.fullName()
          .split(' ')
          .map((name) => name.charAt(0))
          .join('')
          .toUpperCase()
      : '',
  );
}
