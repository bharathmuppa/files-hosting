### ADR: SlideToggle Component

**Status:** Accepted  
**Date:** 2024-11-29  
**Decision Owner:** RGB Development Team

---

## Context and Problem Statement

The Slide Toggle component is required as a wrapper for Angular Material's `MatSlideToggle` to provide a reusable, consistent, and extendable on/off toggle for application settings and forms. This wrapper simplifies usage, integrates seamlessly with signals for reactive updates, and ensures accessibility and form control support across the application.

---

## Decision

The team has decided to create a `SlideToggleComponent` as a standalone wrapper around Angular Material's `MatSlideToggle`. This wrapper will use signal-based inputs to make it reactive and maintain compatibility with modern Angular standards.

Key features include:
1. **Inputs**:
  - `color`: Customizable toggle color (`primary`, `accent`, `warn`).
  - `checked`: Toggle state (on/off).
  - `disabled`: Disabled state.
  - `message`: Optional label text.
2. Signal-based inputs for reactivity and dynamic updates.
3. Default configurations for quick integration with customizable options for flexibility.

---

### Key Considerations

- The `SlideToggleComponent` must:
  - Be standalone for better tree-shaking and modularity.
  - Support signal-based inputs for modern reactive development.
  - Be compatible with Angular Material's `MatSlideToggleHarness` for testing.
  - Maintain accessibility and usability standards.

---

## Alternatives Considered

1. **Direct Use of `MatSlideToggle`**
  - **Pros:** No additional abstraction layer; full access to Material component.
  - **Cons:** Requires repetitive boilerplate for consistent behavior across the application.

2. **Custom Component Without Signals**
  - **Pros:** Simpler implementation.
  - **Cons:** Lacks modern reactive capabilities; less flexibility for dynamic updates.

---

## Rationale

The decision to implement the `SlideToggleComponent` as a wrapper around `MatSlideToggle` was based on:
- The need for consistent implementation and styling across the application.
- The ability to integrate with Angular's signal-based reactive features for dynamic updates.
- Simplified usage while retaining flexibility for customization.

---

## Consequences

- **Positive:**
  - Easy-to-use, consistent API for toggles across the application.
  - Modern reactive design with signal-based inputs.
  - Seamless integration with forms and accessibility support.

- **Negative:**
  - Slight overhead in maintaining an abstraction layer.
  - Testing requires specific workarounds for signal-based properties.

---

## Implementation

1. Create a standalone `SlideToggleComponent`:
  - Use `MatSlideToggle` for base functionality.
  - Accept `color`, `checked`, `disabled`, and `message` as signal-based inputs.
2. Write test cases using `MatSlideToggleHarness`:
  - Implement a workaround to reassign signals dynamically for testing.
  - Use `fakeAsync(async () => { ... })` to wrap test cases for proper handling of asynchronous operations.
3. Document the component API and usage guidelines.

Example usage:

```html
<aal-slide-toggle [checked]="isActive" [message]="'Toggle Setting'"></aal-slide-toggle>
```

Example in the component:

```typescript
isActive = signal<boolean>(false);
```

---

## Decision

The Slide Toggle component is a versatile and easy-to-use wrapper for `MatSlideToggle`, making it ideal for adding simple, aesthetically pleasing on/off switches to applications. With accessibility, form control support, and flexible options, it’s a practical addition to any settings panel or form interface.
