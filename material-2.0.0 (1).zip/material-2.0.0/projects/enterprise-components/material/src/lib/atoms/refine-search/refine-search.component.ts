import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  EventEmitter,
  input,
  model,
  Output,
  ViewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';

@Component({
  selector: 'aal-refine-search',
  standalone: true,
  imports: [MatFormFieldModule, MatInputModule, FormsModule, MatButtonModule, MatIconModule],
  templateUrl: './refine-search.component.html',
  styleUrls: ['./refine-search.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AALRefineSearchComponent {
  refineText = input<string>('Refine');
  searchText = model<string>();
  @Output() enter = new EventEmitter<string>();

  @ViewChild('searchInput') searchInput!: ElementRef<HTMLInputElement>;

  isActive = false;

  activateSearch() {
    this.isActive = true;
  }

  handleBlur() {
    if (!this.searchText()) {
      this.isActive = false;
    }
  }

  clearSearch() {
    this.searchText.set('');
    this.isActive = true;
    this.focusInput();
  }

  emitSearchText() {
    this.enter.emit(this.searchText());
  }

  focusInput() {
    this.searchInput.nativeElement.focus();
  }
}
