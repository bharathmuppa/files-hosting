import { signal } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { AvatarComponent } from './avatar.component';

describe('AvatarComponent', () => {
  let component: AvatarComponent;
  let fixture: ComponentFixture<AvatarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AvatarComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AvatarComponent);
    component = fixture.componentInstance;
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  describe('input properties', () => {
    it('should set default values for size, fullName, disabled, and image', () => {
      expect(component.size()).toBe('md');
      expect(component.fullName()).toBe('');
      expect(component.disabled()).toBe(false);
      expect(component.image()).toBeNull();
    });

    it('should display initials when fullName is set and image is null', () => {
      const fullName = signal('John Doe');
      component.fullName = fullName as unknown as typeof component.fullName;

      const image = signal(null);
      component.image = image as unknown as typeof component.image;

      fixture.detectChanges();

      const initialsElement = fixture.debugElement.query(By.css('.aal-avatar__initials'));
      expect(initialsElement.nativeElement.textContent).toBe('JD');
    });

    it('should display the image when image is provided', () => {
      const mockImageUrl = 'https://www.w3schools.com/howto/img_avatar.png';
      const image = signal(mockImageUrl);
      component.image = image as unknown as typeof component.image;
      fixture.detectChanges();

      const imageElement = fixture.debugElement.query(By.css('img'));
      expect(imageElement).toBeTruthy();
      expect(imageElement.nativeElement.src).toContain(mockImageUrl);
    });

    it('should display the icon when no image or initials are present', () => {
      const fullName = signal(null);
      component.fullName = fullName as unknown as typeof component.fullName;

      const image = signal(null);
      component.image = image as unknown as typeof component.image;

      fixture.detectChanges();

      const iconElement = fixture.debugElement.query(By.css('mat-icon'));
      expect(iconElement).toBeTruthy();
      expect(iconElement.nativeElement.textContent.trim()).toBe('person');
    });
  });

  describe('computed initials()', () => {
    it('should compute initials based on fullName', () => {
      const fullName = signal('John Doe');
      component.fullName = fullName as unknown as typeof component.fullName;
      fixture.detectChanges();

      expect(component.initials()).toBe('JD');
    });

    it('should return empty string if fullName is not provided', () => {
      const fullName = signal('');
      component.fullName = fullName as unknown as typeof component.fullName;
      fixture.detectChanges();

      expect(component.initials()).toBe('');
    });
  });

  describe('dynamic classes', () => {
    it('should apply size class based on size input', () => {
      const size = signal('lg');
      component.size = size as unknown as typeof component.size;

      fixture.detectChanges();

      const avatarElement = fixture.debugElement.query(By.css('.aal-avatar'));
      expect(avatarElement.nativeElement.classList).toContain('aal-avatar--lg');
    });

    it('should apply disabled class when disabled input is true', () => {
      const disabled = signal(true);
      component.disabled = disabled as unknown as typeof component.disabled;

      fixture.detectChanges();

      const avatarElement = fixture.debugElement.query(By.css('.aal-avatar'));
      expect(avatarElement.nativeElement.classList).toContain('aal-avatar--disabled');
    });

    it('should not apply disabled class when disabled input is false', () => {
      const disabled = signal(false);
      component.disabled = disabled as unknown as typeof component.disabled;

      fixture.detectChanges();

      const avatarElement = fixture.debugElement.query(By.css('.aal-avatar'));
      expect(avatarElement.nativeElement.classList).not.toContain('aal-avatar--disabled');
    });
  });
});
