# ADR: ButtonToggleGroup Component

**Status:** Proposed  
**Date:** [Insert Date]  
**Decision Owner:** [Frontend Team or Specific Individual]

---

## Context and Problem Statement

We need a reusable and customizable `ButtonToggleGroup` component for our Angular application that integrates seamlessly with Angular's Forms API, supports standalone usage, and provides flexibility for size and styling variations. The current approach requires creating individual toggle groups manually, leading to repetitive code and inconsistency in design and behavior across the application.

---

## Decision

We will implement a standalone `ButtonToggleGroup` component that acts as a wrapper around Angular Material's `MatButtonToggleGroup`. This component will:

1. Use Angular's signal-based inputs for reactivity.
2. Support integration with Angular's `ControlValueAccessor` for seamless use with `formControlName` and `formControl`.
3. Provide options for size customization (`small`, `medium`, `large`) via an `input` property.
4. Maintain a clean and consistent API for usage across different features.

---

### Key Considerations

1. **Integration with Angular Forms**:
  - Fully compliant with `ControlValueAccessor` for compatibility with `formControl` and `formControlName`.

2. **Reusability**:
  - Encapsulates logic and styling for toggle groups, reducing code duplication.

3. **Customizability**:
  - Supports size variations and multiple selection (`multiple` input).

4. **Performance**:
  - Uses Angular signals for optimized reactivity and change detection.

---

## Alternatives Considered

1. **Direct Use of `MatButtonToggleGroup`**
  - **Pros:**
    - No additional development effort.
    - Direct usage of Angular Material components.
  - **Cons:**
    - Lack of standardization in size and behavior across the application.
    - Requires repetitive implementation in multiple places.

2. **Creating a Wrapper Without `ControlValueAccessor`**
  - **Pros:**
    - Simpler implementation without the need for forms API integration.
  - **Cons:**
    - Not compatible with Angular forms, reducing flexibility and increasing manual wiring effort.

---

## Rationale

The chosen approach ensures the component is both reusable and flexible while integrating seamlessly with Angular forms. It standardizes behavior and design across the application, improving maintainability and reducing the risk of inconsistent implementations.

---

## Consequences

- **Positive:**
  - Streamlined toggle group implementation with a clean API.
  - Consistent styling and behavior across the application.
  - Reduced code duplication and maintenance overhead.
  - Enhanced developer experience with size options and easy integration.

- **Negative:**
  - Additional initial development effort.
  - Requires developers to use the new wrapper instead of `MatButtonToggleGroup` directly.

---

## Implementation

1. **Component Development**:
  - Create the `ButtonToggleGroup` component as a standalone Angular component.
  - Use Angular's `ControlValueAccessor` for form integration.
  - Provide `options`, `multiple`, and `size` as inputs.

---

**Decision:** Use a standalone `ButtonToggleGroup` component to standardize and simplify the implementation of toggle groups in the application.

---
