import { Meta, StoryObj } from '@storybook/angular';
import { AALButtonFabComponent } from './button-fab.component';

const meta: Meta<AALButtonFabComponent> = {
  title: 'Enterprise Components/Atoms/FAB Button',
  tags: ['autodocs'],
  component: AALButtonFabComponent,
  argTypes: {
    name: {
      control: 'text',
      type: 'string',
    },
    icon: {
      control: 'text',
      type: 'string',
    },
    size: {
      control: { type: 'radio' },
      options: ['sm', 'md'],
    },
  },
};

export default meta;
type Story = StoryObj<AALButtonFabComponent>;

// Contained Button Story
export const Default: Story = {
  name: 'FAB Button with Text (Default)',
  args: {
    name: 'FAB Button with Text',
  },
};

// Contained Button with Icon Story
export const ContainedWithIconButton: Story = {
  name: 'FAB Button with Icon',
  args: {
    icon: 'edit',
  },
};
