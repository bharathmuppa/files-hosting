import { NgClass } from '@angular/common';
import { ChangeDetectionStrategy, Component, EventEmitter, input, Output } from '@angular/core';
import { MatChipsModule } from '@angular/material/chips';
import { MatIcon } from '@angular/material/icon';
import { AvatarComponent } from '../avatar/avatar.component';

/**
 * Component representing a customizable chip with optional avatar and label.
 *
 * The `AtomChipComponent` supports truncation for labels exceeding a specified character limit,
 * displays avatars with images or initials, and includes a removable option.
 */
@Component({
  selector: 'aal-atom-chip',
  standalone: true,
  imports: [MatChipsModule, AvatarComponent, MatIcon, NgClass],
  templateUrl: './atom-chip.component.html',
  styleUrls: ['./atom-chip.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AtomChipComponent {
  /**
   * The text label for the chip.
   */
  label = input<string>('');

  /**
   * Determines if the chip can be removed.
   */
  removable = input<boolean>(false);

  /**
   * Size of the Chip.
   */
  size = input<'md' | 'sm'>('md');
  /**
   * Alternative avatar with an image URL, displayed if provided.
   */
  avatarWithImage = input<string | null>();

  /**
   * Alternative avatar with initials, displayed if `avatarWithImage` is not provided.
   */
  avatarWithInitials = input<string>();

  /**
   * Alternative avatar with icon, displayed  if image and initials not provided.
   */
  avatarWithIcon = input<string>();

  /**
   * Optional data payload associated with the chip.
   */
  data = input<any>();

  /**
   * Maximum characters for the label before truncation. Default is 32.
   */
  maxCharacters = input<number>(32);

  /**
   * Color variant of the chip. Possible values are `in-progress`, `rejected`, `done`, or `default`.
   */
  color = input<'in-progress' | 'rejected' | 'done' | 'default'>('default');

  /**
   * Event emitted when the chip is removed.
   */
  @Output()
  removed: EventEmitter<any> = new EventEmitter<any>();

  /**
   * Handles chip removal by emitting the `removed` event with associated data.
   */
  onRemove() {
    this.removed.emit(this.data());
  }

  /**
   * Truncates a given string if it exceeds the specified max characters.
   * @param value The string to truncate.
   * @param maxCharacters Maximum allowed characters before truncation.
   * @returns Truncated string with ellipsis if exceeded.
   */
  truncate(value: string, maxCharacters: number): string {
    return value.length > maxCharacters ? value.substring(0, maxCharacters) + '...' : value;
  }
}
