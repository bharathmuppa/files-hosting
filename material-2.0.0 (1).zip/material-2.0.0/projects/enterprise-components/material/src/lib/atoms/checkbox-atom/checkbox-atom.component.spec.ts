import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CheckboxAtomComponent } from './checkbox-atom.component';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { DebugElement, signal } from '@angular/core';

describe('CheckboxAtomComponent', () => {
  let component: CheckboxAtomComponent;
  let fixture: ComponentFixture<CheckboxAtomComponent>;
  let checkboxDebugElement: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CheckboxAtomComponent, MatCheckboxModule, FormsModule],
    }).compileComponents();

    fixture = TestBed.createComponent(CheckboxAtomComponent);
    component = fixture.componentInstance;
    checkboxDebugElement = fixture.debugElement.query(By.css('mat-checkbox'));
    fixture.detectChanges();
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should have default values', () => {
    expect(component.checked()).toBe(false);
    expect(component.indeterminate()).toBe(false);
    expect(component.disabled()).toBe(false);
  });

  it('should display the label text', () => {
    const label = signal('Test Label');
    component.label = label as unknown as typeof component.label;
    fixture.detectChanges();

    const checkboxElement = checkboxDebugElement.nativeElement as HTMLElement;
    expect(checkboxElement.textContent).toContain('Test Label');
  });
  it('should toggle checked state when clicked', () => {
    // Set initial checked state to false
    component.checked.set(false);
    fixture.detectChanges();

    // Simulate clicking to change state to true
    const checkboxElement = checkboxDebugElement.nativeElement.querySelector(
      'input',
    ) as HTMLInputElement;
    checkboxElement.click();
    fixture.detectChanges();

    expect(component.checked()).toBe(true);

    // Simulate clicking again to change state to false
    checkboxElement.click();
    fixture.detectChanges();

    expect(component.checked()).toBe(false);
  });

  it('should display indeterminate state', () => {
    // Set the component's indeterminate state to true
    component.indeterminate.set(true);
    fixture.detectChanges();

    // Find the input element within the mat-checkbox
    const checkboxInput = checkboxDebugElement.nativeElement.querySelector(
      'input',
    ) as HTMLInputElement;

    // Check that the indeterminate property on the input is true
    expect(checkboxInput.indeterminate).toBe(true);

    // Set the indeterminate state to false and check again
    component.indeterminate.set(false);
    fixture.detectChanges();

    expect(checkboxInput.indeterminate).toBe(false);
  });

  it('should disable the checkbox when disabled is true', () => {
    component.disabled.set(true);
    fixture.detectChanges();

    expect(checkboxDebugElement.attributes['ng-reflect-disabled']).toBe('true');
  });
});
