import { argsToTemplate, Meta } from '@storybook/angular';
import { ProgressBarComponent } from './progress-bar.component';

export default {
  title: 'Enterprise Components/Atoms/Loading Indicator',
  component: ProgressBarComponent,
  parameters: {
    docs: {
      description: {
        component: 'A ProgressBar component that displays a progress bar.',
      },
    },
  },
} as Meta<ProgressBarComponent>;

export const Default = {};

export const InsideContainer = {
  args: {
    mode: 'indeterminate',
  },
  parameters: {
    docs: {
      description: {
        story: 'Displays a indeterminate progress bar inside a container of width 200px.',
      },
    },
  },
  render: (args) => ({
    template: `
      <div style="height: 100px; width: 200px; display: flex; align-items: center; justify-content: center; border: 1px solid gray; padding:1rem;">
        <aal-progress-bar  ${argsToTemplate(args)}></aal-progress-bar>
      </div>`,
    props: args,
  }),
};

export const QueryProgressBar = {
  args: {
    mode: 'query',
  },
  parameters: {
    docs: {
      description: {
        story: 'Displays a progress bar with query mode',
      },
    },
  },
};

export const BufferProgressBar = {
  args: {
    mode: 'buffer',
  },
  parameters: {
    docs: {
      description: {
        story: 'Displays a progress bar in buffer mode',
      },
    },
  },
};
