### ADR: Lading Indicator Component

**Title:** Simple Wrapper for Angular Material Progress Bar  
**Date:** 2024-11-29

---

### **Context**

The `ProgressBarComponent` is created as a simple wrapper for the Angular Material Progress Bar (`MatProgressBar`). The purpose of this wrapper is to encapsulate the functionality of the Angular Material Progress Bar while allowing customization and extending its use case in a consistent manner across the application.

This wrapper provides the following benefits:

1. Encapsulation of Material components to allow future changes without modifying all usages.
2. Ensures consistent application-wide usage of progress bars.
3. Allows additional functionality to be added easily if required in the future.

---

### **Decision**

A simple wrapper component named `ProgressBarComponent` is implemented. This wrapper:

- Supports `mode` as a signal-based `Input`.
- Uses Angular Material's `MatProgressBar` under the hood.
- Provides a clean and reusable interface for developers.

---

### **Consequences**

- **Positive**: Developers can use a simplified and consistent API to implement progress bars.
- **Negative**: Currently, it does not add any additional functionality beyond what `MatProgressBar` offers.

---

### **Usage**

Below are examples of how to use the `ProgressBarComponent` in an Angular project.

#### 1. **Basic Usage**

In your Angular template:

```html

<aal-progress-bar [mode]="progressMode"></aal-progress-bar>
```

In your component:

```typescript
import { Component, signal } from '@angular/core';

@Component({
  selector: 'app-example',
  template: `<aal-progress-bar [mode]="progressMode"></aal-progress-bar>`,
})
export class ExampleComponent {
  progressMode = signal<'indeterminate' | 'buffer' | 'query'>('indeterminate');
}
```

#### 2. **Changing the Mode Dynamically**

```typescript
import { Component, signal } from '@angular/core';

@Component({
  selector: 'app-dynamic-progress',
  template: `
    <aal-progress-bar [mode]="progressMode"></aal-progress-bar>
    <button (click)="switchToBuffer()">Switch to Buffer</button>
  `,
})
export class DynamicProgressComponent {
  progressMode = signal<'indeterminate' | 'buffer' | 'query'>('indeterminate');

  switchToBuffer() {
    this.progressMode.set('buffer');
  }
}
```

---

---

### **Status**

This ADR is accepted and implemented. Future iterations may include additional features like theming or custom indicators.
