import { BooleanInput } from '@angular/cdk/coercion';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, input, InputSignal, OnInit } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'aal-button-fab',
  standalone: true,
  imports: [CommonModule, MatButtonModule, MatIconModule],
  templateUrl: './button-fab.component.html',
  styleUrls: ['./button-fab.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AALButtonFabComponent implements OnInit {
  name: InputSignal<string> = input<string>('');
  icon: InputSignal<string> = input<string>('');
  size: InputSignal<'sm' | 'md'> = input<'sm' | 'md'>('md');
  disabled: InputSignal<BooleanInput> = input<BooleanInput>(false);

  classes: { [key: string]: boolean };

  ngOnInit() {
    this.classes = {
      'icon-only': this.icon() && !this.name(),
      [this.size()]: true,
    };
  }
}
