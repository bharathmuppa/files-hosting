import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
  componentWrapperDecorator,
  moduleMetadata,
  type Meta,
  type StoryObj,
} from '@storybook/angular';
import { AALRefineSearchComponent } from './refine-search.component';

const meta: Meta<AALRefineSearchComponent> = {
  title: 'Enterprise Components/Molecules/Refine Search',
  component: AALRefineSearchComponent,
  decorators: [
    moduleMetadata({
      imports: [
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatIconModule,
        FormsModule,
        BrowserAnimationsModule,
      ],
    }),
    componentWrapperDecorator((story) => `<div style="margin: 17.75rem">${story}</div>`),
  ],
};

export default meta;
type Story = StoryObj<AALRefineSearchComponent>;

export const Default: Story = {
  args: {
    isActive: false,
  },
};

export const ActiveStateWithPreText: Story = {
  args: {
    isActive: true,
    searchText: 'Example Query',
  },
};
