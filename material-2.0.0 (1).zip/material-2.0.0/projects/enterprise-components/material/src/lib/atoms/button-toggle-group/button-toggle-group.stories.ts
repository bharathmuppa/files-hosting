import { JsonPipe } from '@angular/common';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule, provideAnimations } from '@angular/platform-browser/animations';
import { applicationConfig, Meta, moduleMetadata, StoryObj } from '@storybook/angular';
import { IconComponent } from '../icon/icon.component';
import { ButtonToggleGroupComponent } from './button-toggle-group.component';

const meta: Meta = {
  title: 'Enterprise Components/Atoms/Button Toggle Group',
  decorators: [
    moduleMetadata({
      imports: [
        ButtonToggleGroupComponent,
        ReactiveFormsModule,
        IconComponent,
        JsonPipe,
        BrowserAnimationsModule,
      ],
    }),
    applicationConfig({
      providers: [provideAnimations()],
    }),
  ],
  parameters: {
    docs: {
      description: {
        component:
          'The Button Toggle Group component allows single or multiple selections with customizable options.',
      },
    },
  },
  argTypes: {
    options: {
      control: { type: 'object' },
      description:
        'The options for the button toggle group. Each option can include a label, value, and icon.',
    },
    multiple: {
      control: 'boolean',
      description: 'Allows multiple selection if true.',
    },
    size: {
      control: { type: 'select' },
      options: ['md', 'lg'],
      description: 'Specifies the size of the button toggle buttons.',
    },
    useThisKeyToDisplay: {
      control: 'text',
      description:
        'If options is an array of objects, this key will be used as the display value for the button toggle buttons.',
    },
    useThisKeyAsValue: {
      control: 'text',
      description:
        'If options is an array of objects, this key will be used as the value for the button toggle buttons.',
    },
  },
};

export default meta;

type Story = StoryObj;

export const SingleSelection: Story = {
  args: {
    options: [
      { label: 'Very Satisfied', value: 'very_satisfied', icon: 'sentiment_very_satisfied' },
      { label: 'Satisfied', value: 'satisfied', icon: 'sentiment_satisfied' },
      { label: 'Neutral', value: 'neutral', icon: 'sentiment_neutral' },
    ],
    multiple: false,
    size: 'md',
  },
  parameters: {
    docs: {
      description: {
        story: 'Single selection mode for the button toggle group.',
      },
    },
  },
  render: (args) => {
    const control = new FormControl(null);
    return {
      template: `
         <ng-template #customTemplate let-option>
          <div style="display: flex; align-items: center; gap: 0.5rem;">
            <aal-icon [icon]="option.icon" [size]="'sm'"></aal-icon>
            <span style="font-size: 14px; letter-spacing:0.014px; line-height:16px;">{{ option.label }}</span>
          </div>
        </ng-template>
        <aal-button-toggle-group
          [options]="options"
          [multiple]="multiple"
          [formControl]="control"
          [buttonTemplate]="customTemplate"
          [size]="size">
        </aal-button-toggle-group>

        <p>Selected Value: {{ control.value | json }}</p>
      `,
      props: { ...args, control },
    };
  },
};

export const MultipleSelection: Story = {
  args: {
    options: [
      { label: 'Very Satisfied', value: 'very_satisfied', icon: 'sentiment_very_satisfied' },
      { label: 'Satisfied', value: 'satisfied', icon: 'sentiment_satisfied' },
      { label: 'Neutral', value: 'neutral', icon: 'sentiment_neutral' },
    ],
    multiple: true,
    size: 'md',
  },
  parameters: {
    docs: {
      description: {
        story: 'Multiple selection mode for the button toggle group.',
      },
    },
  },
  render: (args) => {
    const control = new FormControl(null);
    return {
      template: `
        <ng-template #customTemplate let-option>
          <div style="display: flex; align-items: center; gap: 0.5rem;">
            <aal-icon [icon]="option.icon" [size]="'sm'"></aal-icon>
            <span>{{ option.label }}</span>
          </div>
        </ng-template>
        <aal-button-toggle-group
          [options]="options"
          [multiple]="multiple"
          [formControl]="control"
          [buttonTemplate]="customTemplate"
          [size]="size">
        </aal-button-toggle-group>
        <p>Selected Value: {{ control.value | json }}</p>
      `,
      props: { ...args, control },
    };
  },
};

export const UseStringArray: Story = {
  args: {
    options: ['Very Satisfied', 'Satisfied', 'Neutral'],
    multiple: false,
    size: 'md',
  },
  parameters: {
    docs: {
      description: {
        story: 'Single selection mode for the button toggle group using a string array.',
      },
    },
  },
  render: (args) => {
    const control = new FormControl(null);
    return {
      template: `

        <aal-button-toggle-group
          [options]="options"
          [multiple]="multiple"
          [formControl]="control"
          [size]="size">
        </aal-button-toggle-group>
        <p>Selected Value: {{ control.value | json }}</p>
      `,
      props: { ...args, control },
    };
  },
};

export const UseObjectArrayWithKey: Story = {
  args: {
    options: [
      { label: 'Very Satisfied', value: 'very_satisfied', icon: 'sentiment_very_satisfied' },
      { label: 'Satisfied', value: 'satisfied', icon: 'sentiment_satisfied' },
      { label: 'Neutral', value: 'neutral', icon: 'sentiment_neutral' },
    ],
    multiple: false,
    size: 'md',
  },
  parameters: {
    docs: {
      description: {
        story:
          'Pass Array Object as options and pass any key of object as displayValue to render inside button toggle .',
      },
    },
  },
  render: (args) => {
    const control = new FormControl(null);
    return {
      template: `
        <aal-button-toggle-group
          [options]="options"
          [multiple]="multiple"
          [formControl]="control"
          [useThisKeyToDisplay]="'label'"
          [size]="size">
        </aal-button-toggle-group>
        <p>Selected Value: {{ control.value | json }}</p>
      `,
      props: { ...args, control },
    };
  },
};

export const UseObjectArrayWithCustomKey: Story = {
  args: {
    options: [
      { label: 'Very Satisfied', value: 'very_satisfied', icon: 'sentiment_very_satisfied' },
      { label: 'Satisfied', value: 'satisfied', icon: 'sentiment_satisfied' },
      { label: 'Neutral', value: 'neutral', icon: 'sentiment_neutral' },
    ],
    multiple: false,
    size: 'md',
  },
  parameters: {
    docs: {
      description: {
        story:
          'Pass Array Object as options and pass any key of object as displayValue to render inside button toggle .',
      },
    },
  },
  render: (args) => {
    const control = new FormControl(null);
    return {
      template: `
        <aal-button-toggle-group
          [options]="options"
          [multiple]="multiple"
          [formControl]="control"
          [useThisKeyToDisplay]="'label'"
          [useThisKeyAsValue]="'value'"
          [size]="size">
        </aal-button-toggle-group>
        <p>Selected Value: {{ control.value | json }}</p>
      `,
      props: { ...args, control },
    };
  },
};
