import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { TileButtonComponent } from './tile-button.component';

@Component({
  selector: 'aal-tile-button-wrapper',
  standalone: true,
  imports: [TileButtonComponent],
  template: `
    <aal-tile-button
      [icon]="icon"
      [title]="title"
      [message]="message"
      [color]="color"
      [(state)]="state"></aal-tile-button>
  `,
})
class TileButtonWrapperComponent {
  icon = 'notifications';
  title = 'Sample Title';
  message = 'Sample Message';
  color = 'primary';
  state = false;
}

describe('TileButtonComponent', () => {
  let wrapperFixture: ComponentFixture<TileButtonWrapperComponent>;
  let wrapperComponent: TileButtonWrapperComponent;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TileButtonWrapperComponent],
    }).compileComponents();

    wrapperFixture = TestBed.createComponent(TileButtonWrapperComponent);
    wrapperComponent = wrapperFixture.componentInstance;
    wrapperFixture.detectChanges();
  });

  it('should create the wrapper component', () => {
    expect(wrapperComponent).toBeTruthy();
  });

  it('should display the correct icon', () => {
    const iconElement = wrapperFixture.debugElement.query(By.css('aal-icon'));
    expect(iconElement.attributes['ng-reflect-icon']).toBe('notifications');
  });

  it('should display the correct title and message', () => {
    const titleElement = wrapperFixture.debugElement.query(By.css('.title-btn__title'));
    const messageElement = wrapperFixture.debugElement.query(By.css('.title-btn__message'));

    expect(titleElement.nativeElement.textContent).toBe('Sample Title');
    expect(messageElement.nativeElement.textContent).toBe('Sample Message');
  });

  it('should toggle the state when clicked', () => {
    const tileElement = wrapperFixture.debugElement.query(By.css('.title-btn'));

    expect(wrapperComponent.state).toBe(false);

    tileElement.nativeElement.click();
    wrapperFixture.detectChanges();

    expect(wrapperComponent.state).toBe(true);

    tileElement.nativeElement.click();
    wrapperFixture.detectChanges();

    expect(wrapperComponent.state).toBe(false);
  });

  it('should apply the "selected" class when state is true', () => {
    wrapperComponent.state = true;
    wrapperFixture.detectChanges();

    const tileElement = wrapperFixture.debugElement.query(By.css('.title-btn'));
    expect(tileElement.classes['selected']).toBeTruthy();
  });
});
