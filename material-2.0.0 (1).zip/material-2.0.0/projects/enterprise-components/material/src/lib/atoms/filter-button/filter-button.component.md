# ADR:  `FilterButtonComponent` 

**Status:** Approved  
**Date:** November 27, 2024  
**Decision Owner:** RGB Dev Team

---

## Context and Problem Statement

We are building a reusable `FilterButtonComponent` as part of our Angular component library. This component integrates functionality such as a button-like UI with optional checkbox selection, customizable icons (Material or SVG), flexible layouts, and theming.


## Decision

We will implement the `FilterButtonComponent` using **input mappings** combined with **Angular Signals** for dynamic reactivity. Instead of tightly coupling with Angular Material or extending existing components, we will expose inputs and outputs that allow full customization. This approach provides flexibility while maintaining independence from Angular Material’s internal implementations.

### Key Inputs

- **`checkbox`**: BooleanInput (optional) to enable/disable checkbox functionality.
- **`layout`**: Defines the component's layout orientation (`'col' | 'row'`).
- **`size`**: Determines size variants (`'sm' | 'md' | 'lg'`).
- **`icon`**: Specifies a Material icon name.
- **`svg`**: Specifies an SVG path or name for custom icons.
- **`label`**: Displays a text label.
- **`count`**: Shows a numerical badge or count.

### Outputs

- **`change`**: Emits events when the checkbox is toggled.

## Alternatives Considered

1. **Extend Angular Material Components**
  - **Pros**: Reuse Angular Material’s rich feature set and styling out of the box.
  - **Cons**: Styling and behavior issues due to inheritance complexities. Dependence on Angular Material versions and themes.

2. **Input Mapping with Signals (Selected)**
  - **Pros**: Clean separation of concerns, independent of Angular Material’s internal changes. Fully customizable, with modern Angular reactivity features.
  - **Cons**: Slightly higher initial implementation effort.

3. **Composition Using Angular Material Components**
  - **Pros**: Allows using Angular Material components internally for behavior and theming.
  - **Cons**: Indirect coupling with Angular Material still exists. Less reusable outside Material-based projects.

## Rationale

The selected approach, input mapping combined with Angular Signals, aligns with the modern Angular paradigm while ensuring component independence and flexibility. By exposing configurable inputs and outputs, the `FilterButtonComponent` can function as a standalone UI component compatible with custom themes and layouts, providing consistent behavior across versions and libraries.

## Consequences

- **Positive**:
  - Fully independent of Angular Material for both functionality and styling.
  - Enables the use of modern Angular features like signals and standalone components.
  - Consistent customization options across applications.
  - Reduced maintenance overhead if Angular Material changes its API.

- **Negative**:
  - Initial implementation requires careful design of input mappings and SCSS for theming.
  - Maintenance required to support additional feature requests or property mappings.

## Implementation

1. **Inputs and Outputs**:
  - Define inputs for customizable properties like `checkbox`, `icon`, `svg`, etc., using Angular’s `input<T>()` for signals.
  - Expose an `output()` for emitting changes.

2. **Template**:
  - Design the template to support dynamic layouts, icons, and state management using input signals.
  - Include support for projected content (e.g., `ng-content` for additional sections).

3. **Styling**:
  - Develop SCSS to align with the library’s custom theme.
  - Ensure responsive and accessible design principles are applied.

4. **Testing**:
  - Create comprehensive unit tests to validate input mappings, dynamic layouts, and reactivity.

---

**Decision:** Develop the `FilterButtonComponent` with standalone inputs, signals, and flexible design.
