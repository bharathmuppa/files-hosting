import { NgClass } from '@angular/common';
import { ChangeDetectionStrategy, Component, input, model } from '@angular/core';
import { MatCheckbox } from '@angular/material/checkbox';
import { MatLabel } from '@angular/material/form-field';
import { IconComponent } from '../icon/icon.component';

@Component({
  selector: 'aal-tile-button',
  standalone: true,
  imports: [IconComponent, MatCheckbox, MatLabel, NgClass],
  templateUrl: './tile-button.component.html',
  styleUrl: './tile-button.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TileButtonComponent {
  /**
   * The name of the icon to display.
   */
  icon = input<string>('notifications');
  /**
   * The title of the tile button.
   */
  title = input.required<string>();
  /**
   * A description for the tile button.
   */
  message = input.required<string>();
  /**
   * state of the tile button. usually used for toggling the state.
   */
  state = model<Boolean>(false);

  /**
   * The color of the icon.
   */
  color = input<string>('primary');

  /**
   * Toggles the state of the tile button.
   */
  toggleTileState() {
    this.state.set(!this.state());
  }
}
