import { Component, DebugElement } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { OverlayModule } from '@angular/cdk/overlay';
import { MatTooltipModule } from '@angular/material/tooltip';
import { AAL_TOOLTIP_DEFAULT_OPTIONS, TooltipDirective } from './tooltip.directive';
import { MatButtonModule } from '@angular/material/button';

@Component({
  template: `
    <button aalTooltip="Test Tooltip" mat-button>Hover me</button>
  `,
  standalone: true,
  imports: [MatButtonModule, TooltipDirective],
})
class TooltipTestComponent {}

describe('TooltipDirective', () => {
  let fixture: ComponentFixture<TooltipTestComponent>;
  let buttonDebugElement: DebugElement;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [OverlayModule, MatTooltipModule, TooltipTestComponent],
      providers: [
        { provide: AAL_TOOLTIP_DEFAULT_OPTIONS, useValue: { showDelay: 500, hideDelay: 100 } },
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TooltipTestComponent);
    buttonDebugElement = fixture.debugElement.query(By.directive(TooltipDirective));
    fixture.detectChanges();
  });

  it('should create an instance of TooltipDirective', () => {
    expect(buttonDebugElement).toBeTruthy();
  });
});
