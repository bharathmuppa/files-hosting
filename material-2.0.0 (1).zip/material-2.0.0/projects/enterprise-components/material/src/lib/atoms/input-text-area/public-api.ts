/*
 * Public API Surface of material
 */

export * from './input-text-area.component';
export * from './input-text-area.module';
