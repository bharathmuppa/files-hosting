import { applicationConfig, type Meta, type StoryObj } from '@storybook/angular';
import { fn } from '@storybook/test';

import { InputTextAreaComponent } from './input-text-area.component';

import { importProvidersFrom } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Info, Modes } from '@enterprise-components/common';

const meta: Meta<InputTextAreaComponent> = {
  title: 'Enterprise Components/Atoms/Text Area',
  component: InputTextAreaComponent,
  tags: ['autodocs'],
  decorators: [
    applicationConfig({
      providers: [importProvidersFrom(BrowserAnimationsModule)],
    }),
  ],
};

export default meta;
type Story = StoryObj<InputTextAreaComponent>;

const errorTitle = 'Error Title';
const errorMessage =
  'This is error message with <a target="_blank" href="https://www.google.com">link </a>';
const errorAnimation = 'https://media.giphy.com/media/1BcfGzv2jCvRl2E4yo/giphy.gif';
const errorThumbnail = 'https://upload.wikimedia.org/wikipedia/en/6/6c/ec_Holding_N.V._logo.svg';
const errorLevel = 'ERROR';
const errorAlert = new Info(errorTitle, errorMessage, errorAnimation, errorThumbnail, errorLevel);

// <!-- Storybook:DONE input-text-area.stories.ts Variant1-->
export const Variant1: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    alert: errorAlert,
    mode: Modes.EDIT,
    lockMode: Modes.EDIT,
    pressAcceptEvent: fn(),
    pressRejectEvent: fn(),
  },
  render: (args) => {
    const fb = new UntypedFormBuilder();
    const control = fb.control('', [Validators.required, Validators.maxLength(256)]);
    return {
      props: {
        ...args,
        control,
      },
      template: `
      <aal-input-text-area
        (acceptChanges)="acceptChanges($event)"
        (rejectChanges)="rejectChanges($event)"
        (pressAcceptEvent)="pressAcceptEvent($event)"
        (pressRejectEvent)="pressRejectEvent($event)"
        [ID]="'InputTextBox'"
        [control]="control"
        [alert]="alert"
        [label]="'input-text-area Always edit mode field'"
        [showHyphenForValues]="[null]"
        [help]=""
        [isBusy]="false"
        [isHistoryEnabled]="false"
        [mode]="mode"
        [lockMode]="lockMode"
        [showLengthHint]="true"
        [maxLength]="256"
        [compositePlaceholder]="'Enter text'"
        [placeholder]="'Enter text'"
        [alwaysEditMode]="true"
        [confirmToolBarNotApplicable]="true">
      </aal-input-text-area>
      `,
    };
  },
};

// <!-- Storybook:DONE input-text-area.stories.ts Variant2-->
export const Variant2: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    alert: errorAlert,
    mode: Modes.READ,
    pressAcceptEvent: fn(),
    pressRejectEvent: fn(),
  },
  render: (args) => {
    const fb = new UntypedFormBuilder();
    const control = fb.control('', [Validators.required, Validators.maxLength(100)]);
    return {
      props: {
        ...args,
        control,
      },
      template: `
      <aal-input-text-area
        (acceptChanges)="acceptChanges($event)"
        (rejectChanges)="rejectChanges($event)"
        (pressAcceptEvent)="pressAcceptEvent($event)"
        (pressRejectEvent)="pressRejectEvent($event)"
        [ID]="'InputTextBox'"
        [control]="control"
        [alert]="alert"
        [label]="'Some Label 1'"
        [showHyphenForValues]="[null]"
        [help]=""
        [isBusy]="false"
        [isHistoryEnabled]="false"
        [mode]="mode"
        [showLengthHint]="true"
        [maxLength]="100"
        [compositePlaceholder]="'Enter number'"
        [placeholder]="'number'">
      </aal-input-text-area>
      `,
    };
  },
};

export const PlainTextArea: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    mode: Modes.READ,
    pressAcceptEvent: fn(),
    pressRejectEvent: fn(),
    label: 'Plain Text Area',
    lockMode: Modes.READ,
    showHyphenForValues: [null, ''],
    ID: 'PlainTextArea',
    confirmToolBarNotApplicable: true,
    isBusy: false,
    isHistoryEnabled: false,
    showLengthHint: true,
    maxLength: 100,
  },
  render: (args) => {
    const fb = new UntypedFormBuilder();
    const control = fb.control('', [Validators.required, Validators.maxLength(args.maxLength)]);
    return {
      props: {
        ...args,
        control,
      },
      template: `
      <aal-input-text-area
        (acceptChanges)="acceptChanges($event)"
        (rejectChanges)="rejectChanges($event)"
        (pressAcceptEvent)="pressAcceptEvent($event)"
        (pressRejectEvent)="pressRejectEvent($event)"
        [ID]="ID"
        [control]="control"
        [label]="label"
        [showHyphenForValues]="showHyphenForValues"
        [isBusy]="isBusy"
        [isHistoryEnabled]="isHistoryEnabled"
        [mode]="mode"
        [showLengthHint]="showLengthHint"
        [maxLength]="maxLength"
        [confirmToolBarNotApplicable]="confirmToolBarNotApplicable">
      </aal-input-text-area>
      `,
    };
  },
};

export const PlainTextAreaEnabled: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    alert: errorAlert,
    mode: Modes.EDIT,
    lockMode: Modes.EDIT,
    pressAcceptEvent: fn(),
    pressRejectEvent: fn(),
    label: 'Plain Text Area',
    showHyphenForValues: [null, ''],
    ID: 'PlainTextAreaEnabled',
    confirmToolBarNotApplicable: true,
    maxLength: 256,
  },
  render: (args) => {
    const fb = new UntypedFormBuilder();
    const control = fb.control(
      'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.',
      [Validators.required, Validators.maxLength(args.maxLength)],
    );
    return {
      props: {
        ...args,
        control,
      },
      template: `
      <aal-input-text-area
        (acceptChanges)="acceptChanges($event)"
        (rejectChanges)="rejectChanges($event)"
        (pressAcceptEvent)="pressAcceptEvent($event)"
        (pressRejectEvent)="pressRejectEvent($event)"
        [ID]="ID"
        [control]="control"
        [label]="label"
        [showHyphenForValues]="showHyphenForValues"
        [help]="help"
        [isBusy]="isBusy"
        [isHistoryEnabled]="isHistoryEnabled"
        [mode]="mode"
        [showLengthHint]="showLengthHint"
        [maxLength]="maxLength"
        [compositePlaceholder]="compositePlaceholder"
        [placeholder]="placeholder"
        [alwaysEditMode]="alwaysEditMode"
        [confirmToolBarNotApplicable]="confirmToolBarNotApplicable">
      </aal-input-text-area>
      `,
    };
  },
};

export const PlainTextAreaFocused: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    alert: errorAlert,
    mode: Modes.EDIT,
    lockMode: Modes.EDIT,
    pressAcceptEvent: fn(),
    pressRejectEvent: fn(),
    label: 'Plain Text Area',
    showHyphenForValues: [null, ''],
    ID: 'PlainTextAreaEnabled',
    confirmToolBarNotApplicable: true,
    maxLength: 256,
  },
  render: (args) => {
    const fb = new UntypedFormBuilder();
    const control = fb.control('', [Validators.required, Validators.maxLength(args.maxLength)]);
    return {
      props: {
        ...args,
        control,
      },
      template: `
      <aal-input-text-area
        (acceptChanges)="acceptChanges($event)"
        (rejectChanges)="rejectChanges($event)"
        (pressAcceptEvent)="pressAcceptEvent($event)"
        (pressRejectEvent)="pressRejectEvent($event)"
        [ID]="ID"
        [control]="control"
        [label]="label"
        [showHyphenForValues]="showHyphenForValues"
        [help]="help"
        [isBusy]="isBusy"
        [isHistoryEnabled]="isHistoryEnabled"
        [mode]="mode"
        [showLengthHint]="showLengthHint"
        [maxLength]="maxLength"
        [compositePlaceholder]="compositePlaceholder"
        [placeholder]="placeholder"
        [alwaysEditMode]="alwaysEditMode"
        [confirmToolBarNotApplicable]="confirmToolBarNotApplicable">
      </aal-input-text-area>
      `,
    };
  },
};

export const PlainTextAreaErrored: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    alert: errorAlert,
    mode: Modes.EDIT,
    lockMode: Modes.EDIT,
    pressAcceptEvent: fn(),
    pressRejectEvent: fn(),
    label: 'Plain Text Area',
    showHyphenForValues: [null, ''],
    ID: 'PlainTextAreaEnabled',
    confirmToolBarNotApplicable: true,
    placeholder: 'Textarea',
    maxLength: 256,
  },
  render: (args) => {
    const fb = new UntypedFormBuilder();
    const control = fb.control(
      'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.',
      [Validators.required, Validators.maxLength(args.maxLength)],
    );
    return {
      props: {
        ...args,
        control,
      },
      template: `
      <aal-input-text-area
        (acceptChanges)="acceptChanges($event)"
        (rejectChanges)="rejectChanges($event)"
        (pressAcceptEvent)="pressAcceptEvent($event)"
        (pressRejectEvent)="pressRejectEvent($event)"
        [ID]="ID"
        [control]="control"
        [label]="label"
        [showHyphenForValues]="showHyphenForValues"
        [help]="help"
        [isBusy]="isBusy"
        [isHistoryEnabled]="isHistoryEnabled"
        [mode]="mode"
        [showLengthHint]="showLengthHint"
        [maxLength]="maxLength"
        [compositePlaceholder]="compositePlaceholder"
        [placeholder]="placeholder"
        [alwaysEditMode]="alwaysEditMode"
        [confirmToolBarNotApplicable]="confirmToolBarNotApplicable">
      </aal-input-text-area>
      `,
    };
  },
};

export const PlainTextAreaShowMore: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    alert: errorAlert,
    mode: Modes.READ,
    lockMode: Modes.READ,
    pressAcceptEvent: fn(),
    pressRejectEvent: fn(),
    label: 'Plain Text Area Show More',
    placeholder: 'Plain Text Area Show More',
    showHyphenForValues: [null, ''],
    ID: 'PlainTextAreaEnabled',
    confirmToolBarNotApplicable: true,
  },
  render: (args) => {
    const fb = new UntypedFormBuilder();
    const control = fb.control(
      `Lorem ipsum
dolor sit amet,
consectetuer
adipiscing elit.
Aenean commodo
ligula eget dolor
Aenean massa
Cum sociis natoque
penatibus et magnis
dis parturient montes,
nascetur ridiculus mus
Donec quam felis,
ultricies nec,
pellentesque eu,
pretium quis, sem.
Nulla consequat
massa quis enim.`,
      [Validators.required, Validators.maxLength(10000)],
    );
    return {
      props: {
        ...args,
        control,
      },
      template: `
      <aal-input-text-area
        (acceptChanges)="acceptChanges($event)"
        (rejectChanges)="rejectChanges($event)"
        (pressAcceptEvent)="pressAcceptEvent($event)"
        (pressRejectEvent)="pressRejectEvent($event)"
        [ID]="ID"
        [control]="control"
        [label]="label"
        [showHyphenForValues]="showHyphenForValues"
        [help]="help"
        [isBusy]="isBusy"
        [isHistoryEnabled]="isHistoryEnabled"
        [mode]="mode"
        [showLengthHint]="showLengthHint"
        [maxLength]="maxLength"
        [compositePlaceholder]="compositePlaceholder"
        [placeholder]="placeholder"
        [alwaysEditMode]="alwaysEditMode"
        [confirmToolBarNotApplicable]="confirmToolBarNotApplicable">
      </aal-input-text-area>
      `,
    };
  },
};
