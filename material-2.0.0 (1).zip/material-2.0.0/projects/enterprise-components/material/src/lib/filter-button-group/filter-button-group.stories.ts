import { BrowserAnimationsModule, provideAnimations } from '@angular/platform-browser/animations';
import { applicationConfig, Meta, moduleMetadata, StoryObj } from '@storybook/angular';
import { FilterButtonGroupComponent } from './filter-button-group.component';

const meta: Meta<FilterButtonGroupComponent> = {
  title: 'Enterprise Components/Molecules/Filter Button Group',
  component: FilterButtonGroupComponent,
  decorators: [
    moduleMetadata({
      imports: [BrowserAnimationsModule],
    }),
    applicationConfig({
      providers: [provideAnimations()],
    }),
  ],
  argTypes: {},
};

export default meta;
type Story = StoryObj<FilterButtonGroupComponent>;

// Scenario 1: Default Multiple Mode
export const DefaultMultipleMode: Story = {
  args: {
    buttons: [
      { uid: '1', label: 'Filter 1', checked: false },
      { uid: '2', label: 'Filter 2', checked: true },
      { uid: '3', label: 'Filter 3', checked: false },
      { uid: '4', label: 'Filter 4', checked: false },
    ],
    selectionMode: 'multiple',
  },
  parameters: {
    docs: {
      description: {
        story:
          'Displays the filter button group in default multiple selection mode with a row layout.',
      },
    },
  },
};

// Scenario 2: Single Selection Mode
export const SingleSelectionMode: Story = {
  args: {
    buttons: [
      { uid: '1', label: 'Filter A', checked: false },
      { uid: '2', label: 'Filter B', checked: true },
      { uid: '3', label: 'Filter C', checked: false },
    ],
    selectionMode: 'single',
  },
  parameters: {
    docs: {
      description: {
        story: 'Displays the filter button group in single selection mode with a column layout.',
      },
    },
  },
};

// Scenario 3: Empty Button List
export const EmptyButtonList: Story = {
  args: {
    buttons: [],
    selectionMode: 'multiple',
  },
  parameters: {
    docs: {
      description: {
        story: 'Displays an empty filter button group.',
      },
    },
  },
};

// Scenario 4: Pre-selected Buttons
export const PreselectedButtons: Story = {
  args: {
    buttons: [
      { uid: '1', label: 'Option 1', checked: true },
      { uid: '2', label: 'Option 2', checked: true },
      { uid: '3', label: 'Option 3', checked: false },
    ],
    selectionMode: 'multiple',
  },
  parameters: {
    docs: {
      description: {
        story: 'Displays the filter button group with some buttons pre-selected.',
      },
    },
  },
};
