import { NgModule } from '@angular/core';
import { FilterButtonGroupComponent } from './public-api';

@NgModule({
  imports: [FilterButtonGroupComponent],
  exports: [FilterButtonGroupComponent],
})
export class FilterButtonGroupModule {}
