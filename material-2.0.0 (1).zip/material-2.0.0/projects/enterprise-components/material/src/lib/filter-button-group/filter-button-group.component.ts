import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  HostBinding,
  input,
} from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FilterButtonComponent } from '../../public-api';

@Component({
  selector: 'aal-filter-button-group',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, FilterButtonComponent],
  templateUrl: './filter-button-group.component.html',
  styleUrls: ['./filter-button-group.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FilterButtonGroupComponent {
  /**
   * List of filter buttons with their configurations.
   */
  buttons = input<
    Array<{
      uid: string;
      label: string;
      count?: number;
      checked: boolean;
      icon?: string;
      svg?: string;
    }>
  >([]);

  /**
   * Mode of the selection: 'single' or 'multiple'. Default: 'multiple'.
   */
  selectionMode = input<'single' | 'multiple'>('multiple');

  /**
   * Event emitted when the selection changes, providing the list of selected UIDs.
   */
  selectionChange = new EventEmitter<string[]>();

  // Dynamically calculate the number of buttons
  @HostBinding('style.--button-count')
  get buttonCount(): number {
    return this.buttons().length || 3;
  }

  /**
   * Handles the change event from a filter button.
   */
  onButtonChange(uid: string): void {
    if (this.selectionMode() === 'single') {
      // Uncheck all buttons except the clicked one
      this.buttons().forEach((button) => {
        button.checked = button.uid === uid ? !button.checked : false;
      });
    }

    // Emit updated selection state
    this.selectionChange.emit(this.getSelectedUIDs());
  }

  /**
   * Returns the UIDs of all selected buttons.
   */
  private getSelectedUIDs(): string[] {
    return this.buttons()
      .filter((button) => button.checked)
      .map((button) => button.uid);
  }
}
