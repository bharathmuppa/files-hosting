import { NgModule } from '@angular/core';
import { AutoCompleteFreeTextMultipleComponent } from './auto-complete-free-text-multiple.component';

@NgModule({
  imports: [AutoCompleteFreeTextMultipleComponent],
  exports: [AutoCompleteFreeTextMultipleComponent],
})
export class AutoCompleteFreeTextMultipleModule {}
