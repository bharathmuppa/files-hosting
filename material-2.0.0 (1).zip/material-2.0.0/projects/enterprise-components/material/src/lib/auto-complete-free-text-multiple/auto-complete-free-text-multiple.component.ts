import { NgClass } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatAutocomplete, MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { MatButton } from '@angular/material/button';
import { MatChipGrid, MatChipInput } from '@angular/material/chips';
import { MatOption } from '@angular/material/core';
import { MatDivider } from '@angular/material/divider';
import { MatFormField, MatLabel, MatPrefix, MatSuffix } from '@angular/material/form-field';
import { MatIcon } from '@angular/material/icon';
import { MatInput } from '@angular/material/input';
import { MatProgressSpinner } from '@angular/material/progress-spinner';
import { MatTooltip } from '@angular/material/tooltip';
import { HistoryService } from '@enterprise-components/common';
import { AutoCompleteMultipleComponent } from '../auto-complete-multiple/auto-complete-multiple.component';
import { ChipModule } from '../chip/chip.module';
import { OverlayCardAlertComponent } from '../overlay-card-alert/overlay-card-alert.component';
import { OverlayCardHelpComponent } from '../overlay-card-help/overlay-card-help.component';
import { ToolbarConfirmComponent } from '../toolbar-confirm/toolbar-confirm.component';

@Component({
  selector: 'aal-auto-complete-free-text-multiple',
  templateUrl: './auto-complete-free-text-multiple.component.html',
  styleUrls: ['./auto-complete-free-text-multiple.component.scss'],
  standalone: true,
  imports: [
    OverlayCardHelpComponent,
    MatProgressSpinner,
    MatFormField,
    MatLabel,
    MatChipGrid,
    ChipModule,
    MatPrefix,
    MatInput,
    FormsModule,
    MatChipInput,
    MatAutocompleteTrigger,
    ReactiveFormsModule,
    MatAutocomplete,
    MatOption,
    MatIcon,
    MatDivider,
    MatTooltip,
    MatButton,
    MatSuffix,
    ToolbarConfirmComponent,
    NgClass,
    OverlayCardAlertComponent,
  ],
})
export class AutoCompleteFreeTextMultipleComponent
  extends AutoCompleteMultipleComponent
  implements OnInit, OnChanges
{
  @Input()
  set resetList(value: boolean) {
    if (value) {
      this.inputControl.setValue('');
    }
  }
  @Input() showConfirmationToolbar: boolean;
  @Output()
  onFocus = new EventEmitter<any>();
  @Output()
  chipAdded: EventEmitter<void> = new EventEmitter<void>();
  @ViewChild(MatAutocompleteTrigger)
  public trigger: MatAutocompleteTrigger;
  constructor(historyService: HistoryService) {
    super(historyService);
  }

  ngOnInit() {
    super.ngOnInit();
    if (this.dataSource && this.showOptionsOnFocus) {
      this.dataSource().subscribe((data) => {
        if (data && data.length) {
          this.optionsList = data;
        }
      });
    }
  }
  addChip(event: any, input?: HTMLInputElement): void {
    this.inputControl.setValue('');
    this.chipAdded.emit(event);
    super.addChip(event, input);
    this.optionsList = this.removeControlValues(this.optionsList);
    setTimeout(() => {
      if (this.trigger) {
        this.trigger.openPanel();
      }
    }, 1);
  }

  onKeyUp(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      if (this.inputControl && this.inputControl.value) {
        this.currentValue = this.control.value || [];
        this.currentValue.push(this.inputControl.value);
        this.control.setValue(this.currentValue);
        this.chipAdded.emit(this.inputControl.value);
        this.resetInputControl();
      }
      this.triggerAcceptChanges();
    } else if (event.key === 'Escape') {
      this.triggerRejectChanges();
    } else if (event.key === ' ' && this.autoTrigger && this.autoTrigger.activeOption) {
      this.addChip(this.autoTrigger.activeOption, this.autoCompleteInput.nativeElement);
    }
  }

  removeChip(item: any, inputField: HTMLElement): void {
    this.resetInputControl();
    super.removeChip(item, inputField);
    this.optionsList.push(item);
    setTimeout(() => {
      this.trigger.openPanel();
    }, 1);
  }

  acceptFreeTextChanges() {
    if (this.inputControl.value !== '') {
      this.currentValue = this.control.value || [];
      this.currentValue.push(this.inputControl.value);
      this.control.setValue(this.currentValue);
      this.chipAdded.emit(this.inputControl.value);
      this.resetInputControl();
    }
    super.triggerAcceptChanges();
  }

  resetInputControl() {
    this.inputControl.setValue('');
  }

  onInputFocus(): void {
    this.onFocus.emit();
  }
}
