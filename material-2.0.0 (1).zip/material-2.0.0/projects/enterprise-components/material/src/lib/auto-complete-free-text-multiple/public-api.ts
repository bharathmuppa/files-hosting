/*
 * Public API Surface of material
 */

export * from './auto-complete-free-text-multiple.component';
export * from './auto-complete-free-text-multiple.module';
