import { NgModule } from '@angular/core';
import { ButtonOutlinedComponent } from './button-outlined.component';

@NgModule({
  imports: [ButtonOutlinedComponent],
  exports: [ButtonOutlinedComponent],
})
export class ButtonOutlinedModule {}
