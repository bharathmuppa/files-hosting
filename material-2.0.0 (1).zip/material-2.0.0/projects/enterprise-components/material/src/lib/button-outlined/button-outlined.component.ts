import { NgClass } from '@angular/common';
import { Component } from '@angular/core';
import { MatBadge } from '@angular/material/badge';
import { MatButton } from '@angular/material/button';
import { MatTooltip } from '@angular/material/tooltip';
import { AALCommonButtonComponent } from '@enterprise-components/common';

@Component({
  selector: 'aal-button-outlined',
  templateUrl: './button-outlined.component.html',
  styleUrls: ['./button-outlined.component.scss'],
  standalone: true,
  imports: [MatButton, MatBadge, NgClass, MatTooltip],
})
export class ButtonOutlinedComponent extends AALCommonButtonComponent {}
