import { NgModule } from '@angular/core';
import { ButtonToolbarComponent } from './button-toolbar.component';

@NgModule({
  imports: [ButtonToolbarComponent],
  exports: [ButtonToolbarComponent],
})
export class ButtonToolbarModule {}
