import { Component, Input, OnInit } from '@angular/core';
import { MatDivider } from '@angular/material/divider';
import { LegacyButtonModule } from '../_legacy-components/button-legacy/button.module';
import { ButtonConfiguration } from '../shared/shared.model';

@Component({
  selector: 'aal-button-toolbar',
  templateUrl: './button-toolbar.component.html',
  styleUrls: ['./button-toolbar.component.scss'],
  standalone: true,
  imports: [LegacyButtonModule, MatDivider],
})
export class ButtonToolbarComponent implements OnInit {
  @Input()
  toolbarConfiguration: ButtonConfiguration[];

  constructor() {}

  ngOnInit() {}
}
