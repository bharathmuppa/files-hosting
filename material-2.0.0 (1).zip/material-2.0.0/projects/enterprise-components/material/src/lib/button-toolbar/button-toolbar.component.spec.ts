import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { CommonModule } from '@angular/common';
import { MatBadgeModule } from '@angular/material/badge';
import { AALCommonComponentsModule } from '@enterprise-components/common';
import { LegacyButtonModule } from '../_legacy-components/button-legacy/button.module';
import { SharedFormModule } from '../shared/shared-form.module';
import { SharedMaterialModule } from '../shared/shared-material.module';
import { SharedModule } from '../shared/shared.module';
import { ButtonToolbarComponent } from './button-toolbar.component';

describe('ButtonToolbarComponent', () => {
  let component: ButtonToolbarComponent;
  let fixture: ComponentFixture<ButtonToolbarComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        MatBadgeModule,
        LegacyButtonModule,
        ButtonToolbarComponent,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ButtonToolbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
