### Migration Guide: Updating `EmptyStateComponent` with Content Projection

This guide explains how to migrate from the old version of `EmptyStateComponent` (File 1) to the new version (File 2), which now supports **content projection** (`ng-content`) for customization, simplifies title handling, and introduces support for custom buttons.

---

#### 1. **Simplified Title Handling**

The `title` input no longer uses `TemplateRef` or content projection for customization. Instead, it only accepts **text content** as a string.

- **Action**: Replace any `TemplateRef` or projected content for the title with a direct string assignment to the `title` input.

**Old Implementation (File 1)**:
```html
<aal-empty-state [titleTemplateRef]="titleTemplate"></aal-empty-state>

<ng-template #titleTemplate>
  <h1>Custom Title</h1>
</ng-template>
```

**New Implementation (File 2)**:
```html
<aal-empty-state title="Custom Title"></aal-empty-state>
```

---

#### 2. **Content Projection for Description**

The `description` input continues to support both direct string values and custom HTML content via content projection. For custom HTML, place the content inside the `<aal-empty-state>` element.

**Old Implementation (File 1)**:
```html
<aal-empty-state [descriptionTemplateRef]="descriptionTemplate"></aal-empty-state>

<ng-template #descriptionTemplate>
  <p>Custom Description</p>
</ng-template>
```

**New Implementation (File 2)**:
For plain text:
```html
<aal-empty-state description="Custom Description"></aal-empty-state>
```

For custom HTML:
```html
<aal-empty-state>
  <p class="es-custom-description">Custom Description</p>
</aal-empty-state>
```

---

#### 3. **Custom Button Support**

In the previous version, there was **no support** for custom buttons or actions directly inside the `EmptyStateComponent`. In the new version, custom buttons can be added using content projection (`ng-content`). 

**New Implementation (File 2)**:
Custom buttons are now injected into the component using `<ng-content>`:

```html
<aal-empty-state>
  <button class="es-button mat-raised-button">Retry</button>
</aal-empty-state>
```

The component template provides a dedicated slot for buttons:
```html
<div class="buttons">
  <ng-content select=".es-button"></ng-content>
</div>
```

---

#### 4. **Inputs Migration**

The new component simplifies and consolidates input properties. Here's how the inputs map from the old version to the new:

| **Old Input Property**           | **New Equivalent**                      | **Notes**                                                                                       |
|-----------------------------------|------------------------------------------|-------------------------------------------------------------------------------------------------|
| `title: string`                  | `title = input('No Data Available')`      | Only accepts text as input; content projection is no longer supported.                        |
| `description: string`            | `description = input('Please check back later.')` | Still supports content projection for custom HTML descriptions.                                |
| `icon: string`                   | `icon = input<string>()`                  | No change.                                                                                     |
| `svgIcon: string`                | `svgIcon = input<string>()`               | No change.                                                                                     |
| `imageTemplateRef: TemplateRef`  | **Removed**                               | Replace with custom `<img>` inside `<ng-content>`.                                            |
| `subTitleTemplateRef: TemplateRef` | **Removed**                               | Replaced by `description` input or custom HTML in `<ng-content>`.                             |
| `titleTemplateRef: TemplateRef`  | **Removed**                               | Titles now accept only plain text strings via the `title` input.                              |

---

#### 5. **Example Migration**

**Old Usage**:
```html
<aal-empty-state
  [icon]="myIcon"
  [title]="titleText"
  [description]="descriptionText"
  [titleTemplateRef]="titleTemplate"
  [descriptionTemplateRef]="descriptionTemplate"
>
</aal-empty-state>

<ng-template #titleTemplate>
  <h1>Custom Title</h1>
</ng-template>

<ng-template #descriptionTemplate>
  <p>Custom Description</p>
</ng-template>
```

**New Usage (File 2)**:
```html
<aal-empty-state [icon]="myIcon" title="Custom Title" description="Custom Description">
  <button class="custom-button mat-raised-button">Retry</button>
</aal-empty-state>
```

---

By following these steps, you can transition to the new version of the `EmptyStateComponent`, which streamlines inputs, adds flexibility through content projection, and introduces a dedicated mechanism for custom buttons.
