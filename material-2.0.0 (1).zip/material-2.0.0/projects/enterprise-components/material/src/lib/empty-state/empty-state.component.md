### Documentation

The `EmptyStateComponent` is a reusable, standalone Angular component for displaying an "empty state" view with customizable icons, title, description, and content slots using content projection.

---

#### Selector

```html
<aal-empty-state></aal-empty-state>
```

---

#### Inputs

| Input                 | Type                         | Default                | Description                                                                                  |
|-----------------------|------------------------------|------------------------|----------------------------------------------------------------------------------------------|
| `title`               | `string`                     | `"No Data Available"`  | The main title displayed in the empty state component.                                       |
| `description`         | `string`                     | `"Please check back later."` | Description text to provide additional context.                                      |
| `icon`                | `string`                     | `undefined`            | The name of the first icon (non-SVG) to display.                                             |
| `svgIcon`             | `string`                     | `undefined`            | The name of the first SVG icon to display.                                                   |
| `secondIcon`          | `string`                     | `undefined`            | The name of the second icon (non-SVG) to display.                                            |
| `secondSvgIcon`       | `string`                     | `undefined`            | The name of the second SVG icon to display.                                                  |
| `thirdIcon`           | `string`                     | `undefined`            | The name of the third icon (non-SVG) to display.                                             |
| `thirdSvgIcon`        | `string`                     | `undefined`            | The name of the third SVG icon to display.                                                   |
| `firstIconSize`       | `"medium" \| "large"`        | `"medium"`             | Controls the size of the first icon.                                                         |
| `secondIconSize`      | `"medium" \| "large"`        | `"medium"`             | Controls the size of the second icon.                                                        |
| `thirdIconSize`       | `"medium" \| "large"`        | `"medium"`             | Controls the size of the third icon.                                                         |
| `isPageLevel`         | `boolean`                    | `undefined`            | Determines if the title is displayed in a page-level (`mat-headline-6`) or subtitle style.   |

---

#### Content Projection

The new `EmptyStateComponent` supports **content projection** for flexible customization. Use `ng-content` to inject custom HTML into the component. Here’s how you can define custom content for button and descriptions:

```html
<aal-empty-state>
  <p class="es-custom-description">This is a custom description.</p>
  <button class="es-button">Custom styled button</button>
</aal-empty-state>
```

The component template includes predefined slots for projecting custom content:
- **`.es-custom-description`**: For the description.
- **`.es-button`**: For the button.

---

#### **Using Custom SVG Icons**

If you want to use custom SVG icons, ensure your Angular application has a configured `MatIconRegistry` to load these icons. 

##### **Step 1: Register Custom SVG Icons**

To use an icon from `assets/icons/custom-icon.svg`, follow these steps:  

In your Angular module or root component, use `MatIconRegistry` to register custom SVG icons:

```typescript
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';

export class AppModule {
  constructor(private matIconRegistry: MatIconRegistry, private domSanitizer: DomSanitizer) {
    this.matIconRegistry.addSvgIcon(
      'custom_icon', 
      this.domSanitizer.bypassSecurityTrustResourceUrl('assets/icons/custom-icon.svg')
    );
  }
}
```

##### **Step 2: Use Custom SVG Icons in the Component**

Once registered, you can use the `svgIcon` input to specify your custom icon:

```html
<aal-empty-state 
  [title]="'Custom Icon Example'" 
  [description]="'This uses a custom SVG icon.'"
  [svgIcon]="'custom_icon'"
  [firstIconSize]="'medium'">
</aal-empty-state>
```

---

### Migration Guide

If you are migrating from an older version of `EmptyStateComponent` that used `TemplateRef` for customization, refer to the [Migration Guide](./migration-guide.md.md) for step-by-step instructions.

---

By including the migration guide reference and clarifying the updated use of content projection, this updated README ensures users can transition smoothly and understand the component's features effectively.
