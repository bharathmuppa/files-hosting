### Architectural Decision Record (ADR)

**Title:** Implementation of Empty State Component

**Context:**
In user interfaces, empty states are crucial to guide users when there's no data or content to display. These states help to prevent confusion and ensure a smooth user experience. Empty states are often used to display a list without items, an empty search result, or a system notification indicating no content is available.

The goal is to design a flexible empty state component that:
- Provides a clear, helpful message.
- Displays a relevant non-interactive image or icon.
- Gives users guidance or helps them discover unused features in the app.
- Encourages users to take key actions to get started using button.

**Requirement:**
1. The empty state must consist of a non-interactive image (icon) and a tagline (text).
2. The image should be related to the content or message displayed.
3. The tagline should provide a brief, helpful message.
4. The component should be customizable, with optional second and third icons, different icon sizes, and customizable title and description, and customizable button.

**Decision:**

We have implemented the empty state component in Angular, taking the following considerations into account:
- The component is flexible, allowing for one or more icons, with size customizations for each.
- The `ngTemplateOutlet` directive is used to render icons dynamically, which provides flexibility in rendering different icons based on input data.
- The empty state component is responsive, ensuring the content and layout are adaptable for various screen sizes.
- The component supports optional text and icon inputs, ensuring that the content can be easily tailored to various use cases.
- The `title` and `description` allows for dynamic content insertion using input signals, ensuring that the component remains adaptable.
- The use of `ng-content` allows for external customization, enabling the inclusion of buttons or other UI elements within the empty state.

**Component Breakdown:**
1. **Icon Display:**
   - Three icons (first, second, third) can be passed in as input.
   - The icons are displayed in a row, using `ngTemplateOutlet` to handle dynamic rendering of icons.
   - A separator SVG element is displayed between the icons if required.

2. **Text Content:**
   - A `title()` function generates the title of the empty state.
   - An optional description can be shown if a `description()` function is provided. Additionally, custom content can be passed into the description section using `ng-content`.
   - The text styles are customizable via CSS, ensuring consistency with the app’s theme.

3. **Button Content:**
   - The component allows for a button or other interactive elements to be inserted through `ng-content`, enabling the user to take action, such as adding content, refreshing the page, or navigating to a help section.

**Trade-offs:**
- **Flexibility vs. Complexity:** The component is highly flexible, which increases its complexity. Developers must ensure they provide the appropriate inputs for each case, such as icons, sizes, and text. This could potentially lead to more complex use cases requiring careful management of input properties.
- **Dynamic Content Rendering:** By using `ngTemplateOutlet`, dynamic rendering of content (icons and text) can sometimes become harder to debug if the input data is not correctly passed or if incorrect templates are used.

**Consequences:**
- The empty state component is now reusable across the application for different sections or features, ensuring a consistent user experience.
- It allows for easy customization by other developers and designers, as the use of `ng-content` makes it easy to inject custom elements (buttons, descriptions, etc.) into the empty state.
- The architecture provides a foundation for further extensions, such as adding animations or more complex layouts if needed in the future.

**Implementation Details:**
- The component is defined as `EmptyStateComponent`, with the `standalone: true` directive for Angular to treat it as a self-contained unit.
- The icons are passed as optional inputs (`icon`, `svgIcon`, `secondIcon`, `thirdIcon`) and can be styled using the `IconSize` enum.
- The component supports page-level customization through the `isPageLevel()` input, allowing different text sizes for the title depending on its context.
- The CSS styles are modular and based on variables from the application's theme, ensuring consistency with the overall design system.
- Supports using custom SVG icons, which can be done by ensuring your Angular application has a configured `MatIconRegistry` to load these icons. 


**Conclusion:**
This architectural decision provides a reusable, flexible, and customizable solution for implementing empty states in the application, improving user experience by guiding them through empty or unpopulated sections with clarity and direction.

## Status

**Accepted**: This approach is implemented and working as intended, fulfilling our requirements for a reusable, empty-state component.
