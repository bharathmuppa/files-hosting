/*
 * Public API Surface of material
 */

export * from './empty-state.component';
export * from './empty-state.module';
