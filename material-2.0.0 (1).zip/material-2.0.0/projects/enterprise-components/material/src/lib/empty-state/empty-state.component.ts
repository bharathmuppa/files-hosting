import { NgClass, NgTemplateOutlet } from '@angular/common';
import { Component, input } from '@angular/core';
import { MatIcon } from '@angular/material/icon';

type IconSize = 'small' | 'medium';
@Component({
  selector: 'aal-empty-state',
  standalone: true,
  imports: [MatIcon, NgClass, NgTemplateOutlet],
  templateUrl: './empty-state.component.html',
  styleUrls: ['./empty-state.component.scss'],
})
export class EmptyStateComponent {
  // Input properties
  title = input('No Data Available');
  description = input('Please check back later.');

  // Icon inputs and sizes
  icon? = input<string>();
  svgIcon = input<string>();
  secondIcon? = input<string>();
  secondSvgIcon = input<string>();
  thirdIcon? = input<string>();
  thirdSvgIcon = input<string>();
  firstIconSize = input<IconSize>('small');
  secondIconSize = input<IconSize>('small');
  thirdIconSize = input<IconSize>('small');

  isPageLevel = input<boolean>();
}
