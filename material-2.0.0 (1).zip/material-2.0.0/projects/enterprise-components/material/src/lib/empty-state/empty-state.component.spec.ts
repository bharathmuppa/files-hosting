import { Component, signal, ViewChild } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatIconRegistry } from '@angular/material/icon';
import { MatIconTestingModule } from '@angular/material/icon/testing';
import { By, DomSanitizer } from '@angular/platform-browser';
import { ButtonComponent } from '../atoms/button/button.component';
import { EmptyStateComponent } from './empty-state.component';

@Component({
  template: `
    <aal-empty-state
      title="Test Title"
      description="Test Description"
      [icon]="'home'"
      [svgIcon]="'shield_yellow'"
      [secondIcon]="'star'"
      [secondSvgIcon]="'shield_blue'"
      [thirdIcon]="'settings'"
      [thirdSvgIcon]="'cr_card_summary'"
      firstIconSize="large"
      secondIconSize="medium"
      thirdIconSize="large"
      [isPageLevel]="true">
      <span style="font-weight: bold; color: #007bff" class="es-custom-description">
        This is styled description projected as customDescription
      </span>
      <aal-button class="es-button" [name]="'Label'"></aal-button>
    </aal-empty-state>
  `,
})
class TestHostComponent {
  @ViewChild(EmptyStateComponent) component: EmptyStateComponent;
  constructor(
    private readonly matIconRegistry: MatIconRegistry,
    private readonly domSanitizer: DomSanitizer,
  ) {
    this.matIconRegistry.addSvgIcon(
      'shield_yellow',
      this.domSanitizer.bypassSecurityTrustResourceUrl('../assets/shield_yellow.svg'),
    );
    this.matIconRegistry.addSvgIcon(
      'shield_blue',
      this.domSanitizer.bypassSecurityTrustResourceUrl('../assets/shield_blue.svg'),
    );
    this.matIconRegistry.addSvgIcon(
      'cr_card_summary',
      this.domSanitizer.bypassSecurityTrustResourceUrl('../assets/cr_card_summary.svg'),
    );
  }
}

describe('EmptyStateComponent', () => {
  let component: EmptyStateComponent;
  let fixture: ComponentFixture<TestHostComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TestHostComponent],
      imports: [EmptyStateComponent, MatIconTestingModule, ButtonComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(TestHostComponent);
    component = fixture.debugElement.query(By.directive(EmptyStateComponent)).componentInstance;

    fixture.detectChanges();
  });
  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should display the title', () => {
    const titleElement = fixture.debugElement.query(By.css('.mat-headline-6'));
    expect(titleElement.nativeElement.textContent).toContain('Test Title');
  });

  it('should display the description', () => {
    fixture.detectChanges();

    const descriptionElement = fixture.debugElement.query(By.css('.aal-empty-state__description'));
    expect(descriptionElement.nativeElement.textContent).toContain('Test Description');
  });

  it('should apply the correct class to the title based on isPageLevel input', () => {
    const titleElement = fixture.debugElement.query(By.css('.mat-headline-6'));
    expect(titleElement).toBeTruthy();
  });

  it('should render the custom description template', () => {
    debugger;
    const customDescription = fixture.debugElement.query(By.css('.es-custom-description'));
    expect(customDescription.nativeElement.textContent.trim()).toBe(
      'This is styled description projected as customDescription',
    );
  });

  it('should render the custom button template', () => {
    const customButton = fixture.debugElement.query(By.css('.es-button'));
    expect(customButton.nativeElement.textContent).toBe('Label');
  });

  it('should render SVG and non-SVG icons with correct size classes', () => {
    const icons = fixture.debugElement.queryAll(By.css('mat-icon'));
    // First icon with SVG (shield_yellow) and size large
    expect(icons[0].componentInstance.svgIcon).toBe('shield_yellow');
    expect(icons[0].nativeElement.classList.contains('icon--large')).toBeTrue();

    // Second icon with SVG (shield_blue) and size medium
    expect(icons[1].componentInstance.svgIcon).toBe('shield_blue');
    expect(icons[1].nativeElement.classList.contains('icon--medium')).toBeTrue();

    // Third icon with SVG (cr_card_summary) and size large
    expect(icons[2].componentInstance.svgIcon).toBe('cr_card_summary');
    expect(icons[2].nativeElement.classList.contains('icon--large')).toBeTrue();
  });

  it('should render non-SVG icons with the correct size class', async () => {
    component.svgIcon = signal(undefined) as unknown as typeof component.svgIcon;
    component.secondSvgIcon = signal(undefined) as unknown as typeof component.secondSvgIcon;
    component.thirdSvgIcon = signal(undefined) as unknown as typeof component.thirdSvgIcon;
    fixture.detectChanges();

    const icons = fixture.debugElement.queryAll(By.css('mat-icon'));

    // Check first non-SVG icon
    expect(icons[0].nativeElement.textContent.trim()).toBe('home');
    expect(icons[0].nativeElement.classList.contains('icon--large')).toBeTrue();

    // Check second non-SVG icon
    expect(icons[1].nativeElement.textContent.trim()).toBe('star');
    expect(icons[1].nativeElement.classList.contains('icon--medium')).toBeTrue();

    // Check third non-SVG icon
    expect(icons[2].nativeElement.textContent.trim()).toBe('settings');
    expect(icons[2].nativeElement.classList.contains('icon--large')).toBeTrue();
  });

  it('should display the separator SVG between icons', () => {
    const separatorSvgs = fixture.debugElement.queryAll(By.css('svg.separator'));
    expect(separatorSvgs.length).toBe(2); // Check if there are two separator SVGs
  });

  it('should not display any icon if none is provided', () => {
    // Removing icons by setting them to undefined and re-detecting changes
    component.icon = signal(undefined) as unknown as typeof component.icon;
    component.svgIcon = signal(undefined) as unknown as typeof component.svgIcon;
    component.secondIcon = signal(undefined) as unknown as typeof component.secondIcon;
    component.secondSvgIcon = signal(undefined) as unknown as typeof component.secondSvgIcon;
    component.thirdIcon = signal(undefined) as unknown as typeof component.thirdIcon;
    component.thirdSvgIcon = signal(undefined) as unknown as typeof component.thirdSvgIcon;
    fixture.detectChanges();

    const icons = fixture.debugElement.queryAll(By.css('mat-icon'));
    expect(icons.length).toBe(0);
  });
});
