import { provideHttpClient } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { MatIconModule, MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { applicationConfig, moduleMetadata, type Meta, type StoryObj } from '@storybook/angular';
import { ButtonComponent } from '../../public-api';
import { EmptyStateComponent } from './empty-state.component';

// needed for injecting custom svg
@NgModule({})
export class MatIconRegistryModule {
  constructor(
    private matIconRegistry: MatIconRegistry,
    private domSanitizer: DomSanitizer,
  ) {
    this.matIconRegistry
      .addSvgIcon(
        'shield_yellow',
        this.domSanitizer.bypassSecurityTrustResourceUrl('./assets/shield_yellow.svg'),
      )
      .addSvgIcon(
        'shield_blue',
        this.domSanitizer.bypassSecurityTrustResourceUrl('./assets/shield_blue.svg'),
      )
      .addSvgIcon(
        'cr_card_summary',
        this.domSanitizer.bypassSecurityTrustResourceUrl('./assets/cr_card_summary.svg'),
      );
  }
}

const meta: Meta<EmptyStateComponent> = {
  title: 'Enterprise Components/Molecules/Empty state',
  component: EmptyStateComponent,
  decorators: [
    applicationConfig({
      providers: [provideHttpClient()],
    }),
    moduleMetadata({
      imports: [MatIconModule, MatIconRegistryModule],
    }),
  ],
};

export default meta;

type Story = StoryObj<EmptyStateComponent>;

export const DefaultWithoutInputs: Story = {};

export const Default: Story = {
  args: {
    icon: 'list',
    firstIconSize: 'small',
    description: 'The description of the empty state. Make it condense but understandable.',
    title: 'Empty State Title',
    isPageLevel: false,
  },
};

export const FirstIconMedium: Story = {
  args: {
    icon: 'list',
    firstIconSize: 'medium',
    description: 'The description of the empty state. Make it condense but understandable.',
    title: 'Empty State Title',
    isPageLevel: false,
  },
};

export const ShowSecondIcon: Story = {
  args: {
    icon: 'list',
    firstIconSize: 'medium',
    secondIcon: 'list',
    secondIconSize: 'medium',
    description: 'The description of the empty state. Make it condense but understandable.',
    title: 'Empty State Title',
    isPageLevel: false,
  },
};

export const ShowSecondMedium: Story = {
  args: {
    icon: 'list',
    firstIconSize: 'medium',
    secondIcon: 'list',
    secondIconSize: 'medium',
    description: 'The description of the empty state. Make it condense but understandable.',
    title: 'Empty State Title',
    isPageLevel: false,
  },
};

export const ShowThirdIcon: Story = {
  args: {
    icon: 'list',
    firstIconSize: 'medium',
    secondIcon: 'list',
    secondIconSize: 'medium',
    thirdIcon: 'list',
    thirdIconSize: 'medium',
    description: 'The description of the empty state. Make it condense but understandable.',
    title: 'Empty State Title',
    isPageLevel: false,
  },
};

export const ShowThirdIconMedium: Story = {
  args: {
    icon: 'list',
    firstIconSize: 'medium',
    secondIcon: 'list',
    secondIconSize: 'medium',
    thirdIcon: 'list',
    thirdIconSize: 'medium',
    description: 'The description of the empty state. Make it condense but understandable.',
    title: 'Empty State Title',
    isPageLevel: false,
  },
};

export const SVGIcons: Story = {
  args: {
    title: 'Empty State Title',
    description: 'The description of the empty state. Make it condense but understandable.',
    icon: 'list',
    svgIcon: 'shield_yellow',
    secondSvgIcon: 'shield_blue',
    secondIcon: 'list',
    thirdIcon: 'list',
    thirdSvgIcon: 'cr_card_summary',
    firstIconSize: 'medium',
    secondIconSize: 'medium',
    thirdIconSize: 'medium',
    isPageLevel: false,
  },
};

export const SVGIconsMedium: Story = {
  args: {
    title: 'Empty State Title',
    description: 'The description of the empty state. Make it condense but understandable.',
    svgIcon: 'shield_yellow',
    secondSvgIcon: 'shield_blue',
    thirdSvgIcon: 'cr_card_summary',
    firstIconSize: 'medium',
    secondIconSize: 'medium',
    thirdIconSize: 'medium',
    isPageLevel: false,
  },
};

export const CustomDescription: Story = {
  args: {
    title: 'Empty State Title',
    svgIcon: 'shield_yellow',
    secondSvgIcon: 'shield_blue',
    thirdSvgIcon: 'cr_card_summary',
    firstIconSize: 'medium',
    secondIconSize: 'medium',
    thirdIconSize: 'medium',
    isPageLevel: false,
  },
  render: (args) => ({
    template: `
      <aal-empty-state
        [svgIcon]="svgIcon"
        [secondSvgIcon]="secondSvgIcon"
        [thirdSvgIcon]="thirdSvgIcon"
        firstIconSize="medium"
        secondIconSize="medium"
        thirdIconSize="medium"
        [title]="title"
        [isPageLevel]="false">
          <span style="font-weight: bold; color: #007bff" class="es-custom-description">
            This is styled description passed as customDescription templateRef
          </span>
      </aal-empty-state>
    `,
    props: args,
  }),
};

export const CustomContainedButton: Story = {
  args: {
    title: 'Empty State Title',
    description: 'The description of the empty state. Make it condense but understandable.',
    svgIcon: 'shield_yellow',
    secondSvgIcon: 'shield_blue',
    thirdSvgIcon: 'cr_card_summary',
    firstIconSize: 'medium',
    secondIconSize: 'medium',
    thirdIconSize: 'medium',
    isPageLevel: false,
  },
  render: (args) => ({
    styles: [
      `
      :host ::ng-deep button {
        letter-spacing: 0.01094rem !important;
        }
      `,
    ],

    template: `
      <aal-empty-state
        [svgIcon]="svgIcon"
        [secondSvgIcon]="secondSvgIcon"
        [thirdSvgIcon]="thirdSvgIcon"
        firstIconSize="medium"
        secondIconSize="medium"
        thirdIconSize="medium"
        [title]="title"
        [description]="description"
        [isPageLevel]="false">
        <aal-button style="font-weight: bold; color: #007bff" [name]="'Label'" class="es-button"></aal-button>
      </aal-empty-state>
    `,
    props: args,
    moduleMetadata: {
      imports: [ButtonComponent],
    },
  }),
};

export const CustomContainedButtonDisabled: Story = {
  args: {
    title: 'Empty State Title',
    description: 'The description of the empty state. Make it condense but understandable.',
    svgIcon: 'shield_yellow',
    secondSvgIcon: 'shield_blue',
    thirdSvgIcon: 'cr_card_summary',
    firstIconSize: 'medium',
    secondIconSize: 'medium',
    thirdIconSize: 'medium',
    isPageLevel: false,
  },
  render: (args) => ({
    styles: [
      `
    :host ::ng-deep button {
      letter-spacing: 0.01094rem !important;
      }
    `,
    ],
    template: `
      <aal-empty-state
        [svgIcon]="svgIcon"
        [secondSvgIcon]="secondSvgIcon"
        [thirdSvgIcon]="thirdSvgIcon"
        firstIconSize="medium"
        secondIconSize="medium"
        thirdIconSize="medium"
        [title]="title"
        [description]="description"
        [isPageLevel]="false">
          <aal-button class="es-button" [name]="'Label'" [disabled]="true"></aal-button>
      </aal-empty-state>
    `,
    props: args,
    moduleMetadata: {
      imports: [ButtonComponent],
    },
  }),
};

export const CustomContainedButtonIconOnly: Story = {
  args: {
    title: 'Empty State Title',
    description: 'The description of the empty state. Make it condense but understandable.',
    svgIcon: 'shield_yellow',
    secondSvgIcon: 'shield_blue',
    thirdSvgIcon: 'cr_card_summary',
    firstIconSize: 'medium',
    secondIconSize: 'medium',
    thirdIconSize: 'medium',
    isPageLevel: false,
  },
  render: (args) => ({
    styles: [
      `
    :host ::ng-deep button {
      letter-spacing: 0.01094rem !important;
      }
    `,
    ],
    template: `
      <aal-empty-state
        [svgIcon]="svgIcon"
        [secondSvgIcon]="secondSvgIcon"
        [thirdSvgIcon]="thirdSvgIcon"
        firstIconSize="medium"
        secondIconSize="medium"
        thirdIconSize="medium"
        [title]="title"
        [description]="description"
        [isPageLevel]="false">
          <aal-button class="es-button" [icon]="'chevron_right'" [type]="'contained'"></aal-button>
      </aal-empty-state>
    `,
    props: args,
    moduleMetadata: {
      imports: [ButtonComponent],
    },
  }),
};

export const CustomContainedButtonLeadingIcon: Story = {
  args: {
    title: 'Empty State Title',
    description: 'The description of the empty state. Make it condense but understandable.',
    svgIcon: 'shield_yellow',
    secondSvgIcon: 'shield_blue',
    thirdSvgIcon: 'cr_card_summary',
    firstIconSize: 'medium',
    secondIconSize: 'medium',
    thirdIconSize: 'medium',
    isPageLevel: false,
  },
  render: (args) => ({
    styles: [
      `
    :host ::ng-deep button {
      letter-spacing: 0.01094rem !important;
      }
    `,
    ],
    template: `
      <aal-empty-state
        [svgIcon]="svgIcon"
        [secondSvgIcon]="secondSvgIcon"
        [thirdSvgIcon]="thirdSvgIcon"
        firstIconSize="medium"
        secondIconSize="medium"
        thirdIconSize="medium"
        [title]="title"
        [description]="description"
        [isPageLevel]="false">
          <aal-button class="es-button" [icon]="'chevron_right'" name="Label" [type]="'contained'"></aal-button>
      </aal-empty-state>
    `,
    props: args,
    moduleMetadata: {
      imports: [ButtonComponent],
    },
  }),
};

export const CustomContainedButtonTrailingIcon: Story = {
  args: {
    title: 'Empty State Title',
    description: 'The description of the empty state. Make it condense but understandable.',
    svgIcon: 'shield_yellow',
    secondSvgIcon: 'shield_blue',
    thirdSvgIcon: 'cr_card_summary',
    firstIconSize: 'medium',
    secondIconSize: 'medium',
    thirdIconSize: 'medium',
    isPageLevel: false,
  },
  render: (args) => ({
    styles: [
      `
    :host ::ng-deep button {
      letter-spacing: 0.01094rem !important;
      }
    `,
    ],
    template: `
      <aal-empty-state
        [svgIcon]="svgIcon"
        [secondSvgIcon]="secondSvgIcon"
        [thirdSvgIcon]="thirdSvgIcon"
        firstIconSize="medium"
        secondIconSize="medium"
        thirdIconSize="medium"
        [title]="title"
        [description]="description"
        [isPageLevel]="false">
          <aal-button class="es-button" [icon]="'add'" [iconRight]="'chevron_right'" name="Label" [showIconRightToButtonText]="true" [type]="'contained'"></aal-button>
      </aal-empty-state>
    `,
    props: args,

    moduleMetadata: {
      imports: [ButtonComponent],
    },
  }),
};

// TODO: Fix button badge alignment
export const CustomContainedButtonWithBadge: Story = {
  args: {
    title: 'Empty State Title',
    description: 'The description of the empty state. Make it condense but understandable.',
    svgIcon: 'shield_yellow',
    secondSvgIcon: 'shield_blue',
    thirdSvgIcon: 'cr_card_summary',
    firstIconSize: 'medium',
    secondIconSize: 'medium',
    thirdIconSize: 'medium',
    isPageLevel: false,
  },
  render: (args) => ({
    styles: [
      `
    :host ::ng-deep button {
      letter-spacing: 0.01094rem !important;
    }
    `,
    ],
    template: `
      <aal-empty-state
        [svgIcon]="svgIcon"
        [secondSvgIcon]="secondSvgIcon"
        [thirdSvgIcon]="thirdSvgIcon"
        firstIconSize="medium"
        secondIconSize="medium"
        thirdIconSize="medium"
        [title]="title"
        [description]="description"
        [isPageLevel]="false">
          <aal-button
            class="es-button"
            [icon]="'chevron_right'"
            [type]="'contained'"
            [hasBadge]="true"
            [badgeData]="'1'">
          </aal-button>
      </aal-empty-state>
    `,
    props: args,
    moduleMetadata: {
      imports: [ButtonComponent],
    },
  }),
};

export const CustomOutlinedButton: Story = {
  args: {
    title: 'Empty State Title',
    description: 'The description of the empty state. Make it condense but understandable.',
    svgIcon: 'shield_yellow',
    secondSvgIcon: 'shield_blue',
    thirdSvgIcon: 'cr_card_summary',
    firstIconSize: 'medium',
    secondIconSize: 'medium',
    thirdIconSize: 'medium',
    isPageLevel: false,
  },
  render: (args) => ({
    styles: [
      `
    :host ::ng-deep button {
      letter-spacing: 0.01094rem !important;
      }
    `,
    ],
    template: `
      <aal-empty-state
        [svgIcon]="svgIcon"
        [secondSvgIcon]="secondSvgIcon"
        [thirdSvgIcon]="thirdSvgIcon"
        firstIconSize="medium"
        secondIconSize="medium"
        thirdIconSize="medium"
        [title]="title"
        [description]="description"
        [isPageLevel]="false">
          <aal-button class="es-button" [name]="'Label'" [type]="'outlined'"></aal-button>
      </aal-empty-state>
    `,
    props: args,
    moduleMetadata: {
      imports: [ButtonComponent],
    },
  }),
};
export const CustomTextButton: Story = {
  args: {
    title: 'Empty State Title',
    description: 'The description of the empty state. Make it condense but understandable.',
    svgIcon: 'shield_yellow',
    secondSvgIcon: 'shield_blue',
    thirdSvgIcon: 'cr_card_summary',
    firstIconSize: 'medium',
    secondIconSize: 'medium',
    thirdIconSize: 'medium',
    isPageLevel: false,
  },
  render: (args) => ({
    styles: [
      `
      :host ::ng-deep button {
        letter-spacing: 0.01094rem !important;
      }
    `,
    ],
    template: `
      <aal-empty-state
        [svgIcon]="svgIcon"
        [secondSvgIcon]="secondSvgIcon"
        [thirdSvgIcon]="thirdSvgIcon"
        firstIconSize="medium"
        secondIconSize="medium"
        thirdIconSize="medium"
        [title]="title"
        [description]="description"
        [isPageLevel]="false">
          <aal-button class="es-button" [name]="'Label'" [type]="'text'"></aal-button>
      </aal-empty-state>
    `,
    props: args,
    moduleMetadata: {
      imports: [ButtonComponent],
    },
  }),
};
// TODO: Add different variance of empty state custom button depending on the
// discussion feedback with John, like do we need disabled button
