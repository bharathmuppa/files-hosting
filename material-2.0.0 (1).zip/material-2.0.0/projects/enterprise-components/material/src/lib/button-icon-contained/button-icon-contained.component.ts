import { NgClass } from '@angular/common';
import { Component, Input } from '@angular/core';
import { MatBadge } from '@angular/material/badge';
import { MatButton } from '@angular/material/button';
import { MatIcon } from '@angular/material/icon';
import { MatTooltip } from '@angular/material/tooltip';
import { AALCommonButtonComponent } from '@enterprise-components/common';

@Component({
  selector: 'aal-button-icon-contained',
  templateUrl: './button-icon-contained.component.html',
  styleUrls: ['./button-icon-contained.component.scss'],
  standalone: true,
  imports: [MatButton, MatTooltip, MatBadge, NgClass, MatIcon],
})
export class ButtonIconContainedComponent extends AALCommonButtonComponent {
  @Input()
  iconRight: string = '';
  @Input()
  showIconRightToButtonText: boolean = false;
  @Input()
  showIconLeftToButtonText: boolean = true;
}
