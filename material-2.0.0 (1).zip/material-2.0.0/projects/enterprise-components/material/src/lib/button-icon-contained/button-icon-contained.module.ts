import { NgModule } from '@angular/core';
import { ButtonIconContainedComponent } from './button-icon-contained.component';

@NgModule({
  imports: [ButtonIconContainedComponent],
  exports: [ButtonIconContainedComponent],
})
export class ButtonIconContainedModule {}
