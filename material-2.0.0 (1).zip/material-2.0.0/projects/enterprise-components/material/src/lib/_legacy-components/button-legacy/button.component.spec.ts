import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatBadgeModule } from '@angular/material/badge';
import { AALCommonComponentsModule } from '@enterprise-components/common';

import { ButtonContainedModule } from '../../button-contained/button-contained.module';
import { ButtonIconModule } from '../../button-icon/button-icon.module';
import { SharedFormModule } from '../../shared/shared-form.module';
import { SharedMaterialModule } from '../../shared/shared-material.module';
import { SharedModule } from '../../shared/shared.module';
import { AALButtonLegacyComponent } from './button.component';

describe('ButtonComponent', () => {
  let component: AALButtonLegacyComponent;
  let fixture: ComponentFixture<AALButtonLegacyComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AALButtonLegacyComponent],
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        MatBadgeModule,
        ButtonContainedModule,
        ButtonIconModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AALButtonLegacyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit on click', () => {
    spyOn(component.onClick, 'emit');
    const $event = new Event('click');
    component.click($event);
    expect(component.onClick.emit).toHaveBeenCalled();
  });
});
