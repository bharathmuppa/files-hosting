import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ButtonTypes } from '@enterprise-components/common';
import { ButtonConfiguration } from '../../shared/shared.model';

@Component({
  selector: 'aal-button-legacy',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss'],
})
export class AALButtonLegacyComponent implements OnInit {
  @Input()
  buttonConfiguration: ButtonConfiguration;
  @Output() onClick = new EventEmitter<any>();
  buttonTypes = ButtonTypes;

  ngOnInit() {}

  click($event): void {
    this.onClick.emit($event);
  }
}
