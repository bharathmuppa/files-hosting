import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { AALCommonComponentsModule } from '@enterprise-components/common';
import { ButtonContainedModule } from '../../button-contained/button-contained.module';
import { ButtonIconModule } from '../../button-icon/button-icon.module';
import { AALButtonLegacyComponent } from './button.component';

@NgModule({
  declarations: [AALButtonLegacyComponent],
  imports: [CommonModule, AALCommonComponentsModule, ButtonContainedModule, ButtonIconModule],
  exports: [AALButtonLegacyComponent],
})
export class LegacyButtonModule {}
