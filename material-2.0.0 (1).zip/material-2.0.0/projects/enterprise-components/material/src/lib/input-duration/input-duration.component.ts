import { Component, Input, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormControl } from '@angular/forms';
import {
  AALInputFormControlComponent,
  DurationTypes,
  HistoryService,
  Info,
  Modes,
} from '@enterprise-components/common';
import { Duration } from 'luxon';

import { AsyncPipe, NgClass } from '@angular/common';
import { MatAutocomplete, MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { MatOption } from '@angular/material/core';
import { MatError, MatFormField, MatLabel } from '@angular/material/form-field';
import { MatIcon } from '@angular/material/icon';
import { MatInput } from '@angular/material/input';
import { MatProgressSpinner } from '@angular/material/progress-spinner';
import { MatTooltip } from '@angular/material/tooltip';
import { AALCommonModule } from '../common/common.module';
import { OverlayCardAlertComponent } from '../overlay-card-alert/overlay-card-alert.component';
import { OverlayCardHelpComponent } from '../overlay-card-help/overlay-card-help.component';
import { CommonMaterialComponentErrorStateMatcher } from '../shared/common-material-component.error-state-matcher';
import { ToolbarConfirmComponent } from '../toolbar-confirm/toolbar-confirm.component';

@Component({
  selector: 'aal-input-duration',
  templateUrl: './input-duration.component.html',
  styleUrls: ['./input-duration.component.scss'],
  standalone: true,
  imports: [
    OverlayCardHelpComponent,
    MatProgressSpinner,
    MatFormField,
    MatLabel,
    MatInput,
    FormsModule,
    MatAutocompleteTrigger,
    ReactiveFormsModule,
    MatAutocomplete,
    MatOption,
    MatIcon,
    MatError,
    ToolbarConfirmComponent,
    MatTooltip,
    NgClass,
    AALCommonModule,
    OverlayCardAlertComponent,
    AsyncPipe,
  ],
})
export class InputDurationComponent extends AALInputFormControlComponent implements OnInit {
  @Input()
  prefixInReadMode: string;
  durationToRevert: any;
  @Input()
  pattern: RegExp;
  @Input()
  type: string;
  @Input()
  displayOutputOnlyIn: string;
  @Input()
  formatStringHint: string;
  errorStateMatcher = new CommonMaterialComponentErrorStateMatcher();

  constructor(historyService: HistoryService) {
    super(historyService); // (?[a-zA-Z])
  }

  @Input()
  set alert(error: Info) {
    this.error = error;
    if (error) {
      this.revertChanges();
    }
  }

  get control() {
    return this.frmControl;
  }

  @Input()
  set control(ctrl: UntypedFormControl) {
    if (ctrl && ctrl.value !== undefined) {
      if (ctrl.value && !ctrl.value.match(/^[p|P]/i)) {
        this.newValue = this.dhmToISODuration(ctrl.value);
        this.oldValue = this.dhmToISODuration(ctrl.value);
      } else if (ctrl.value === null) {
        this.newValue = null;
        this.oldValue = null;
      } else {
        this.newValue = ctrl.value;
        this.oldValue = ctrl.value;
      }
      ctrl.setValue(this.isoDurationToDHMFormat(this.newValue));
    }
    this.frmControl = ctrl;
  }

  ngOnInit() {
    if (!this.pattern) {
      switch (this.type) {
        case DurationTypes.Period:
          this.pattern =
            /^\d(\d*)((y|Y|yr|YR)?)\s*(\d*)((mo|MO)?)\s*(\d*)([dD]?)\s*(?![0-9])$|^\d(\d*):([0-5][0-9]$)/;
          this.formatStringHint = !this.formatStringHint
            ? 'Use Format: 2y2mo2d Or 2yr2mo2d or 2y 2mo 2d'
            : '';
          break;
        case DurationTypes.Duration:
          this.pattern =
            /^\d(\d*)([dD]?)\s*(\d*)((h|H|hr|HR)?)\s*(\d*)([mM]?)(?![0-9])$|^\d(\d*):([0-5][0-9]$)/;
          this.formatStringHint = !this.formatStringHint ? 'Use Format: 2d2h2m Or 2d 2h 2m' : '';
          break;
        default:
        case DurationTypes.Default:
          this.pattern =
            /^\d(\d*)((y|Y|yr|YR)?)\s*(\d*)((mo|MO)?)\s*(\d*)([dD]?)\s*(\d*)((h|H|hr|HR)?)\s*(\d*)([mM]?)(?![0-9])$|^\d(\d*):([0-5][0-9]$)/;
          this.formatStringHint = !this.formatStringHint
            ? 'Use Format: 2y2mo2d2h2m Or 2yr2mo2d2hr2m Or 2y 2mo 2d 2h 2m'
            : '';
          break;
      }
    }
    super.ngOnInit();
  }

  onBlur($event: Event) {
    /* For composite controls, when any value is selected, the focus shits to the input element. Here we are writing conditions for the scenarios when the blur event of the input control must not be called. Add the class 'skip-input-blur-event' to achieve this */
    if (
      $event instanceof FocusEvent &&
      $event.relatedTarget &&
      ($event.relatedTarget['classList'].contains('mat-select') ||
        $event.relatedTarget['id'].includes(this.hyphenatedID) ||
        $event.relatedTarget['parentElement'].classList.contains('skip-input-blur-event'))
    ) {
      // do nothing
      return;
    }
    if (this.control.valid) {
      this.sanitizeControlValue();
      this.newValue = this.dhmToISODuration(this.control.value);
      super.onBlur($event);
    }
  }

  revertChanges() {
    this.showConfirmationToolbar = false;
    this.control.setValue(this.isoDurationToDHMFormat(this.durationToRevert));
    this.oldValue = this.durationToRevert;
    this.setMode(Modes.READ);
  }

  getValidatorMessage(validatorKey: string): string {
    if (validatorKey.toUpperCase() === 'PATTERN') {
      return this.formatStringHint;
    } else {
      return super.getValidatorMessage(validatorKey);
    }
  }

  triggerAcceptChanges() {
    if (this.control.valid) {
      this.sanitizeControlValue();
      this.durationToRevert = this.oldValue;
      this.newValue = this.dhmToISODuration(this.control.value);
      if (this.type === 'duration') {
        this.control.setValue(this.isoDurationToDHMFormat(this.newValue));
      }
      super.triggerAcceptChanges();
    }
  }

  triggerRejectChanges() {
    this.newValue = this.dhmToISODuration(this.control.value);
    super.triggerRejectChanges();
    this.control.setValue(this.isoDurationToDHMFormat(this.oldValue));
  }

  private dhmToISODuration(value): string {
    if (value === null) {
      return null;
    }
    value = value.replace(/\s/g, '').toLowerCase();
    let duration = '';
    if (
      value.indexOf('y') > -1 ||
      value.indexOf('d') > -1 ||
      value.indexOf('h') > -1 ||
      value.indexOf('m') > -1
    ) {
      duration = 'P';
      switch (this.type) {
        case DurationTypes.Period:
          let periodMatches = value.match(/(\d+)([yY])/);
          duration =
            duration + (periodMatches && periodMatches.length > 0 ? periodMatches[1] + 'Y' : '0Y');
          periodMatches = value.match(/(\d+)(mo|MO)/);
          duration =
            duration + (periodMatches && periodMatches.length > 0 ? periodMatches[1] + 'M' : '0M');
          periodMatches = value.match(/(\d+)([dD])/);
          duration =
            duration + (periodMatches && periodMatches.length > 0 ? periodMatches[1] + 'D' : '0D');
          break;
        case DurationTypes.Duration:
          let durationMatches = value.match(/(\d+)([dD])/);
          duration =
            duration +
            (durationMatches && durationMatches.length > 0 ? durationMatches[1] + 'D' : '0D');
          durationMatches = value.match(/(\d+)([hH])/);
          duration =
            duration +
            (durationMatches && durationMatches.length > 0 ? `T${durationMatches[1]}H` : 'T0H');
          durationMatches = value.match(/(\d+)([mM])(?!o)/);
          duration =
            duration +
            (durationMatches && durationMatches.length > 0 ? durationMatches[1] + 'M' : '0M');
          break;
        default:
        case DurationTypes.Default:
          let defaultMatches = value.match(/(\d+)([yY])/);
          duration =
            duration +
            (defaultMatches && defaultMatches.length > 0 ? defaultMatches[1] + 'Y' : '0Y');
          defaultMatches = value.match(/(\d+)(mo|MO)/);
          duration =
            duration +
            (defaultMatches && defaultMatches.length > 0 ? defaultMatches[1] + 'M' : '0M');
          defaultMatches = value.match(/(\d+)([dD])/);
          duration =
            duration +
            (defaultMatches && defaultMatches.length > 0 ? defaultMatches[1] + 'D' : '0D');
          defaultMatches = value.match(/(\d+)([hH])/);
          duration =
            duration +
            (defaultMatches && defaultMatches.length > 0 ? `T${defaultMatches[1]}H` : 'T0H');
          defaultMatches = value.match(/(\d+)([mM])(?!o)/);
          duration =
            duration +
            (defaultMatches && defaultMatches.length > 0 ? defaultMatches[1] + 'M' : '0M');
          break;
      }
    } else if (value.indexOf(':') > -1) {
      const match = value.match(/(\d*)[:](\d*)/);
      if (match && match.length === 3) {
        duration = `PT${match[1]}H${match[2]}M`;
      }
    }
    return duration;
  }

  private isoDurationToDHMFormat(value): string {
    if (value === null) {
      return null;
    }
    const duration = Duration.fromISO(value);
    const years = Math.trunc(duration.years);
    const months = Math.trunc(duration.months);
    const days = Math.trunc(duration.days);
    const hours = Math.trunc(duration.hours);
    const minutes = Math.trunc(duration.minutes);
    if (
      value.indexOf('Y') > -1 ||
      value.indexOf('D') > -1 ||
      value.indexOf('H') > -1 ||
      value.indexOf('M') > -1 ||
      value.indexOf('S') > -1
    ) {
      switch (this.type) {
        case DurationTypes.Period:
          return (
            (
              (years ? `${years}yr` : '') +
              (months ? ` ${months}mo` : '') +
              (days ? ` ${days}d` : '')
            ).trim() || '0yr'
          );
        case DurationTypes.Duration:
          return (
            (
              (days ? `${days}d` : '') +
              (hours ? ` ${hours}h` : '') +
              (minutes ? ` ${minutes}m` : '')
            ).trim() || '0h'
          );
        default:
        case DurationTypes.Default:
          return (
            (
              (years ? `${years}yr` : '') +
              (months ? ` ${months}mo` : '') +
              (days ? ` ${days}d` : '') +
              (hours ? ` ${hours}h` : '') +
              (minutes ? ` ${minutes}m` : '')
            ).trim() || '0h'
          );
      }
    }
    return value;
  }

  private sanitizeControlValue() {
    let temp =
      this.control && this.control.value ? this.control.value : this.control.value === 0 ? '0' : '';
    let tempValue = '';
    // if only number , default to hours
    if (!isNaN(temp)) {
      temp +=
        this.displayOutputOnlyIn ||
        (this.type === DurationTypes.Duration
          ? 'h'
          : this.type === DurationTypes.Period
            ? 'yr'
            : 'h');
    }
    const splitData = temp
      .replace(/\s/g, '')
      .split(/[:]|(\d+)/)
      .filter((item) => item !== '' && item !== undefined && item !== null);
    if (splitData.length < 3) {
      if (!isNaN(splitData[0]) && !isNaN(splitData[1])) {
        tempValue = `${this.addPadding(splitData[0] || 0)}h ${this.addPadding(splitData[1] || 0)}m`;
      } else if (!isNaN(splitData[0]) && isNaN(splitData[1])) {
        tempValue = `${this.addPadding(splitData[0] || 0)}${splitData[1]}`;
      }
    } else if (splitData.length > 2) {
      splitData.forEach((data, index) => {
        if (!isNaN(parseInt(data, 10))) {
          tempValue += data;
        } else {
          tempValue += data + (index !== splitData.length - 1 ? ' ' : '');
        }
      });
    }
    this.control.setValue(tempValue);
  }

  private addPadding(pad) {
    if (parseInt(pad, 10) === 0) {
      return '0';
    }
    // return (parseInt(pad, 10) < 10 ? '0' : '') + parseInt(pad, 10);
    return parseInt(pad, 10);
  }
}
