/*
 * Public API Surface of material
 */

export * from './input-duration.component';
export * from './input-duration.module';
