import { NgModule } from '@angular/core';
import { InputDurationComponent } from './input-duration.component';

@NgModule({
  imports: [InputDurationComponent],
  exports: [InputDurationComponent],
})
export class InputDurationModule {}
