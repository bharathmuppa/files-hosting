import { NgModule } from '@angular/core';
import { ButtonOverlayTabbedComponent } from './button-overlay-tabbed.component';

@NgModule({
  imports: [ButtonOverlayTabbedComponent],
  exports: [ButtonOverlayTabbedComponent],
})
export class ButtonOverlayTabbedModule {}
