import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatBadgeModule } from '@angular/material/badge';
import { MatMenuTrigger } from '@angular/material/menu';
import { AALCommonComponentsModule } from '@enterprise-components/common';

import { EmptyStateComponent } from '../empty-state/empty-state.component';
import { SharedFormModule } from '../shared/shared-form.module';
import { SharedMaterialModule } from '../shared/shared-material.module';
import { SharedModule } from '../shared/shared.module';
import { ButtonOverlayTabbedComponent } from './button-overlay-tabbed.component';

describe('ButtonOverlayTabbedComponent', () => {
  let component: ButtonOverlayTabbedComponent;
  let fixture: ComponentFixture<ButtonOverlayTabbedComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        MatBadgeModule,
        EmptyStateComponent,
        ButtonOverlayTabbedComponent,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ButtonOverlayTabbedComponent);
    component = fixture.componentInstance;
    component.overlayMenuXPosition = 'before';
    component.overlayMenuYPosition = 'above';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call overlayTabbedPanel', () => {
    spyOn(component.overlayTabbedPanelOpen, 'emit');
    const $event = { value: 'sample data test' };
    component.overlayTabbedPanel($event);
    expect(component.overlayTabbedPanelOpen.emit).toHaveBeenCalled();
  });

  it('should call overLayTabbedListItem', () => {
    spyOn(component.overLayTabbedListItemClick, 'emit');
    const $event = { value: 'sample data test' };
    component.closeOnItemClick = true;
    component.overLayTabbedListItem($event);
    expect(component.overLayTabbedListItemClick.emit).toHaveBeenCalled();
  });

  it('should call openSelectedTab', () => {
    spyOn(component.selectedTab, 'emit');
    const $event = { value: 'sample data test' };
    component.openSelectedTab($event);
    expect(component.selectedTab.emit).toHaveBeenCalled();
  });

  it('should showAll', async () => {
    spyOn(component.showAllItems, 'emit');
    component.trigger = {
      closeMenu: (_) => {},
    } as never as MatMenuTrigger;
    component.showAll();
    expect(component.showAllItems.emit).toHaveBeenCalled();
  });

  it('should close the menu, when panelCloseOnItemClick is set ', async () => {
    const spy = spyOn(component.overLayMenuTabbed.close, 'emit');
    component.trigger = {
      closeMenu: (_) => {},
    } as never as MatMenuTrigger;
    component.panelCloseOnItemClick = true;
    expect(spy).toHaveBeenCalled();
  });

  it('should call menuClosedEvent', () => {
    spyOn(component.buttonOverlayTabbedClosedEvent, 'emit');
    const event = { value: 'sample data test' };
    component.menuClosedEvent(event);
    expect(component.buttonOverlayTabbedClosedEvent.emit).toHaveBeenCalledWith(event);
  });
});
