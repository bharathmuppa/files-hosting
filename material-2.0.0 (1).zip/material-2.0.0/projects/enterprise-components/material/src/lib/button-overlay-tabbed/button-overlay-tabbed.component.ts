import { NgClass, NgTemplateOutlet } from '@angular/common';
import { Component, EventEmitter, Input, Output, TemplateRef, ViewChild } from '@angular/core';
import { MatBadge } from '@angular/material/badge';
import { MatButton, MatIconButton } from '@angular/material/button';
import { MatDivider } from '@angular/material/divider';
import { MatIcon } from '@angular/material/icon';
import { MatMenu, MatMenuItem, MatMenuTrigger } from '@angular/material/menu';
import { MatProgressBar } from '@angular/material/progress-bar';
import { MatTab, MatTabContent, MatTabGroup } from '@angular/material/tabs';
import { MatToolbar, MatToolbarRow } from '@angular/material/toolbar';
import { MatTooltip } from '@angular/material/tooltip';
import { AALCommonButtonComponent, ButtonType } from '@enterprise-components/common';

@Component({
  selector: 'aal-button-overlay-tabbed',
  templateUrl: './button-overlay-tabbed.component.html',
  styleUrls: ['./button-overlay-tabbed.component.scss'],
  standalone: true,
  imports: [
    MatIconButton,
    MatBadge,
    MatMenuTrigger,
    MatTooltip,
    NgClass,
    NgTemplateOutlet,
    MatIcon,
    MatButton,

    MatMenu,
    MatToolbar,
    MatToolbarRow,
    MatProgressBar,
    MatTabGroup,
    MatTab,
    MatTabContent,
    MatDivider,
    MatMenuItem,
  ],
})
export class ButtonOverlayTabbedComponent extends AALCommonButtonComponent {
  @ViewChild(MatMenuTrigger) trigger: MatMenuTrigger;
  @ViewChild('overLayMenuTabbed', { static: false }) overLayMenuTabbed;
  @Input()
  closeOnItemClick: boolean;
  @Input()
  set panelCloseOnItemClick(val: boolean) {
    if (val) {
      this.overLayMenuTabbed.close.emit();
    }
  }
  @Input()
  disableClick: boolean;
  @Input()
  headerIcon: string;
  @Input()
  headerTitle: string;
  @Input()
  buttonLabel: string;
  @Input()
  overlayData: any;
  @Input()
  buttonIcon: string;
  @Input()
  buttonType: ButtonType;
  @Input()
  buttonTooltip: string;
  @Input()
  defaultItemImageURL: string;
  @Input()
  defaultSvgIcon: string;
  @Input()
  titleTemplateRef: TemplateRef<any>;
  @Input()
  mainDescriptionTemplateRef: TemplateRef<any>;
  @Input()
  subDescriptionTemplateRef: TemplateRef<any>;
  @Output()
  submitClick: EventEmitter<string> = new EventEmitter<string>();
  @Output()
  overlayTabbedPanelOpen: EventEmitter<string> = new EventEmitter<string>();
  @Input()
  overlayMenuXPosition: string;
  @Input()
  overlayMenuYPosition: string;
  @Input()
  itemTemplateRef: TemplateRef<any>;
  @Input()
  menuSortTemplateRef: TemplateRef<any>;
  @Input()
  largeAmountsTemplateRef: TemplateRef<any>;
  @Input()
  emptyStateTemplateRef: TemplateRef<any>;
  @Output()
  overLayTabbedListItemClick: EventEmitter<string> = new EventEmitter<string>();
  @Output()
  showAllItems: EventEmitter<void> = new EventEmitter<void>();
  @Output()
  selectedTab: EventEmitter<string> = new EventEmitter<string>();
  @Input()
  categoryName: string;
  @Input()
  categoryKey: string;
  @Input()
  subCategoryKey: string;
  @Input()
  itemKey: string;
  @Input()
  categoryItemsCount: string;
  @Input()
  subCategoryItemsCount: string;
  @Input()
  categoryItemName: string;
  @Input()
  subCategoryItemName: string;
  @Input()
  progressBar: boolean;
  @Input() set selectedIndex(value: number) {
    this.selectedTabIndex = value;

    if (this.enableTabSelection) {
      this.switchToTab = value;
    }
  }
  @Input()
  showAllForTabs: any[];
  @Input()
  sortMenuForTabs: any[];
  @Input()
  largeAmountsForTabs: any[];
  @Input()
  largeAmountsLength: number;
  @Input()
  defaultIconTempRef: TemplateRef<any>;
  @Input()
  isIconBorder: boolean;
  selectedTabIndex: any = 0;
  @ViewChild(MatTabGroup) tabGroup: MatTabGroup;
  @Output() selectedIndexChange = new EventEmitter<number>();
  @Input() enableTabSelection: boolean = true;
  switchToTab: number;
  @Output() buttonOverlayTabbedClosedEvent = new EventEmitter<any>();
  overlayTabbedPanel($event) {
    this.tabGroup.realignInkBar();
    this.overlayTabbedPanelOpen.emit($event);
  }

  overLayTabbedListItem($event, tab?) {
    $event.tabData = tab ? tab : '';
    this.overLayTabbedListItemClick.emit($event);
    if (this.closeOnItemClick) {
      this.overLayMenuTabbed.close.emit();
    }
  }

  openSelectedTab($event) {
    this.selectedTabIndex = $event.index;
    this.selectedTab.emit($event);
  }

  showAll() {
    this.trigger.closeMenu();
    this.showAllItems.emit();
  }

  // ECC-26014: Added to handle the tab index change
  onSelectedIndexChange($event) {
    this.switchToTab = $event;
    this.selectedTabIndex = $event.index;
    this.selectedIndexChange.emit($event);
  }

  // ECC-26014: Added to handle the mat menu close event
  menuClosedEvent(event) {
    this.buttonOverlayTabbedClosedEvent.emit(event);
  }
}
