import { CommonModule } from '@angular/common';
import {
  AfterContentInit,
  Component,
  ContentChildren,
  Input,
  QueryList,
  TemplateRef,
} from '@angular/core';

@Component({
  selector: 'aal-filter-panel',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './filter-panel.component.html',
  styleUrls: ['./filter-panel.component.scss'],
})
export class FilterPanelComponent implements AfterContentInit {
  @Input() sections: { header: string; content?: TemplateRef<any> }[] = [];

  @ContentChildren(TemplateRef) contentTemplates!: QueryList<TemplateRef<any>>;

  ngAfterContentInit() {
    this.sections.forEach((section, index) => {
      section.content = this.contentTemplates.toArray()[index] || null;
    });
  }
}
