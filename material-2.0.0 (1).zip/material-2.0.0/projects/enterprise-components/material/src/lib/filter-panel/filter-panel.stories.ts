import { UntypedFormBuilder } from '@angular/forms';
import { BrowserAnimationsModule, provideAnimations } from '@angular/platform-browser/animations';
import { applicationConfig, Meta, moduleMetadata, StoryObj } from '@storybook/angular';
import { InputTextComponent } from '../../public-api';
import { FilterPanelComponent } from './filter-panel.component';

const meta: Meta<FilterPanelComponent> = {
  title: 'Enterprise Components/Atoms/FilterPanel',
  component: FilterPanelComponent,
  decorators: [
    moduleMetadata({
      imports: [BrowserAnimationsModule, InputTextComponent],
    }),
    applicationConfig({
      providers: [provideAnimations()],
    }),
  ],
  argTypes: {},
};

export default meta;
type Story = StoryObj<FilterPanelComponent>;
const fb = new UntypedFormBuilder();
const control = fb.control('');

// Scenario 1: Default
export const Default: Story = {
  args: {},
  parameters: {
    docs: {
      description: {
        story: 'Displays the default filter panel with a header and content inside.',
      },
    },
  },
  render: (args) => ({
    props: {
      ...args,
      control: control,
      hideHelp: true,
      label1: 'Filter1',
      label2: 'Filter2',
      label3: 'Filter3',
      label4: 'Filter4',
      label5: 'Filter5',
      label6: 'Filter6',
      label7: 'Filter7',
      label8: 'Filter8',
      lockMode: 'EDIT',
      confirmToolBarNotApplicable: true,
    },
    template: `
      <aal-filter-panel
  [sections]="[{ header: 'Section 1' }, { header: 'Section 2' }, { header: 'Section 3' }]">
        <ng-template #section1>
          <aal-input-text
            [control]="control"
            [hideHelp]="hideHelp"
            [lockMode]="lockMode"
            [mode]="lockMode"
            [confirmToolBarNotApplicable]="confirmToolBarNotApplicable"
            [label]="label1">
          </aal-input-text>
          <aal-input-text
            [control]="control"
            [hideHelp]="hideHelp"
            [lockMode]="lockMode"
            [mode]="lockMode"
            [confirmToolBarNotApplicable]="confirmToolBarNotApplicable"
            [label]="label2">
          </aal-input-text>
          <aal-input-text
            [control]="control"
            [hideHelp]="hideHelp"
            [lockMode]="lockMode"
            [mode]="lockMode"
            [confirmToolBarNotApplicable]="confirmToolBarNotApplicable"
            [label]="label3">
          </aal-input-text>
          <aal-input-text
            [control]="control"
            [hideHelp]="hideHelp"
            [lockMode]="lockMode"
            [mode]="lockMode"
            [confirmToolBarNotApplicable]="confirmToolBarNotApplicable"
            [label]="label4">
          </aal-input-text>
        </ng-template>

        <ng-template #section2>
          <aal-input-text
            [control]="control"
            [hideHelp]="hideHelp"
            [lockMode]="lockMode"
            [mode]="lockMode"
            [confirmToolBarNotApplicable]="confirmToolBarNotApplicable"
            [label]="label5">
          </aal-input-text>
          <aal-input-text
            [control]="control"
            [hideHelp]="hideHelp"
            [lockMode]="lockMode"
            [mode]="lockMode"
            [confirmToolBarNotApplicable]="confirmToolBarNotApplicable"
            [label]="label6">
          </aal-input-text>
          <aal-input-text
            [control]="control"
            [hideHelp]="hideHelp"
            [lockMode]="lockMode"
            [mode]="lockMode"
            [confirmToolBarNotApplicable]="confirmToolBarNotApplicable"
            [label]="label7">
          </aal-input-text>
        </ng-template>

        <ng-template #section3>
          <aal-input-text
            [control]="control"
            [hideHelp]="hideHelp"
            [lockMode]="lockMode"
            [mode]="lockMode"
            [confirmToolBarNotApplicable]="confirmToolBarNotApplicable"
            [label]="label8">
          </aal-input-text>
        </ng-template>
      </aal-filter-panel>
    `,
  }),
};
