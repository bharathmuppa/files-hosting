/*
 * Public API Surface of material
 */

export * from './filter-panel.component';
