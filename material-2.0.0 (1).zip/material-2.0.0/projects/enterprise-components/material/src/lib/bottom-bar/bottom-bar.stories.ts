import { MatCheckboxModule } from '@angular/material/checkbox';
import { Meta, moduleMetadata, StoryObj } from '@storybook/angular';
import { ButtonComponent } from '../atoms/button/public-api';
import { AALBottomBarComponent } from './public-api';

const meta: Meta<AALBottomBarComponent> = {
  title: 'Enterprise Components/Molecules/Bottom Bar',
  tags: ['autodocs'],
  decorators: [
    moduleMetadata({
      imports: [ButtonComponent, MatCheckboxModule],
    }),
  ],
  component: AALBottomBarComponent,
};

export default meta;
type Story = StoryObj<AALBottomBarComponent>;

// 1. Simple Default
export const Default: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Displays the basic auto complete single implementation.',
      },
    },
  },
  render: (args) => ({
    template: `
      <aal-bottom-bar>
        <div left-buttons>
          <aal-button
            [name]="'LeftButton 1'"
            [type]="'outlined'"
          ></aal-button>
          <mat-divider vertical></mat-divider>
          <aal-button
            [name]="'LeftButton 2'"
            [type]="'outlined'"
          ></aal-button>
        </div>

        <div right-buttons>
          <aal-button
            [name]="'RightButton 1'"
          ></aal-button>
          <mat-divider vertical></mat-divider>
          <aal-button
            [name]="'RightButton 2'"
          ></aal-button>
          <mat-divider vertical></mat-divider>
          <aal-button
            [name]="'RightButton 3'"
          ></aal-button>
        </div>
      </aal-bottom-bar>
    `,
  }),
};

// 2. Check box and Right buttons
export const CheckBoxAndRightButtons: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Displays the basic auto complete single implementation.',
      },
    },
  },
  render: (args) => ({
    template: `
      <aal-bottom-bar>
        <div left-buttons>
          <mat-checkbox>
            Do Not Show Me This Message Again
          </mat-checkbox>
        </div>

        <div right-buttons>
          <aal-button
            [name]="'RightButton 1'"
          ></aal-button>
          <mat-divider vertical></mat-divider>
          <aal-button
            [name]="'RightButton 2'"
          ></aal-button>
        </div>
      </aal-bottom-bar>
    `,
  }),
};

// 3. Check box only
export const CheckBoxOnly: Story = {
  args: {
    configuration: 'Checkbox',
  },
  parameters: {
    docs: {
      description: {
        story: 'Displays the basic auto complete single implementation.',
      },
    },
  },
  render: (args) => ({
    template: `
      <aal-bottom-bar>
        <div left-buttons>
          <mat-checkbox>
            Do Not Show Me This Message Again
          </mat-checkbox>
        </div>
      </aal-bottom-bar>
    `,
  }),
};

// 4. Only Left Buttons
export const LeftButtonsOnly: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Displays the basic auto complete single implementation.',
      },
    },
  },
  render: (args) => ({
    template: `
      <aal-bottom-bar>
        <div left-buttons>
          <aal-button
            [name]="'LeftButton 1'"
            [type]="'outlined'"
          ></aal-button>
          <mat-divider vertical></mat-divider>
          <aal-button
            [name]="'LeftButton 2'"
            [type]="'outlined'"
          ></aal-button>
        </div>
      </aal-bottom-bar>
    `,
  }),
};

// 4. Only Right Buttons
export const RightButtonsOnly: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Displays the basic auto complete single implementation.',
      },
    },
  },
  render: (args) => ({
    template: `
      <aal-bottom-bar>
        <div right-buttons>
          <aal-button
            [name]="'RightButton 1'"
            [type]="'outlined'"
          ></aal-button>
          <mat-divider vertical></mat-divider>
          <aal-button
            [name]="'RightButton 2'"
            [type]="'outlined'"
          ></aal-button>
        </div>
      </aal-bottom-bar>
    `,
  }),
};
