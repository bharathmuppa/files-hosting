/*
 * Public API Surface of material
 */

export * from './bottom-bar.component';
