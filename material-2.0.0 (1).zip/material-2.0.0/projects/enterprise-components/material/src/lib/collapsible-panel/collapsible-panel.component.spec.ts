import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatBadgeModule } from '@angular/material/badge';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AALCommonComponentsModule } from '@enterprise-components/common';
import { ButtonIconOutlinedModule } from '../button-icon-outlined/button-icon-outlined.module';
import { InputTextComponent } from '../input-text/input-text.component';
import { SharedFormModule } from '../shared/shared-form.module';
import { SharedMaterialModule } from '../shared/shared-material.module';
import { SharedModule } from '../shared/shared.module';
import { CollapsiblePanelComponent } from './collapsible-panel.component';

describe('CollapsiblePanelComponent', () => {
  let component: CollapsiblePanelComponent;
  let fixture: ComponentFixture<CollapsiblePanelComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        MatBadgeModule,
        InputTextComponent,
        ButtonIconOutlinedModule,
        BrowserAnimationsModule,
        CollapsiblePanelComponent,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CollapsiblePanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit collapsibleButton, when buttonClick is triggered', () => {
    const spy = spyOn(component.collapsibleButton, 'emit');
    component.buttonClick({});
    expect(spy).toHaveBeenCalled();
  });

  it('should emit acceptChangesOn, when onAcceptChanges is triggered', () => {
    const spy = spyOn(component.acceptChangesOn, 'emit');
    component.onAcceptChanges({});
    expect(spy).toHaveBeenCalled();
  });

  it('should emit rejectChangesOn, when onRejectChanges is triggered', () => {
    const spy = spyOn(component.rejectChangesOn, 'emit');
    component.onRejectChanges({});
    expect(spy).toHaveBeenCalled();
  });
});
