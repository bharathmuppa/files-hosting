import { NgModule } from '@angular/core';
import { CollapsiblePanelComponent } from './collapsible-panel.component';

@NgModule({
  imports: [CollapsiblePanelComponent],
  exports: [CollapsiblePanelComponent],
})
export class CollapsiblePanelModule {}
