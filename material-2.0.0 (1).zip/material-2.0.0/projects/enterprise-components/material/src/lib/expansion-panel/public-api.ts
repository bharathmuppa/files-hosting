/*
 * Public API Surface of material
 */

export * from './expansion-panel.component';
export * from './expansion-panel.module';
