import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { MatButton } from '@angular/material/button';
import {
  MatExpansionPanel,
  MatExpansionPanelDescription,
  MatExpansionPanelHeader,
  MatExpansionPanelTitle,
} from '@angular/material/expansion';
import { MatProgressSpinner } from '@angular/material/progress-spinner';
import { MatTooltip } from '@angular/material/tooltip';
import { Info, InfoLevels } from '@enterprise-components/common';
import { OverlayCardAlertComponent } from '../overlay-card-alert/overlay-card-alert.component';
import { OverlayCardHelpComponent } from '../overlay-card-help/overlay-card-help.component';

@Component({
  selector: 'aal-expansion-panel',
  templateUrl: './expansion-panel.component.html',
  styleUrls: ['./expansion-panel.component.scss'],
  standalone: true,
  imports: [
    MatExpansionPanel,
    MatExpansionPanelHeader,
    MatExpansionPanelTitle,

    OverlayCardHelpComponent,
    MatProgressSpinner,
    OverlayCardAlertComponent,
    MatTooltip,
    MatButton,
    MatExpansionPanelDescription,
  ],
})
export class ExpansionPanelComponent implements OnInit {
  @Input()
  header: string;
  @Input()
  isExpanded: boolean;
  @Input()
  headerCost?: string;
  @Input()
  headerHelp: Info | string;
  @Input()
  buttonLabel: string;
  @Input()
  showButton: boolean;
  @Input()
  buttonTooltip: string;
  @Input()
  disableButton: boolean;
  @Input()
  expansionDisabled: boolean;
  @Input()
  set headerError(value: Info | string) {
    if (value) {
      this.headerErrorDetails = value;
      this.headerErrorTitleColor = this.getColor();
    } else {
      this.headerErrorDetails = '';
      this.headerErrorTitleColor = '';
    }
  }
  @Input()
  error: Info | string;
  @Input()
  hideHeaderHelp?: boolean;
  @Input()
  isDataLoading: boolean;
  @Input()
  headerCaption: string;
  @Output()
  buttonClick: EventEmitter<void> = new EventEmitter<void>();
  headerErrorDetails: Info | string;
  headerErrorTitleColor: string;
  @Output()
  expansionPanelToggleState: EventEmitter<boolean> = new EventEmitter<boolean>();
  @ViewChild(MatExpansionPanel) expansionPanel: MatExpansionPanel;

  ngOnInit() {
    if (this.headerHelp && typeof this.headerHelp === 'string') {
      this.headerHelp = new Info(this.headerHelp);
    }
    if (this.error && typeof this.error === 'string') {
      this.error = new Info(this.error);
    }
  }

  onButtonClick($event): void {
    this.buttonClick.emit();
    $event.stopPropagation();
  }

  onExpansionPanelToggle() {
    if (this.expansionDisabled) {
      return;
    }
    this.isExpanded = !this.isExpanded;
    if (this.isExpanded) {
      this.expansionPanel.open();
      this.expansionPanelToggleState.emit(true);
    } else {
      this.expansionPanel.close();
      this.expansionPanelToggleState.emit(false);
    }
  }

  getColor(): string {
    if (
      typeof this.headerErrorDetails !== 'string' &&
      this.headerErrorDetails.level === InfoLevels.ERROR
    ) {
      return '#e00';
    } else {
      return '#f0ab00';
    }
  }
}
