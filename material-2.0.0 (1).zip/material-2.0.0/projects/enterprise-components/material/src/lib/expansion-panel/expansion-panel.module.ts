import { NgModule } from '@angular/core';
import { ExpansionPanelComponent } from './expansion-panel.component';

@NgModule({
  imports: [ExpansionPanelComponent],
  exports: [ExpansionPanelComponent],
})
export class ExpansionPanelModule {}
