import { NgModule } from '@angular/core';
import { ButtonToggleComponent } from './button-toggle.component';

@NgModule({
  imports: [ButtonToggleComponent],
  exports: [ButtonToggleComponent],
})
export class ButtonToggleModule {}
