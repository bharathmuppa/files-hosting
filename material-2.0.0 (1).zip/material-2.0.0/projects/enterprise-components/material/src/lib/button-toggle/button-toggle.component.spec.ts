import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { UntypedFormControl } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AALCommonComponentsModule, Info } from '@enterprise-components/common';

import { OverlayCardErrorModule } from '../overlay-card-alert/overlay-card-alert.module';
import { OverlayCardHelpModule } from '../overlay-card-help/overlay-card-help.module';
import { SharedFormModule } from '../shared/shared-form.module';
import { SharedMaterialModule } from '../shared/shared-material.module';
import { ToolbarConfirmModule } from '../toolbar-confirm/toolbar-confirm.module';
import { ButtonToggleComponent } from './button-toggle.component';

describe('ButtonToggleComponent', () => {
  let component: ButtonToggleComponent;
  let fixture: ComponentFixture<ButtonToggleComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        OverlayCardHelpModule,
        OverlayCardErrorModule,
        ToolbarConfirmModule,
        BrowserAnimationsModule,
        ButtonToggleComponent,
      ],
    })
      .compileComponents()
      .then(() => {});
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ButtonToggleComponent);
    component = fixture.componentInstance;
    component.help = new Info('help title', 'help message', '', '', '');
    component.control = new UntypedFormControl('');
    component.options = [
      { name: 'abc', label: 'Abc', sequence: 1, isDescriptionAvailable: true },
      { name: 'xyz', label: 'Xyz', sequence: 2, isDescriptionAvailable: false },
    ];
    jasmine.clock().uninstall();
    fixture.detectChanges();
  });

  it('should create component', () => {
    expect(component).toBeTruthy();
  });

  it('toggle button layout should be column if there are more than 3 items', () => {
    delete component.layout;
    component.options = new Array(4);
    component.setLayout();
    expect(component.layout).toBe('column');
  });

  it('should set initial values on component initiation', () => {
    component.ngOnInit();
    expect(component.mode).toBe(component.modes.READ);
    expect(component.useDefaultHelpDisplay).toBe(true);
  });

  it('mode should be changed to Edit on click of text in read mode', () => {
    const el = fixture.nativeElement.querySelector('.aal-read-section');
    el.dispatchEvent(new Event('click'));
    expect(component.mode).toBe(component.modes.EDIT);
  });

  it('If no description field is available for a button , on click of button, it should accept changes and show read mode', () => {
    const el = fixture.nativeElement.querySelector('.aal-read-section');
    el.dispatchEvent(new Event('click'));
    fixture.detectChanges();
    const buttonEl = fixture.nativeElement.querySelectorAll('button')[1];
    buttonEl.dispatchEvent(new Event('click'));
    fixture.detectChanges();
    expect(component.mode).toBe(component.modes.READ);
  });

  it('should return, when onButtonToggleBlur is triggered and related target is one of the button toggle options', () => {
    component.hyphenatedID = 'test';
    const retValue = component.onButtonToggleBlur({
      relatedTarget: { id: component.hyphenatedID + '_button_toggle_1' },
    });
    expect(retValue).toEqual(undefined);
  });

  it('should set appropriate mode, when resetMode is triggered and related target is not one of the button toggle options', () => {
    component.resetMode({ relatedTarget: null });
    expect(component.mode).toBe('READ');
  });

  it('should set appropriate mode, when onButtonToggleBlur is triggered, no relatedTarget exists or related target is not one of the button toggle options', () => {
    component.onButtonToggleBlur({ relatedTarget: null });
    expect(component.mode).toBe('READ');
  });

  it('should set appropriate mode, when onKeyUp is triggered and ESC key is pressed', () => {
    component.onKeyUp({
      key: 'Escape',
      currentTarget: {
        children: [],
      },
    });
    expect(component.mode).toBe('READ');
  });

  it('should focus on the next option, when onKeyUp is triggered and ArrowRight key is pressed', () => {
    const spy = spyOn(component, 'navigateOptions').and.callThrough();
    const event = {
      key: 'ArrowRight',
      currentTarget: {
        children: [
          {
            classList: {
              contains: () => {
                return true;
              },
              add: () => {},
            },
            focus: () => {},
          },
          {
            classList: {
              contains: () => {
                return false;
              },
              add: () => {},
            },
            focus: () => {},
          },
        ],
      },
    };
    component.onKeyUp(event);
    expect(spy).toHaveBeenCalled();
  });

  it('should focus on the previous option, when onKeyUp is triggered and ArrowLeft key is pressed', () => {
    const spy = spyOn(component, 'navigateOptions').and.callThrough();
    const event = {
      key: 'ArrowLeft',
      currentTarget: {
        children: [
          {
            classList: {
              contains: () => {
                return false;
              },
              add: () => {},
            },
            focus: () => {},
          },
          {
            classList: {
              contains: () => {
                return true;
              },
              add: () => {},
            },
            focus: () => {},
          },
        ],
      },
    };
    component.onKeyUp(event);
    expect(spy).toHaveBeenCalled();
  });

  it('should select the appropriate option, when onKeyUp is triggered and an alphabet key is pressed', () => {
    const event = {
      key: 'S',
      currentTarget: {
        children: [
          {
            innerText: 'Test',
          },
          {
            innerText: 'Select Option',
            children: [
              {
                click: () => {},
              },
            ],
          },
        ],
      },
    };
    const spy = spyOn(event.currentTarget.children[1].children[0], 'click');
    component.onKeyUp(event);
    expect(spy).toHaveBeenCalled();
  });

  it('should reset the control, when onKeyUp is triggered, the control has a value and C key is pressed', () => {
    const spy = spyOn(component, 'resetControl');
    component.control = new UntypedFormControl('Opt 1');
    component.onKeyUp({
      key: 'C',
      currentTarget: {
        children: [
          {
            innerText: 'Test',
          },
          {
            innerText: 'Select Option',
          },
        ],
      },
    });
    expect(spy).toHaveBeenCalled();
  });

  it('should focus on the button toggle, when onClick is triggered', () => {
    component.buttonToggle = {
      focus: () => {},
    };
    const spy = spyOn(component.buttonToggle, 'focus');
    jasmine.clock().install();
    component.onClick();
    jasmine.clock().tick(300);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });
});
