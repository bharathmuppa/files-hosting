import { NgClass } from '@angular/common';
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonToggle, MatButtonToggleGroup } from '@angular/material/button-toggle';
import { MatIcon } from '@angular/material/icon';
import { MatProgressSpinner } from '@angular/material/progress-spinner';
import { MatTooltip } from '@angular/material/tooltip';
import { AALFixedInputFormControlComponent, Modes } from '@enterprise-components/common';
import { ButtonIconModule } from '../button-icon/button-icon.module';
import { AALCommonModule } from '../common/common.module';
import { OverlayCardErrorModule } from '../overlay-card-alert/overlay-card-alert.module';
import { OverlayCardHelpModule } from '../overlay-card-help/overlay-card-help.module';

/**
 * A button toggle component that extends AALFixedInputFormControlComponent.
 * Provides interactive toggle options with various modes (READ, EDIT, etc.)
 * and supports keyboard navigation and focus management.
 */
@Component({
  selector: 'aal-button-toggle',
  templateUrl: './button-toggle.component.html',
  styleUrls: ['./button-toggle.component.scss'],
  standalone: true,
  imports: [
    OverlayCardHelpModule,
    MatProgressSpinner,
    MatTooltip,
    MatButtonToggleGroup,
    FormsModule,
    ReactiveFormsModule,
    MatButtonToggle,
    MatIcon,
    ButtonIconModule,
    NgClass,
    AALCommonModule,
    OverlayCardErrorModule,
  ],
})
export class ButtonToggleComponent extends AALFixedInputFormControlComponent implements OnInit {
  @Input() layout: string; // Defines the layout of the toggle group (e.g., 'row' or 'column').
  @Input() isOptionIcon: string; // Indicates if options are represented by icons.
  @Input() align: string; // Alignment property (e.g., 'horizontal', 'vertical').

  @ViewChild('toggle') buttonToggle; // Reference to the MatButtonToggleGroup element.

  /**
   * Lifecycle hook to initialize the component.
   * Sets the layout and invokes the parent class's initialization logic.
   */
  ngOnInit() {
    this.setLayout();
    super.ngOnInit();
  }

  /**
   * Configures the layout of the toggle group based on the number of options.
   * Defaults to 'column' if options exceed 3; otherwise, 'row'.
   */
  setLayout() {
    if (!this.layout && this.options) {
      this.layout = this.options.length > 3 ? 'column' : 'row';
    }
  }

  /**
   * Handles the blur event for the button toggle group.
   * Resets the mode to default if focus moves away to an unrelated element.
   * @param event - The blur event triggered by focus loss.
   */
  onButtonToggleBlur(event) {
    if (
      event &&
      event.relatedTarget &&
      event.relatedTarget.id &&
      event.relatedTarget.id.includes(this.hyphenatedID)
    ) {
      // Do nothing if focus remains within the same toggle group.
      return;
    } else if (
      event &&
      (!event.relatedTarget ||
        (event.relatedTarget && !event.relatedTarget.id) ||
        (event.relatedTarget &&
          event.relatedTarget.id &&
          !event.relatedTarget.id.includes(this.hyphenatedID)))
    ) {
      // Reset mode to default when focus moves to unrelated elements.
      this.mode = this.lockMode ? this.lockMode : Modes.READ;
      this.triggerAcceptChanges();
    }
  }

  /**
   * Handles keyup events for keyboard navigation and shortcuts.
   * Supports navigating options with arrow keys, clearing values with 'C',
   * and selecting options by typing their starting letters.
   * @param event - The keyup event triggered by user input.
   */
  onKeyUp(event) {
    const regex = new RegExp('^([A-Z])$');
    const children = Array.from(event.currentTarget.children) as any[];
    const key = event.key.toUpperCase();

    if (event.key === 'Escape') {
      // Reset mode to READ when the Escape key is pressed.
      this.mode = this.lockMode ? this.lockMode : Modes.READ;
    } else if (event.key === 'ArrowRight') {
      // Navigate to the next option when the Right Arrow key is pressed.
      this.navigateOptions(children, 'RIGHT');
    } else if (event.key === 'ArrowLeft') {
      // Navigate to the previous option when the Left Arrow key is pressed.
      this.navigateOptions(children, 'LEFT');
    } else if (regex.test(key)) {
      if (key === 'C' && this.control.value) {
        // Clear the control value when 'C' is pressed.
        this.resetControl();
      } else {
        // Select an option based on the typed letter.
        for (const child of children) {
          const firstChar = child.innerText.substring(0, 1).toUpperCase();
          if (firstChar === key) {
            child.children[0].click();
            break;
          }
        }
      }
    }
  }

  /**
   * Navigates between toggle options using arrow keys.
   * @param children - The list of toggle button elements.
   * @param direction - The navigation direction ('LEFT' or 'RIGHT').
   */
  navigateOptions(children, direction) {
    let currentIndex = 0;
    let nextIndex = 0;

    // Identify the currently focused button and calculate the next index.
    for (const child of children) {
      if (child.classList.contains('cdk-focused')) {
        currentIndex = children.indexOf(child);
        nextIndex =
          currentIndex === 0 && direction === 'LEFT'
            ? children.length - 1
            : currentIndex === children.length - 1 && direction === 'RIGHT'
              ? 0
              : direction === 'LEFT'
                ? currentIndex - 1
                : currentIndex + 1;
      }
    }

    // Set focus and styles for the next button.
    children[nextIndex].tabIndex = 0;
    children[nextIndex].focus();
    children[nextIndex].classList.add('cdk-focused');
    children[nextIndex].classList.add('cdk-keyboard-focused');
  }

  /**
   * Resets the mode when focus is lost from the 'Clear Selection' button.
   * Ensures the mode resets only if focus moves to unrelated elements.
   * @param event - The blur event triggered by focus loss.
   */
  resetMode(event) {
    if (
      event &&
      (!event.relatedTarget ||
        !(event.relatedTarget.id && event.relatedTarget.id.includes(this.hyphenatedID)))
    ) {
      this.mode = this.lockMode ? this.lockMode : Modes.READ; // Reset mode to default.
      this.triggerAcceptChanges(); // Notify changes.
    }
  }

  /**
   * Handles click events on the component.
   * Focuses the toggle group after a slight delay to ensure proper interaction.
   */
  onClick() {
    super.onClick();
    setTimeout(() => {
      if (this.buttonToggle) {
        this.buttonToggle.focus(); // Focus the toggle group element.
      }
    }, 200);
  }
}
