import { CommonModule } from '@angular/common';
import { ElementRef, signal } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { UntypedFormControl, Validators } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AALCommonComponentsModule, AALUtil } from '@enterprise-components/common';

import { DatePickerWeekComponent } from '../date-picker-week/date-picker-week.component';
import { SharedFormModule } from '../shared/shared-form.module';
import { SharedMaterialModule } from '../shared/shared-material.module';
import { SharedModule } from '../shared/shared.module';
import { DatePickerSelectComponent } from './date-picker-select.component';

describe('DatePickerSelectComponent', () => {
  let component: DatePickerSelectComponent;
  let fixture: ComponentFixture<DatePickerSelectComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        SharedMaterialModule,
        SharedFormModule,
        AALCommonComponentsModule,
        SharedModule,
        MatDatepickerModule,
        BrowserAnimationsModule,
        DatePickerSelectComponent,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatePickerSelectComponent);
    component = fixture.componentInstance;
    component.control = new UntypedFormControl(
      new Date(),
      Validators.compose([Validators.required]),
    );
    fixture.detectChanges();
    jasmine.clock().uninstall();
  });

  it('should create ', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize component (ngOnInit) and default date selected should to current date', () => {
    const today = new Date();
    component.control.setValue(today);
    component.ngOnInit();
    expect(component.datePickerSelection).toEqual(AALUtil.setDateDefaultTime(today));
  });

  it('should set isSelectedOptionAvailable as false, when ngAfterViewInit is triggered and endDate does not exist', () => {
    const today = new Date();
    component.control.setValue(today);
    component.type = signal('range') as unknown as typeof component.type;
    component.ngAfterViewInit();
    expect(component.isSelectedOptionAvailable).toEqual(false);
  });

  it('should set isSelectedOptionAvailable as true, when ngAfterViewInit is triggered and endDate exists', () => {
    const today = new Date(2021, 6, 17);
    component.control.setValue({ end: today });
    component.type = signal('range') as unknown as typeof component.type;
    component.endDateForm = [{ date: today, name: '' }];
    component.ngAfterViewInit();
    expect(component.isSelectedOptionAvailable).toEqual(true);
  });

  it('should set selectedValue, when changeDateFormat trigger with dateType as noStartEnd', () => {
    component.type = signal('range') as unknown as typeof component.type;
    component.today = new Date(2021, 6);
    component.endDateForm = [{ date: new Date(2021, 6), name: '' }];
    component.changeDateFormat(
      {
        value: new Date(2021, 6),
      },
      'noStartEnd',
    );
    expect(component.selectedValue).toEqual(new Date(2021, 6));
  });

  it('should set beginDate, when changeDateFormat trigger with dateType as start', () => {
    component.type = signal('range') as unknown as typeof component.type;
    component.changeDateFormat(
      {
        value: new Date(2021, 6),
      },
      'start',
    );
    expect(component.beginDate).toEqual(new Date(2021, 6));
  });

  it('should set datePickerSelection, when changeDateFormat trigger with dateType as end', () => {
    component.type = signal('range') as unknown as typeof component.type;
    component.beginDate = new Date(2021, 6);
    component.changeDateFormat(
      {
        value: new Date(2021, 7),
      },
      'end',
    );
    expect(component.datePickerSelection).toEqual({
      begin: new Date(2021, 6),
      end: new Date(2021, 7),
    });
  });

  it('should set control value, when changeDateFormat trigger with dateType as noStartEnd', () => {
    component.changeDateFormat(
      {
        value: new Date(2021, 7),
      },
      'noStartEnd',
    );
    expect(component.control.value).toEqual(new Date(2021, 7));
  });

  it('should set null value to control when ChangeDateFormat is trigger', () => {
    component.changeDateFormat({}, 'start');
    fixture.detectChanges();
    expect(component.control.value).toEqual('');
  });

  it('should verify selectedValue when control is set with valid Date Object for Begin and End', () => {
    component.type = signal('range') as unknown as typeof component.type;
    component.control.setValue({ begin: new Date(), end: new Date() });
    component.ngOnInit();
    expect(new Date(component.selectedValue).getDate()).toBe(new Date().getDate());
  });

  it('should call onChange of super Component', () => {
    spyOn(DatePickerWeekComponent.prototype, 'onChange');
    component.type = signal('range') as unknown as typeof component.type;
    component.control.setValue({ begin: new Date(), end: new Date() });
    component.onChange(new Event(''));
    expect(new Date(component.control.value.begin).getDate()).toBe(new Date().getDate());
    expect(DatePickerWeekComponent.prototype.onChange).toHaveBeenCalled();
  });

  it('should set control current date when type is null when onChange is trigger', () => {
    component.type = signal('') as unknown as typeof component.type;
    component.onChange(new Event(''));
    expect(new Date(component.control.value).getDate()).toBe(new Date().getDate());
  });

  it('should set current date when type is set when ChangeDateFormat is trigger', () => {
    component.type = signal('range') as unknown as typeof component.type;
    component.today = new Date();
    const event = { value: new Date() };
    component.changeDateFormat(event, 'start');
    expect(new Date(component.selectedValue).getDate()).toBe(new Date().getDate());
  });

  it('should open optionsPanel, when onClick is triggered', () => {
    component.type = signal('range') as unknown as typeof component.type;
    component.selectField = {
      trigger: new ElementRef<any>({
        click: () => {},
      }),
    };
    const spy = spyOn(component.selectField.trigger.nativeElement, 'click').and.callFake(() => {});
    jasmine.clock().install();
    component.onClick();
    jasmine.clock().tick(300);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });
});
