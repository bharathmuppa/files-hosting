import { MatNativeDateModule } from '@angular/material/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Modes } from '@enterprise-components/common';
import { moduleMetadata, type Meta, type StoryObj } from '@storybook/angular';
import { fn } from '@storybook/test';
import { PassCustomControl } from '../../../.storybook/utils';
import { DatePickerSelectComponent } from './date-picker-select.component';
const meta: Meta<DatePickerSelectComponent> = {
  title: 'Enterprise Components/Molecules/Date Picker Select',
  component: DatePickerSelectComponent,
  decorators: [
    moduleMetadata({
      imports: [MatNativeDateModule, BrowserAnimationsModule],
    }),
  ],
};

export default meta;
type Story = StoryObj<DatePickerSelectComponent>;

export const Default: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    ID: 'datepicker_select_range_1',
    isPastDateRange: true,
    showHyphenForValues: [null, ''],
    label: 'DatePicker Select',
    placeholder: 'Datepicker select(editable)',
    type: 'range',
    mode: Modes.READ,
  },
  render: PassCustomControl,
};

export const DatePickerModeProtected: Story = {
  args: {
    acceptChanges: fn(),
    rejectChanges: fn(),
    ID: 'Datepicker select',
    mode: Modes.PRIVATE,
    showHyphenForValues: [null, ''],
    label: 'Datepicker Select',
    placeholder: 'Datepicker select(editable)',
    type: 'range',
  },
  render: PassCustomControl,
};
