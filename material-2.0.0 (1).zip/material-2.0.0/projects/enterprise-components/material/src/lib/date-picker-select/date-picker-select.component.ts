import { DatePipe, formatDate, NgClass } from '@angular/common';
import { AfterViewInit, Component, Input, input, OnInit, Renderer2 } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormControl } from '@angular/forms';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
  MatNativeDateModule,
  MatOption,
} from '@angular/material/core';
import {
  MatDatepicker,
  MatDatepickerInput,
  MatDatepickerModule,
  MatDatepickerToggle,
  MatDatepickerToggleIcon,
  MatDateRangeInput,
  MatDateRangePicker,
  MatEndDate,
  MatStartDate,
} from '@angular/material/datepicker';
import { MatError, MatFormField, MatLabel, MatSuffix } from '@angular/material/form-field';
import { MatInput } from '@angular/material/input';
import { MatProgressSpinner } from '@angular/material/progress-spinner';
import { MatSelect } from '@angular/material/select';
import { MatTooltip } from '@angular/material/tooltip';
import { AALCommonModule, AALUtil, HistoryService } from '@enterprise-components/common';
import { DatePickerWeekComponent } from '../date-picker-week/date-picker-week.component';
import { generateMatDateFormats } from '../date-picker/date-picker.utils';
import { DynamicDateAdapter } from '../date-picker/dynamic-date-adapter.service';
import { OverlayCardErrorModule } from '../overlay-card-alert/overlay-card-alert.module';
import { OverlayCardHelpModule } from '../overlay-card-help/overlay-card-help.module';

@Component({
  selector: 'aal-date-picker-select',
  templateUrl: './date-picker-select.component.html',
  styleUrls: ['./date-picker-select.component.scss'],
  standalone: true,
  imports: [
    OverlayCardHelpModule,
    MatProgressSpinner,
    MatFormField,
    MatLabel,
    MatSelect,
    FormsModule,
    MatOption,
    MatInput,
    MatDatepickerInput,
    ReactiveFormsModule,
    MatDatepickerToggle,
    MatSuffix,
    MatDatepickerToggleIcon,
    MatDatepicker,
    MatDateRangeInput,
    MatStartDate,
    MatEndDate,
    MatDateRangePicker,
    AALCommonModule,
    MatError,
    MatTooltip,
    NgClass,
    OverlayCardErrorModule,
    DatePipe,

    MatNativeDateModule,
    MatDatepickerModule,
  ],
  providers: [
    { provide: MAT_DATE_LOCALE, useValue: 'en-GB' }, // Set the locale to English (with Monday as the first day)
    {
      provide: DateAdapter,
      useFactory: () => {
        const adapter = new DynamicDateAdapter();
        adapter.setStartOfWeek(1); // Default to Monday
        return adapter;
      },
    },
    { provide: MAT_DATE_FORMATS, useValue: generateMatDateFormats() },
  ],
})
export class DatePickerSelectComponent
  extends DatePickerWeekComponent
  implements OnInit, AfterViewInit
{
  beginDate: Date;
  selectedValue: any;
  dateRangeFormat: string;
  isSelectedOptionAvailable: boolean;
  onChangeDateDisableOptionAvailable: boolean;
  type = input<string>(undefined);

  get control() {
    return this.frmControl;
  }

  // TODO: Didn't change to signals based input because frmControl is from AALCommonFormControlComponent
  // Before changing to signals here, we need to change in AALCommonFormControlComponent
  @Input()
  set control(val: UntypedFormControl) {
    this.frmControl = val;
    if (val) {
      this.oldValue =
        typeof val.value === 'object' ? JSON.parse(JSON.stringify(val.value)) : val.value;
    }
    if (!val.value) {
      this.selectedValue = null;
    }
  }

  constructor(renderer: Renderer2, historyService: HistoryService) {
    super(renderer, historyService);
  }

  ngOnInit() {
    if (this.control && this.control.value) {
      if (this.type() === 'range' && this.control.value) {
        this.datePickerSelection = this.control.value;
        const controlEndDate = this.control.value.end
          ? new Date(this.control.value.end)
          : new Date();
        this.selectedValue = controlEndDate;
        this.isSelectedOptionAvailable = false;
        this.onChangeDateDisableOptionAvailable = false;
      } else {
        this.selectedValue = AALUtil.setDateDefaultTime(this.control.value);
        if (!this.listValueSelected) {
          this.datePickerSelection = this.selectedValue;
        }
      }
    }
    super.ngOnInit();
  }

  ngAfterViewInit() {
    if (this.type() === 'range' && this.control && this.control.value) {
      const controlEndDate = this.control.value.end ? new Date(this.control.value.end) : new Date();
      const endDate = this.endDateForm.find(
        (item) =>
          item.date.getDate() === controlEndDate.getDate() &&
          item.date.getMonth() === controlEndDate.getMonth() &&
          item.date.getFullYear() === controlEndDate.getFullYear(),
      );
      if (endDate) {
        this.onChangeDateDisableOptionAvailable = true;
        this.isSelectedOptionAvailable = true;
        this.selectedValue = endDate.date;
      } else {
        this.isSelectedOptionAvailable = false;
        this.selectedValue = this.control.value;
      }
    }
  }

  onChange($event?: Event) {
    if (this.type() === 'range' && this.control.value) {
      const isoDateObject = {
        begin: AALUtil.getDateInISOFormat(this.control.value.begin),
        end: AALUtil.getDateInISOFormat(this.control.value.end),
      };
      this.control.setValue(isoDateObject);
    } else {
      this.control.setValue(AALUtil.getDateInISOFormat(this.control.value));
    }
    this.onChangeDateDisableOptionAvailable = true;
    super.onChange($event);
  }

  changeDateFormat(event, dateType) {
    if (event.value) {
      if (this.type() === 'range' && !event.value.begin && dateType === 'noStartEnd') {
        this.control.setValue({
          begin: this.isPastDateRange ? event.value : this.today,
          end: this.isPastDateRange ? this.today : event.value,
        });
        this.datePickerSelection = this.control.value;
        const endDate = this.endDateForm.find(
          (item) =>
            item.date.getDate() === event.value.getDate() &&
            item.date.getMonth() === event.value.getMonth() &&
            item.date.getFullYear() === event.value.getFullYear(),
        );
        this.selectedValue = endDate.date;
      } else {
        if (dateType === 'start') {
          this.beginDate = event.value;
        } else if (dateType === 'end') {
          this.control.setValue({
            begin: this.beginDate,
            end: event.value,
          });
          this.selectedValue = this.control.value;
          this.datePickerSelection = this.control.value;
        } else {
          this.control.setValue(event.value);
          this.selectedValue = this.control.value;
          this.datePickerSelection = this.control.value;
        }
        const format = 'MMM dd, YYYY';
        const locale = 'en-US';
        if (this.datePickerSelection && this.datePickerSelection.begin) {
          this.dateRangeFormat =
            formatDate(this.datePickerSelection.begin, format, locale) +
            ' — ' +
            formatDate(this.datePickerSelection.end, format, locale);
        }
      }
    } else {
      this.control.setValue('');
    }
  }

  onClick(): void {
    super.setModeToEdit();
    if (this.type() === 'range') {
      setTimeout(() => {
        if (this.selectField && this.selectField.trigger) {
          this.selectField.trigger.nativeElement.click();
        }
      }, 100);
    }
  }
}
