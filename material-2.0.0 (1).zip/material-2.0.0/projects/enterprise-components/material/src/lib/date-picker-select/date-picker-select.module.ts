import { NgModule } from '@angular/core';
import { DatePickerSelectComponent } from './date-picker-select.component';

@NgModule({
  imports: [DatePickerSelectComponent],
  exports: [DatePickerSelectComponent],
})
export class DatePickerSelectModule {}
