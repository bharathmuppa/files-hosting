import { NgModule } from '@angular/core';
import { DatePickerWeekComponent } from './date-picker-week.component';

@NgModule({
  imports: [DatePickerWeekComponent],
  exports: [DatePickerWeekComponent],
})
export class DatePickerWeekModule {}
