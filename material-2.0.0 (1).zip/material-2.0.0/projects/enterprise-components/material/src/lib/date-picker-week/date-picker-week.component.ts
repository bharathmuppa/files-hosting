import { NgClass } from '@angular/common';
import { Component, ElementRef, Renderer2, ViewChild } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { MatDatepicker } from '@angular/material/datepicker';
import { AALDatePickerFormControlComponent, HistoryService } from '@enterprise-components/common';
import { DateTime } from 'luxon';

@Component({
  selector: 'aal-date-picker-week',
  templateUrl: './date-picker-week.component.html',
  styleUrls: ['./date-picker-week.component.scss'],
  standalone: true,
  imports: [NgClass],
})
export class DatePickerWeekComponent extends AALDatePickerFormControlComponent {
  weeksList: Array<number>;
  @ViewChild('picker', { static: false }) datepicker: MatDatepicker<any>;
  @ViewChild('weekSection', { static: false }) weekSection: ElementRef;
  dateValue: Date;
  startDay: number;

  constructor(
    public renderer: Renderer2,
    historyService: HistoryService,
  ) {
    super(historyService);
    this.control = new UntypedFormControl();
  }

  datePickerOpened() {
    this.dateValue = this.control.value;
    this.initializeDatePicker();
    this.calculateWeeks();
    this.addCalenderEvents();
  }

  initializeDatePicker() {
    setTimeout(() => {
      const matDatePicker = document.getElementsByClassName('mat-datepicker-content')[0];
      if (matDatePicker) {
        // This is added as the date picker when opened is not rendering fresh week list
        // so when we select June 30, 2024 then it is not displaying correct week number
        // that is because
        // this.weekSection.nativeElement.innerHTML is still contains old HTML
        // that is why we are rendering list by using this.renderWeekList() which updates date picker even when it is opened

        // matDatePicker.insertAdjacentHTML('afterbegin', this.weekSection.nativeElement.innerHTML);
        this.renderWeekList();
      }
    }, 200);
  }

  calculateWeeks(month?, year?) {
    let startDate = new Date();
    let beginDate = new Date();
    if (month && year) {
      startDate = DateTime.fromObject({
        year,
        month,
      }).toJSDate();
    } else if (this.dateValue) {
      // added below line to handle dateValue when date range picker is selected, as it is giving error while formatting the date.
      beginDate =
        this.dateValue && this.dateValue['begin'] ? this.dateValue['begin'] : this.dateValue;
      startDate = DateTime.fromObject({
        year: new Date(beginDate).getFullYear(),
        month: new Date(beginDate).getMonth() + 1,
      }).toJSDate();
    }
    this.startDay = DateTime.fromJSDate(startDate).startOf('month').weekday;
    const startOfMonth = DateTime.fromJSDate(startDate).startOf('month').toJSDate();
    const endOfMonth = DateTime.fromJSDate(startDate).endOf('month').toJSDate();
    let startWeekNumber = DateTime.fromJSDate(startOfMonth).weekNumber as any;
    let endWeekNumber = DateTime.fromJSDate(endOfMonth).weekNumber as any;
    const numWeeksInMonth: any = this.weeksInMonth(year, month);
    // if first day of month is sunday, This is because week starts from Monday
    if (startOfMonth.getDay() === 0) {
      startWeekNumber = startWeekNumber + 1;
      endWeekNumber = endWeekNumber + 1;
      // if its first week of Jan
      if (startWeekNumber >= 52) {
        startWeekNumber = 1;
      } else {
        endWeekNumber = endWeekNumber - 1;
      }
    }
    this.weeksList = this.getListOfWeeks(startWeekNumber, endWeekNumber, numWeeksInMonth);
  }

  addCalenderEvents() {
    setTimeout(() => {
      this.setDateInput();
      const matDatePicker = document.getElementsByClassName('mat-datepicker-content')[0];
      // TODO: find out if there are any events exist for
      // previous and next button
      const nextPreviousButtons = document.querySelectorAll(
        '.mat-calendar .mat-calendar-previous-button,' + '.mat-calendar .mat-calendar-next-button',
      );
      const monthYearSection = document.querySelector('.mat-calendar-period-button'); // TODO: Remove dom usage in components

      setTimeout(() => {
        // TODO: find out if there are any events exist for
        // period button means month, year with dropdown button which changes year and months
        const calendarPeriodButton = document.querySelector('.mat-calendar-period-button');
        if (calendarPeriodButton) {
          this.renderer.listen(calendarPeriodButton, 'click', (event) => {
            this.renderWeekList();
          });
        }
        if (nextPreviousButtons) {
          Array.from(nextPreviousButtons).forEach((button) => {
            this.renderer.listen(button, 'click', () => {
              this.renderWeekList();
            });
          });
        }
      }, 100);
    }, 200);
  }

  renderWeekList() {
    const matDatePicker = document.getElementsByClassName('mat-datepicker-content')[0];
    // TODO: Remove dom usage in components
    const period = (document.querySelector('.mat-calendar-period-button') as HTMLElement)
      ?.innerText;
    if (period) {
      const selectedDate = new Date(isNaN(Date.parse(period)) ? period.split(' ')[0] : period);
      const monthChanged = DateTime.fromJSDate(selectedDate).month;
      const yearChanged = selectedDate.getFullYear();
      this.calculateWeeks(monthChanged, yearChanged);
      setTimeout(() => {
        if (matDatePicker.getElementsByClassName('week-section')[0]) {
          matDatePicker.getElementsByClassName('week-section')[0].remove();
        }
        if (period && period.length !== 11) {
          // to check whether it is Month period(8) or Year period(11)
          matDatePicker.insertAdjacentHTML('afterbegin', this.weekSection.nativeElement.innerHTML);
        }
      }, 200);
    }
  }

  getListOfWeeks(start, end, numWeeksInMonth): Array<number> {
    numWeeksInMonth = parseInt(numWeeksInMonth, 10);
    const weeksList = [];
    if (end < start) {
      if (start >= 52) {
        weeksList.push(start);
        for (let i = 1; i < numWeeksInMonth; i++) {
          weeksList.push(i);
        }
      } else {
        for (let i = 1; i <= numWeeksInMonth - 1; i++) {
          weeksList.push(start++);
        }
        weeksList.push(end);
      }
    } else {
      for (let i = 1; i <= numWeeksInMonth; i++) {
        weeksList.push(start++);
      }
    }
    return weeksList;
  }

  monthSelected(event) {
    setTimeout(() => {
      const matDatePicker = document.getElementsByClassName('mat-datepicker-content')[0];
      matDatePicker.insertAdjacentHTML('afterbegin', this.weekSection.nativeElement.innerHTML);
      this.renderWeekList();
    }, 200);
  }

  getMonthNumber(month) {
    let selectedMonthIndex;
    const monthNames = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];

    monthNames.forEach((item, index) => {
      // to handle cases when selected month has different abbr based on different system settings (like for September => Sep or Sept.)
      if (month.toLowerCase().indexOf(item.toLowerCase()) > -1) {
        selectedMonthIndex = index;
      }
    });
    return selectedMonthIndex;
  }

  setDateInput() {
    this.control.setValue(this.dateValue);
  }

  // Should be adjusted if we switch to day of the week to Sunday
  private weeksInMonth(year = new Date().getFullYear(), month = new Date().getMonth() + 1) {
    // Get the first and last days of the month
    const startOfMonth = new Date(year, month - 1, 1); // JavaScript months are 0-indexed
    const endOfMonth = new Date(year, month, 0); // Last day of the month

    // Adjust the day index for Monday as the starting day of the week
    // const startDay = startOfMonth.getDay(); // for sunday
    const startDay = (startOfMonth.getDay() + 6) % 7;

    // Total days in the month
    const totalDays = endOfMonth.getDate();

    // Calculate the number of weeks
    return Math.ceil((totalDays + startDay) / 7);
  }
}
