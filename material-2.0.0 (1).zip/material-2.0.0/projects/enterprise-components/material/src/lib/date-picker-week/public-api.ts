/*
 * Public API Surface of material
 */

export * from './date-picker-week.component';
export * from './date-picker-week.module';
