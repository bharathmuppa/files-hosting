import { UntypedFormBuilder, Validators } from '@angular/forms';

export const PassCustomControl = (args) => {
  const fb = new UntypedFormBuilder();
  const control = fb.control('', Validators.required);
  return {
    props: {
      ...args,
      control,
    },
  };
};
