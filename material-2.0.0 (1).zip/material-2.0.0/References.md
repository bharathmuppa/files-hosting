# References

- [Style Guide](https://angular.dev/style-guide)
- [Eslint](https://github.com/angular-eslint/angular-eslint?tab=readme-ov-file#adding-eslint-configuration-to-an-existing-angular-cli-project-which-has-no-existing-linter)
- 
