### Description
This merge request Adds a New Component. 
Please describe it in detail.

#### Check List
- [ ] Pixel Perfect Implementation
- [ ] Public API added
- **Leverage Latest Angular Features**
  - [ ] Control flows
  - [ ] Signals
  - [ ] Standalone components

#### Test Coverage
- [ ] Unit tests
- [ ] Integration tests
- [ ] End-to-End (E2E) tests

#### Linting
- [ ] `stylelint`
- [ ] `eslint`

#### Styling
- [ ] Use Tailwind CSS for styling

#### Code Quality
- [ ] Follow Boy Scout rule (refactor touched files)

#### Storybook
- [ ] Ensure all Figma designs are implemented
