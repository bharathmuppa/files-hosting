### Description
This merge request addresses the problem or user story being tackled. Please describe it in detail.

### Changes Made
Provide code snippets or screenshots as necessary.

#### Existing Components
- **Pixel Perfect Implementation**
  - [ ] Pixel perfect alignment as per design
- **Refactor**
  - [ ] Convert module to standalone component
  - [ ] Dependency on Angular 18 upgrade
  - [ ] Reduce code smells
- **Leverage Latest Angular Features**
  - [ ] Control flows
  - [ ] Signals
  - [ ] Standalone components

#### Test Coverage
- [ ] Unit tests
- [ ] Integration tests
- [ ] End-to-End (E2E) tests

#### Linting
- [ ] `stylelint`
- [ ] `eslint`

#### Styling
- [ ] Use Tailwind CSS for styling

#### Code Quality
- [ ] Follow Boy Scout rule (refactor touched files)

#### Storybook
- [ ] Ensure all Figma designs are implemented

