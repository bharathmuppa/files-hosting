module.exports = {
  // Run ng lint with specific files for TypeScript
  '*.{js,ts}': (files) =>
    `ng lint ${files.map((file) => `--lint-file-patterns ${file}`).join(' ')} --force`,

  // Run stylelint with auto-fix for SCSS files
  '*.scss': (files) => `stylelint ${files.join(' ')} --fix --allow-empty-input `,
};
