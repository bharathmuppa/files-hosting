# Setup Git Hooks for pre-commit and pre-push

This is a guide to setup git hooks for pre-commit and pre-push using Husky and lint-staged. But developers  noo need to do all this, as this is already setup in the project.
you can just run the following command to install the hooks.

`npm i`


## Steps we followed to setup the hooks

```bash

## Step 1: Install Husky and lint-staged

```bash
npm install --save-dev husky lint-staged
```

## Step 2: Update package.json && lint-staged

```json
{
  "scripts": {
    "ng": "ng",
    "start": "ng serve",
    "pre-commit": "npx lint-staged",
    "pre-push": "npm build",
    "postinstall": "npx husky init &&  echo 'npm run pre-commit'> .husky/pre-commit && echo 'npm run pre-push'> .husky/pre-push"
  }
}
```
```js
  //.lintestagedrc.js
module.exports = {
  // Run ng lint with specific files for TypeScript
  '*.{js,ts}': (files) =>
    `ng lint ${files.map((file) => `--lint-file-patterns ${file}`).join(' ')} --force`,

  // Run stylelint with auto-fix for SCSS files
  '*.scss': (files) => `stylelint ${files.join(' ')} --fix`,
};

```

## Step 3: Initialize Husky

This step should be done in all other devs machine, so that they can use the hooks.

```bash
npm install
```

### References
[Run only changed files in lint-staged](https://vipin-saini.medium.com/pre-commit-hooks-angular-12-2b7d8f9d5633)

> Note: Dont change the husky folder as it is being ignore in gitignore file.
> Note: In pipeline, you need to run  npm ci  --ignore-scripts, so that post install script won't kick in, thus husky will not be initialized.
