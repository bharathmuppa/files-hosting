# Angular project Formatting: EditorConfig, Prettier, and Angular ESLint

This guide provides a setup for using **EditorConfig**, **Prettier**, and **Angular ESLint** in an Angular project. Each tool has a unique role, and additional plugins (like **eslint-config-prettier** and **eslint-plugin-prettier**) ensure these tools work together without conflict.

## Why Use All Three Tools?

1. **EditorConfig**:
    - **Purpose**: Sets basic editor settings (e.g., line endings, indentation style) across all files.
    - **Benefits**: Ensures consistent basic formatting across different editors, even for files not handled by ESLint or Prettier (e.g., markdown).
    - **Role**: Acts as a baseline to prevent issues from differing editor defaults.

2. **Prettier**:
    - **Purpose**: Focuses on code formatting (e.g., spacing, line length, quotes) based on a standard set of rules.
    - **Benefits**: Provides fast, automatic formatting, eliminating the need for ESLint to handle formatting. Minimizes discussions over style choices.
    - **Role**: Handles the visual structure of the code, ensuring readability and consistency.

3. **Angular ESLint**:
    - **Purpose**: Enforces Angular, TypeScript, and JavaScript code quality and best practices.
    - **Benefits**: Catches potential bugs and enforces consistent code quality, especially Angular-specific rules that Prettier doesn’t cover.
    - **Role**: Focuses on code quality and best practices, while Prettier handles formatting.

## Why Use `eslint-config-prettier` and `eslint-plugin-prettier`?

When using **ESLint** and **Prettier** together, **eslint-config-prettier** and **eslint-plugin-prettier** are essential to avoid conflicts and ensure seamless integration.

### 1. `eslint-config-prettier`
- **Purpose**: Disables any formatting-related rules in ESLint that would conflict with Prettier.
- **Reason**: Since ESLint has its own rules for code styling (e.g., indentation, line length), these can conflict with Prettier’s rules. `eslint-config-prettier` turns off ESLint’s formatting rules, letting Prettier take full control over formatting.
- **Benefit**: By disabling ESLint formatting rules, it avoids redundancy and ensures that Prettier is the sole source of formatting decisions, simplifying maintenance and improving consistency.

### 2. `eslint-plugin-prettier`
- **Purpose**: Integrates Prettier as an ESLint rule, allowing ESLint to report any formatting issues that Prettier detects.
- **Reason**: `eslint-plugin-prettier` makes Prettier errors show up as ESLint issues, so developers can see both formatting and quality errors in one place, typically within their code editor.
- **Benefit**: Consolidates feedback from both Prettier and ESLint, making it easier to fix all issues without needing to switch between different tools or error reports.

Together, **eslint-config-prettier** and **eslint-plugin-prettier** ensure that ESLint and Prettier work in harmony, with ESLint focusing on code quality and Prettier on formatting.

## Step 1: Add `.editorconfig`

Add a `.editorconfig` file to define consistent editor settings across all files.

```plaintext
# Editor configuration, see https://editorconfig.org
root = true

[*]
charset = utf-8
indent_style = space
indent_size = 2
insert_final_newline = true
trim_trailing_whitespace = true

[*.md]
max_line_length = off
trim_trailing_whitespace = false
```

## Step 2: Install Prettier and Angular ESLint

Run the following commands:

```bash
# Install Prettier, Prettier and ESLint integration plugins
npm install --save-dev prettier eslint-config-prettier eslint-plugin-prettier

# Install Angular ESLint and dependencies
ng add @angular-eslint/schematics

```

## Step 3: Configure Prettier

Create a `.prettierrc` file to define Prettier formatting rules:

```json
// .prettierrc
{
  "semi": true,
  "singleQuote": true,
  "printWidth": 100,
  "tabWidth": 2,
  "trailingComma": "all",
  "endOfLine": "lf"
}
```

Add `.prettierignore` to exclude certain files/folders from formatting:

```plaintext
# .prettierignore
dist/
node_modules/
*.md
package-lock.json
```

## Step 4: Configure Angular ESLint with Prettier

Edit your `.eslintrc.js` file to integrate Prettier with ESLint. This example uses both `eslint-config-prettier` and `eslint-plugin-prettier`:

```js
// .eslintrc.js
module.exports = {
  // Marks this configuration as the root, so ESLint doesn’t look for other configurations higher up in the directory.
  root: true,

  // Ignore patterns prevent ESLint from processing specific folders or files.
  // Here, "projects/**/*" ensures that sub-projects are ignored unless they have their own ESLint configuration.
  ignorePatterns: ['projects/**/*'],

  overrides: [
    {
      // Target TypeScript files for linting with specific rules and plugins
      files: ['*.ts'],

      // parserOptions specifies TypeScript configurations for ESLint’s parser.
      // This allows ESLint to understand types and project-specific types in the main app and e2e tests.
      parserOptions: {
        project: [
          'tsconfig.json', // Main project TypeScript configuration
          'e2e/tsconfig.json', // End-to-end testing TypeScript configuration
        ],
        createDefaultProgram: true,
      },

      // Extend recommended configurations for Angular and Prettier integration.
      extends: [
        'plugin:@angular-eslint/recommended', // Angular-specific best practices
        'plugin:@angular-eslint/template/process-inline-templates', // Support for inline HTML in Angular components
        'plugin:prettier/recommended', // Integrates Prettier and disables ESLint conflicts
      ],

      // Custom linting rules for Angular component and directive selectors to maintain naming conventions.
      rules: {
        '@angular-eslint/component-selector': [
          'error',
          {
            prefix: 'aal', // Prefix for Angular component selectors
            style: 'kebab-case', // Enforce kebab-case for selectors
            type: 'element', // Apply to element selectors
          },
        ],
        '@angular-eslint/directive-selector': [
          'error',
          {
            prefix: 'aal', // Prefix for Angular directive selectors
            style: 'camelCase', // Enforce camelCase for directives
            type: 'attribute', // Apply to attribute selectors
          },
        ],
      },
    },
    {
      // Target HTML files for Angular template linting.
      files: ['*.html'],

      // Extend Angular-specific template linting rules.
      extends: ['plugin:@angular-eslint/template/recommended'],

      // Add template-specific rules here if necessary
      rules: {},
    },
    {
      // Target HTML templates within components for Angular template linting.
      "files": ["*.component.ts"],
      "extends": ["plugin:@angular-eslint/template/process-inline-templates"]
    }
  ],

  // Extend Storybook’s recommended rules for Storybook-specific code.
  extends: ['plugin:storybook/recommended'],
};

```

### Explanation:
- **`plugin:prettier/recommended`**: Combines `eslint-config-prettier` and `eslint-plugin-prettier`, letting Prettier handle all formatting and making Prettier errors appear as ESLint issues.

## Step 5: Enable Formatting on Save

Configure formatting on save for your editor.

### VSCode
In VSCode, add the following to `.vscode/settings.json`:

```json
{
  "editor.formatOnSave": true,
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "[typescript]": {
    "editor.defaultFormatter": "esbenp.prettier-vscode"
  },
  "[typescriptreact]": {
    "editor.defaultFormatter": "esbenp.prettier-vscode"
  },
  "prettier.requireConfig": true
}
```

### IntelliJ/WebStorm

#### STEP 1: Disable Eslint and tslint in intellij settings, you can use actions to find eslint and tslint settings
![Disable Eslint](resources/intellij-settings.png)

#### STEP 2: Go to **Settings** > **Languages & Frameworks** > **JavaScript** > **Prettier**.
![intellij settings](resources/mjs.png)




## Step 6: Optional – Add a Pre-Commit Hook

Use **Husky** and **lint-staged** to enforce formatting and linting on every commit.

```bash
# Install Husky and lint-staged
npm install --save-dev husky lint-staged

# Initialize Husky
npx husky install

# Add Prettier and ESLint to lint-staged in package.json
{
  "lint-staged": {
    "*.{ts,js,json,css,scss,html}": [
      "prettier --write",
      "eslint --fix"
    ]
  }
}

# Add a pre-commit hook
npx husky add .husky/pre-commit "npx lint-staged"
```

---

This setup provides a cohesive, high-quality codebase with consistent formatting, integrating Prettier and Angular ESLint seamlessly.
