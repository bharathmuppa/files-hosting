# Technical Design Document 

## Summary
- This Component uses Control value accessor.

#Inputs
- Form Control 

# Output events
- 
