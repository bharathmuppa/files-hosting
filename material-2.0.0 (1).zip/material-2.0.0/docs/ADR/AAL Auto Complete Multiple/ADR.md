# ADR for AAL AutoComplete Multiple

## Requirement
I want a component which takes multiple inputs from user, also shows suggestions based on text user entered and selected option should be shown as chip which can be also be removed.

It can take a help component
It can have a tooltip
It can take a placeholder

## UX Decision
[UX Specification](https://wiki.asml.com/wiki/confluence/pages/viewpage.action?pageId=305811928)

## Behaviour
### Mode and Lock Mode
- This component should have 3 modes, namely
  EDIT - Changes control to be editable (Will show form control)
  READ - Form control will be hidden and HTML element with value is show
  PROTECTED - Form field should be disabled.
  PRIVATE - Show only field label
- User can also set a Lock mode, it takes priority over mode.
  - Eg: Mode: Edit, LockMode: Read - Component will be read Mode
  - Eg: Mode: Read, LockMode: EDIT - Component will be read Mode initially and then upon interaction it will be Locked in EDIT Mode.

### Save
- Should save on blur event, this should be configurable.
- Should save on accept button in confirm toolbar if user wants to show Confirm toolbar.
- default state is blur event

### Revert
- Should revert changes on reject button in confirm toolbar or on Escape button.
  - Eg: Initial value is `foo`, then user starts entering `foo-some-more--fooo` and then clicks on reject button or clicked on esc then component should show previous value which is `foo`

### Reset/clear all
- Clear all by clear icon on input.
- Individual remove chip functionality- (default= true)

### Error State
- It should support form validations based on configuration object, which will be defined in below section.

### design
Row1: Should have chips added.()
Row2: Input field to enter value. ClearAll at end.

### History
- History is last N(default=4) search results which you have saved
- It should be optional;
- History should have filtering based on what you search.
- It accepts and History array. (Either application can provide this or a state management from material)

### Default State
- By Default Field will be in read mode and when user clicks on the field it enters into Edit Mode, Unless specified explicitly using Modes and Lock Mode.

## Display Value
- this component should take display values in line 1 and line 2
- icon as input
- separators (-,. ())
- item display field

## Solution design
- [Refer to Technical Design Document](./TDD.md)
- Reactive Forms

## Alternatives Considered
1. Control is passed as input
   - <aal-auto-complete  [mode]="" [lockMode]="" [control]="<control from application will be passed here>" [options]="" [placeholder]="configObj.placeholder" [help]=""> </aal-auto-complete>
   - Pros
     - Fine grained control. component wrapper suports UX better and can cook lot of business logic within component.
   - Cons: 
     - We have to emit events on our own. No framework support
     - Results in more code in component, bloated component
   Migration Effort: LOW

2. Passing the options as input instead of Control and creating the form control within the component
   - <aal-auto-complete  [mode]="" [lockMode]="" [options]="" [formControlName]="control"> </aal-auto-complete>
   - Pros
     - More Standardized way, coz we can use Control Value Accessor(More close to Framework)
     - Proven Solution
   - Cons
     - With Control value accessor, more restricted on internal state. possible but complex 
   - Migration Effort: MEDIUM

> Decision: 2 
> 
> Reason: Though we expect More Migration effort, it is a standard way of working and we believe it will bring more benefits in long run.






